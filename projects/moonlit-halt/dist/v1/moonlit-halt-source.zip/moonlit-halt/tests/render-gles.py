import ctypes as C, json, os, tempfile
from PIL import Image
E=C.CDLL('libEGL.so.1'); P=C.c_void_p; I=C.c_int; U=C.c_uint; F=C.c_float
E.eglGetProcAddress.argtypes=[C.c_char_p];E.eglGetProcAddress.restype=P
getPlatform=C.CFUNCTYPE(P,U,P,C.POINTER(I))(E.eglGetProcAddress(b'eglGetPlatformDisplayEXT'))
d=getPlatform(0x31DD,None,None)
E.eglInitialize.argtypes=[P,C.POINTER(I),C.POINTER(I)]; a=I();b=I();assert E.eglInitialize(d,C.byref(a),C.byref(b))
E.eglBindAPI.argtypes=[U];assert E.eglBindAPI(0x30A0)
attrs=(I*15)(0x3033,1,0x3040,4,0x3024,8,0x3023,8,0x3022,8,0x3025,24,0x3038,0,0)
E.eglChooseConfig.argtypes=[P,C.POINTER(I),C.POINTER(P),I,C.POINTER(I)];conf=P();n=I();assert E.eglChooseConfig(d,attrs,C.byref(conf),1,C.byref(n)) and n.value
E.eglCreatePbufferSurface.argtypes=[P,P,C.POINTER(I)];E.eglCreatePbufferSurface.restype=P
surface=E.eglCreatePbufferSurface(d,conf,(I*5)(0x3057,1280,0x3056,720,0x3038))
E.eglCreateContext.argtypes=[P,P,P,C.POINTER(I)];E.eglCreateContext.restype=P
context=E.eglCreateContext(d,conf,None,(I*3)(0x3098,2,0x3038))
E.eglMakeCurrent.argtypes=[P,P,P,P];assert E.eglMakeCurrent(d,surface,surface,context)
def fn(name,ret,*args):return C.CFUNCTYPE(ret,*args)(E.eglGetProcAddress(name.encode()))
createShader=fn('glCreateShader',U,U);source=fn('glShaderSource',None,U,I,C.POINTER(C.c_char_p),C.POINTER(I));compile=fn('glCompileShader',None,U);getShader=fn('glGetShaderiv',None,U,U,C.POINTER(I));logShader=fn('glGetShaderInfoLog',None,U,I,C.POINTER(I),C.c_char_p)
createProgram=fn('glCreateProgram',U);attach=fn('glAttachShader',None,U,U);link=fn('glLinkProgram',None,U);getProgram=fn('glGetProgramiv',None,U,U,C.POINTER(I));use=fn('glUseProgram',None,U)
def make(shaders):
 p=createProgram()
 for s in shaders:
  sh=createShader(s['type']);ss=C.c_char_p(s['source'].encode());source(sh,1,C.byref(ss),None);compile(sh);ok=I();getShader(sh,0x8B81,C.byref(ok))
  if not ok.value:
   buf=C.create_string_buffer(4096);logShader(sh,4096,None,buf);raise Exception(buf.value)
  attach(p,sh)
 link(p);ok=I();getProgram(p,0x8B82,C.byref(ok));assert ok.value,'link failure';return p
cap=json.load(open(os.environ.get('MOONLIT_CAPTURE',os.path.join(tempfile.gettempdir(),'moonlit-scene-capture.json'))));programs=[make(p['shaders']) for p in cap['programs']]
getLoc=fn('glGetUniformLocation',I,U,C.c_char_p);getAttr=fn('glGetAttribLocation',I,U,C.c_char_p);mat=fn('glUniformMatrix4fv',None,I,I,U,C.POINTER(F));vec=fn('glUniform3fv',None,I,I,C.POINTER(F));scalar=fn('glUniform1f',None,I,F)
gen=fn('glGenBuffers',None,I,C.POINTER(U));bind=fn('glBindBuffer',None,U,U);buffer=fn('glBufferData',None,U,C.c_ssize_t,P,U);enableAttr=fn('glEnableVertexAttribArray',None,U);pointer=fn('glVertexAttribPointer',None,U,I,U,U,I,P);draw=fn('glDrawArrays',None,U,I,I);enable=fn('glEnable',None,U);disable=fn('glDisable',None,U);clear=fn('glClear',None,U);clearColor=fn('glClearColor',None,F,F,F,F);viewport=fn('glViewport',None,I,I,I,I)
viewport(0,0,1280,720);clearColor(.03,.05,.09,1);clear(0x4100)
# Draw the same sky and static scene using actual OpenGL ES shaders.
p=programs[2];use(p);sky=(F*12)(-1,-1,1,-1,-1,1,-1,1,1,-1,1,1);v=U();gen(1,C.byref(v));bind(0x8892,v);buffer(0x8892,C.sizeof(sky),sky,0x88E4);loc=getAttr(p,b'a');enableAttr(loc);pointer(loc,2,0x1406,0,8,None);scalar(getLoc(p,b'pitch'),.035);draw(4,0,6);fn('glDisableVertexAttribArray',None,U)(loc)
p=programs[0];use(p);enable(0x0B71)
mat(getLoc(p,b'uVP'),1,0,(F*16)(*cap['vp']));vec(getLoc(p,b'uEye'),1,(F*3)(*cap['eye']));vec(getLoc(p,b'uLights[0]'),6,(F*18)(*cap['lights']));scalar(getLoc(p,b'uTime'),0)
geo=(F*len(cap['geometry']))(*cap['geometry']);v=U();gen(1,C.byref(v));bind(0x8892,v);buffer(0x8892,C.sizeof(geo),geo,0x88E4)
for name,size,offset in [(b'aPosition',3,0),(b'aNormal',3,12),(b'aColor',4,24)]:
 loc=getAttr(p,name);enableAttr(loc);pointer(loc,size,0x1406,0,40,P(offset))
draw(4,0,len(cap['geometry'])//10)
err=fn('glGetError',U)();assert err==0,hex(err)
raw=(C.c_ubyte*(1280*720*4))();fn('glReadPixels',None,I,I,I,I,U,U,P)(0,0,1280,720,0x1908,0x1401,raw)
im=Image.frombytes('RGBA',(1280,720),bytes(raw)).transpose(Image.Transpose.FLIP_TOP_BOTTOM);im.save(os.environ.get('MOONLIT_RENDER',os.path.join(tempfile.gettempdir(),'moonlit-native-render.png')))
print('PASS: all 6 shaders compiled, all 3 programs linked, static scene rendered at 1280x720; GL error 0. Native offscreen GLES, not browser/mobile QA.')
