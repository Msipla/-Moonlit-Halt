package dev.mispla.abyss;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import dev.mispla.abyss.GlimmeringAbyss.View;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.List;
import net.minecraft.class_1944;
import net.minecraft.class_2168;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3492;
import net.minecraft.class_3499;
import net.minecraft.class_7923;

/** Six buildings on an explicitly authored local shelf, study dimension only. */
public final class Town {
    public static final class_2338 ORIGIN=new class_2338(-55,-63,-106);
    public static final List<GlimmeringAbyss.View> VIEWS=List.of(
        new GlimmeringAbyss.View("street",47.5,39,4.5,180,-9),
        new GlimmeringAbyss.View("plaza",63.5,39,4.5,112,-8),
        new GlimmeringAbyss.View("high",55.5,59,-60.5,27,18),
        new GlimmeringAbyss.View("cliff",20.5,39,-11.5,90,55),
        new GlimmeringAbyss.View("bridge",4.5,39,33.4,180,47),
        new GlimmeringAbyss.View("scale",-29.5,39,35.5,-55,-10),
        new GlimmeringAbyss.View("overview",-31.5,73,66.5,-145,24),
        Architecture.VIEWS.get(0),Architecture.VIEWS.get(4));
    private Town(){}
    private static class_3218 world(class_2168 s){
        var w=s.method_9211().method_3847(GlimmeringAbyss.STUDY);if(w==null)throw new IllegalStateException("Study missing");return w;
    }
    private static class_3499 template(class_3218 w){return w.method_14183().method_15094(GlimmeringAbyss.id("town")).orElseThrow(()->new IllegalStateException("Town template missing"));}
    public static int place(class_2168 s){
        try{
            var w=world(s);var t=template(w);
            if(!t.method_15172(w,ORIGIN,ORIGIN,new class_3492().method_15133(true).method_15131(true),w.field_9229,class_2248.field_31028|class_2248.field_31031))throw new IllegalStateException("Town placement failed");
            s.method_9226(()->class_2561.method_43470("[Abyss] Phase 6 town ready. /abyss town view street | high | cliff; /abyssrender blue | blue95 | blue95-fog. Explicit local terrain replacement: use a test save."),false);return 1;
        }catch(Exception e){e.printStackTrace();s.method_9213(class_2561.method_43470(e.getMessage()));return 0;}
    }
    public static int view(class_2168 s,String name)throws com.mojang.brigadier.exceptions.CommandSyntaxException{
        var v=VIEWS.stream().filter(x->x.name().equals(name)).findFirst().orElse(null);
        if(v==null){s.method_9213(class_2561.method_43470("street | plaza | high | cliff | bridge | scale | overview | facade | interior"));return 0;}
        var p=s.method_9207();if(name.equals("overview")&&!p.method_7337()){s.method_9213(class_2561.method_43470("Overview requires Creative"));return 0;}
        p.method_31549().field_7479=name.equals("overview");p.method_7355();p.method_14251(world(s),v.x(),v.y(),v.z(),v.yaw(),v.pitch());return 1;
    }
    private static <T extends Comparable<T>> String value(class_2680 s,class_2769<T> p){return p.method_11901(s.method_11654(p));}
    private static boolean clear(class_3218 w,class_2338 p){
        var floor=w.method_8320(p.method_10074()).method_26220(w,p.method_10074());
        return !floor.method_1110()&&floor.method_1105(class_2350.class_2351.field_11052)==1.0&&w.method_8320(p).method_26220(w,p).method_1110()&&w.method_8320(p.method_10084()).method_26220(w,p.method_10084()).method_1110();
    }
    public static int audit(class_2168 s,String label){
        try{
            if(!label.matches("[a-zA-Z0-9_-]{1,40}"))throw new IllegalArgumentException("label");
            var w=world(s);var n=template(w).method_15175(new class_2487());var palette=n.method_10554("palette",class_2520.field_33260);var list=n.method_10554("blocks",class_2520.field_33260);
            int mismatch=0,propsMismatch=0,windows=0,lit=0;var digest=MessageDigest.getInstance("SHA-256");
            for(int i=0;i<list.size();i++){
                var e=list.method_10602(i);var xyz=e.method_10554("pos",class_2520.field_33253);var p=ORIGIN.method_10069(xyz.method_10600(0),xyz.method_10600(1),xyz.method_10600(2));
                var expected=palette.method_10602(e.method_10550("state"));var actual=w.method_8320(p);
                if(!expected.method_10558("Name").equals(class_7923.field_41175.method_10221(actual.method_26204()).toString()))mismatch++;
                var props=expected.method_10562("Properties");for(var prop:actual.method_28501())if(props.method_10545(prop.method_11899())&&!props.method_10558(prop.method_11899()).equals(value(actual,prop)))propsMismatch++;
                digest.update((p.method_23854()+"="+actual+"\n").getBytes(java.nio.charset.StandardCharsets.UTF_8));
                if(expected.method_10558("Name").equals("glimmeringabyss:warm_window")){windows++;if(actual.method_27852(GlimmeringAbyss.WARM_WINDOW)&&w.method_8314(class_1944.field_9282,p)==12)lit++;}
            }
            int samples=0;boolean route=true;
            for(int z=5;z<=43;z++){route&=clear(w,new class_2338(30,39,z));samples++;}
            for(int x=30;x<=47;x++){route&=clear(w,new class_2338(x,39,1));samples++;}
            for(int z=-60;z<=4;z++){
                if(z==-26||z==-43){route&=w.method_8320(new class_2338(47,z==-26?39:40,z)).method_27852(class_2246.field_28897);continue;}
                route&=clear(w,new class_2338(47,39+(z<=-26?1:0)+(z<=-43?1:0),z));samples++;
            }
            for(int x=-29;x<=30;x++){route&=clear(w,new class_2338(x,39,35));samples++;}
            boolean ladder=true;for(int y=41;y<60;y++)ladder&=w.method_8320(new class_2338(54,y,-58)).method_27852(class_2246.field_9983);
            boolean drop=true;int dropSamples=0;
            for(int x:new int[]{0,4,20})for(int z:new int[]{-20,35})for(int y=-62;y<=36;y++){
                var p=new class_2338(x,y,z);drop&=w.method_8320(p).method_26215();dropSamples++;
            }
            // Independently re-read the old shipped template's 52 accepted windows.
            var old=w.method_14183().method_15094(GlimmeringAbyss.id("workshop")).orElseThrow().method_15175(new class_2487());
            var op=old.method_10554("palette",class_2520.field_33260);var ob=old.method_10554("blocks",class_2520.field_33260);int preserved=0;
            for(int i=0;i<ob.size();i++){
                var e=ob.method_10602(i);if(!op.method_10602(e.method_10550("state")).method_10558("Name").equals("glimmeringabyss:warm_window"))continue;
                var xyz=e.method_10554("pos",class_2520.field_33253);var p=Architecture.ORIGIN.method_10069(xyz.method_10600(0),xyz.method_10600(1),xyz.method_10600(2));
                if(w.method_8320(p).method_27852(GlimmeringAbyss.WARM_WINDOW)&&w.method_8314(class_1944.field_9282,p)==12)preserved++;
            }
            var r=new JsonObject();r.addProperty("label",label);r.addProperty("template_blocks_checked",list.size());r.addProperty("block_id_mismatches",mismatch);r.addProperty("explicit_property_mismatches",propsMismatch);
            r.addProperty("actual_structure_state_sha256",HexFormat.of().formatHex(digest.digest()));r.addProperty("warm_window_blocks",windows);r.addProperty("warm_windows_native_light_12",lit);r.addProperty("accepted_workshop_windows_preserved",preserved);
            r.addProperty("route_samples",samples);r.addProperty("route_collision_clearance_pass",route);r.addProperty("ladder_pass",ladder);r.addProperty("deep_air_samples",dropSamples);r.addProperty("open_depth_pass",drop);r.addProperty("finite_floor_y",-63);
            r.addProperty("template_entities",n.method_10554("entities",class_2520.field_33260).size());r.addProperty("buildings",6);r.addProperty("pass",mismatch==0&&propsMismatch==0&&windows==lit&&preserved==52&&route&&ladder&&drop);
            Path out=Path.of("abyss-results");Files.createDirectories(out);Files.writeString(out.resolve("town-"+label+".json"),new GsonBuilder().setPrettyPrinting().create().toJson(r));
            s.method_9226(()->class_2561.method_43470("[Abyss] Town "+label+" / "+r),false);return r.get("pass").getAsBoolean()?1:0;
        }catch(Exception e){e.printStackTrace();s.method_9213(class_2561.method_43470(e.getMessage()));return 0;}
    }
}
