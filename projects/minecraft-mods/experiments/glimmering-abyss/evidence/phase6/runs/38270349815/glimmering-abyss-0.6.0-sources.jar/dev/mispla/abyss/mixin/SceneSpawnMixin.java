package dev.mispla.abyss.mixin;

import dev.mispla.abyss.SceneSafety;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3218.class)
public abstract class SceneSpawnMixin {
    @Inject(method="spawnEntity",at=@At("HEAD"),cancellable=true)
    private void abyss$excludeSceneMobs(class_1297 entity,CallbackInfoReturnable<Boolean> result){
        if(entity instanceof class_1308&&SceneSafety.protects((class_3218)(Object)this))result.setReturnValue(false);
    }
}
