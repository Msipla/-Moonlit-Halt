package dev.mispla.abyss;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1311;
import net.minecraft.class_1642;
import net.minecraft.class_1928;
import net.minecraft.class_1944;
import net.minecraft.class_2168;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/** Entire current landscape dimension, including its dark outer caves and abyss.
 * No global gamerule change. Vanilla aggressive phantoms are also excluded;
 * a future explicitly authored neutral scenic phantom is a separate decision. */
public final class SceneSafety {
    private SceneSafety(){}
    public static boolean protects(class_3218 world){return world.method_27983().equals(GlimmeringAbyss.STUDY);}
    public static void initialize(){
        // Also covers old save entities, spawners and alternate insertion paths.
        ServerEntityEvents.ENTITY_LOAD.register((entity,world)->{if(protects(world)&&entity instanceof class_1308)entity.method_31472();});
    }
    public static int probe(class_2168 s,String label){
        try{
            if(!Boolean.getBoolean("abyss.testServer")||!label.matches("[a-zA-Z0-9_-]{1,40}"))throw new IllegalArgumentException("Isolated test server only");
            var w=s.method_9211().method_3847(GlimmeringAbyss.STUDY);var overworld=s.method_9211().method_30002();
            boolean before=overworld.method_8450().method_8355(class_1928.field_19390);int entries=0;
            // Generator uses one quiet_depths biome everywhere, not a town-only mask.
            for(var group:class_1311.values())entries+=w.method_23753(new class_2338(-45,-40,-60)).comp_349().method_30966().method_31004(group).method_34994().size();
            var attempts=new JsonArray();boolean blocked=true;
            for(var type:List.of(class_1299.field_6051,class_1299.field_6137,class_1299.field_6046,class_1299.field_6079,class_1299.field_6091,class_1299.field_6078,class_1299.field_6108,class_1299.field_6085,class_1299.field_6114)){
                var e=type.method_5883(w);e.method_5814(-40,20,-60);boolean accepted=w.method_8649(e);blocked&=!accepted;
                var row=new JsonObject();row.addProperty("type",class_1299.method_5890(type).toString());row.addProperty("spawn_accepted",accepted);attempts.add(row);if(accepted)e.method_31472();
            }
            var control=class_1299.field_6051.method_5883(overworld);control.method_5814(0,45,0);boolean allowed=overworld.method_8649(control);boolean retained=!control.method_31481();control.method_31472();
            int mobs=0;for(var entity:w.method_27909())if(entity instanceof class_1308)mobs++;
            boolean after=overworld.method_8450().method_8355(class_1928.field_19390);
            var r=new JsonObject();r.addProperty("label",label);r.addProperty("difficulty",w.method_8407().method_5460());r.addProperty("entire_study_dimension_protected",protects(w));r.addProperty("overworld_protected",protects(overworld));r.addProperty("natural_biome_spawn_entries",entries);r.add("actual_spawn_attempts",attempts);
            r.addProperty("all_scene_mob_insertions_rejected",blocked);r.addProperty("loaded_scene_mobs",mobs);r.addProperty("overworld_zombie_spawn_accepted",allowed&&retained);r.addProperty("overworld_doMobSpawning_before",before);r.addProperty("overworld_doMobSpawning_after",after);r.addProperty("dark_abyss_native_block_light",w.method_8314(class_1944.field_9282,new class_2338(0,-60,-20)));
            r.addProperty("pass",entries==0&&blocked&&mobs==0&&allowed&&retained&&before&&after&&!protects(overworld)&&w.method_8407()!=net.minecraft.class_1267.field_5801);
            Path out=Path.of("abyss-results");Files.createDirectories(out);Files.writeString(out.resolve("safety-"+label+".json"),new GsonBuilder().setPrettyPrinting().create().toJson(r));s.method_9226(()->class_2561.method_43470("[Abyss] Safety "+r),false);return r.get("pass").getAsBoolean()?1:0;
        }catch(Exception e){e.printStackTrace();s.method_9213(class_2561.method_43470(e.getMessage()));return 0;}
    }
}
