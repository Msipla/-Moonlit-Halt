package dev.mispla.abyss;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1011;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_318;
import net.minecraft.class_3965;
import net.minecraft.class_412;
import net.minecraft.class_442;
import net.minecraft.class_5365;
import net.minecraft.class_639;
import net.minecraft.class_642;
import org.lwjgl.opengl.GL11;
import java.nio.file.Files;
import java.nio.file.Path;

/** Opt-in official-client harness: actual bell interactions, two rides and walking keys. */
public final class Phase7CaptureClient implements ClientModInitializer {
    private static final boolean RECONNECT=Boolean.getBoolean("abyss.capture.phase7.reconnect");
    private static final boolean NATURAL=Boolean.getBoolean("abyss.capture.phase75");
    private static final boolean SECOND=Boolean.getBoolean("abyss.capture.phase75.second");
    private long dreamSeenAt;
    private int dreamCaptured;
    private final JsonArray motion=new JsonArray();
    private static final Path OUT=Path.of(RECONNECT?"abyss-phase7-reconnect":"abyss-phase7-captures");
    private final JsonArray frames=new JsonArray(),walks=new JsonArray(),rides=new JsonArray(),accesses=new JsonArray();
    private boolean connected,finished,midShot,lowShot,exteriorShot;
    private long exteriorAt;
    private net.minecraft.class_1531 photoCamera;
    private long started,changed;
    private int phase=-1,leg,sleeps;
    private boolean observedSleep,restartReady;
    private double startX,startZ;
    private static final double[][] WALK=NATURAL?new double[][]{{6.5,72.5},{20.5,72.5},{20.5,70.5},{38.5,70.5},{38.5,43.5},{30.5,43.5},{30.5,35.5},{-29.5,35.5},{-46.5,35.5},{-29.5,35.5},{30.5,35.5},{30.5,5.5},{47.5,5.5},{47.5,-22.5},{47.5,5.5},{30.5,5.5},{30.5,43.5},{38.5,43.5},{38.5,70.5},{20.5,70.5},{20.5,72.5},{6.5,72.5},{6.5,70.5}}:new double[][]{{6.5,72.5},{20.5,72.5},{20.5,70.5},{38.5,70.5},{38.5,43.5},{30.5,43.5},{30.5,35.5},{-29.5,35.5},{30.5,35.5},{30.5,5.5},{47.5,5.5},{47.5,-22.5},{47.5,5.5},{30.5,5.5},{30.5,43.5},{38.5,43.5},{38.5,70.5},{20.5,70.5},{20.5,72.5},{6.5,72.5},{6.5,70.5}};
    @Override public void onInitializeClient(){if(!Boolean.getBoolean("abyss.capture.phase7"))return;started=System.nanoTime();ClientTickEvents.END_CLIENT_TICK.register(this::tick);}
    private double seconds(){return (System.nanoTime()-changed)/1e9;}
    private void next(){phase++;changed=System.nanoTime();System.out.println("ABYSS_PHASE7_STAGE "+phase);}
    private void command(class_310 c,String command){c.method_1562().method_45730("abyss phase7 "+command);}
    private void bell(class_310 c,boolean upper){
        var p=new class_2338(JourneyClient.x+6,upper?JourneyClient.entryY+1:45,JourneyClient.z+68);
        c.field_1761.method_2896(c.field_1724,class_1268.field_5808,new class_3965(class_243.method_24953(p),class_2350.field_11035,p,false));
    }
    private void tick(class_310 c){
        if(finished)return;
        try{
            if(System.nanoTime()-started>1500_000_000_000L)throw new IllegalStateException("Capture deadline");
            if(!connected&&c.field_1755!=null&&c.method_18506()==null&&!(c.field_1755 instanceof class_442))c.method_1507(new class_442());
            if(!connected&&c.field_1755 instanceof class_442&&c.method_18506()==null){
                connected=true;c.field_1690.method_42503().method_41748(16);c.field_1690.method_42510().method_41748(6);c.field_1690.method_41808().method_41748(75);c.field_1690.method_42473().method_41748(.5);c.field_1690.method_42524().method_41748(45);c.field_1690.method_42433().method_41748(false);c.field_1690.method_42534().method_41748(class_5365.field_25428);c.field_1690.method_41792().method_41748(true);c.field_1690.field_1837=false;c.field_1690.field_1842=true;
                String address="127.0.0.1:"+Integer.getInteger("abyss.port",25585);class_412.method_36877(new class_442(),c,class_639.method_2950(address),new class_642("Phase 7 release test",address,false),false);return;
            }
            if(restartReady&&c.field_1687==null){finished=true;c.method_1592();return;}
            if(c.field_1724==null||c.field_1687==null||!JourneyClient.ready())return;
            if(NATURAL&&c.field_1724.method_5765()&&(phase==3||phase==6)){
                var r=new JsonObject();r.addProperty("phase",phase);r.addProperty("seconds",seconds());r.addProperty("x",c.field_1724.method_23317());r.addProperty("y",c.field_1724.method_23318());r.addProperty("z",c.field_1724.method_23321());
                var car=c.field_1724.method_5854();r.addProperty("car_x",car.method_23317());r.addProperty("car_y",car.method_23318());r.addProperty("car_z",car.method_23321());motion.add(r);
            }
            if(SECOND){
                if(phase==-1){command(c,"view overview");next();return;}
                if(seconds()<18||!queues(c))return;
                capture(c,"second-seed-overview.png");finished=true;c.method_1592();return;
            }
            if(c.field_1755 instanceof DreamScreen dream){
                if(dream.step>dreamCaptured){
                    if(dreamSeenAt==0)dreamSeenAt=System.nanoTime();
                    if(System.nanoTime()-dreamSeenAt>400_000_000L){capture(c,"dream-"+dream.step+".png");dreamCaptured=dream.step;dreamSeenAt=0;}
                }
                return;
            }
            if(RECONNECT){
                if(phase==-1){next();return;}if(seconds()<12)return;checkLanding(c,true);capture(c,"reconnected-safe-station.png");
                var recovery=new JsonObject();recovery.addProperty("pass",true);recovery.addProperty("same_offline_identity",true);write("recovery.json",recovery);finished=true;c.method_1592();return;
            }
            if(phase==-1){command(c,"view outside");next();return;}
            if(phase==0){if(seconds()<65)return;command(c,"natural");capture(c,"outside-normal-overworld.png");command(c,"bedtime");phase=20;changed=System.nanoTime();return;}
            if(phase==20){
                if(seconds()<3)return;var bed=new class_2338(JourneyClient.x+400,c.field_1724.method_31478(),JourneyClient.z+70);
                c.field_1761.method_2896(c.field_1724,class_1268.field_5808,new class_3965(class_243.method_24953(bed),class_2350.field_11036,bed,false));observedSleep=false;phase=21;changed=System.nanoTime();return;
            }
            if(phase==21){
                observedSleep|=c.field_1724.method_6113();if(c.field_1724.method_6113()||!observedSleep){if(seconds()>30)throw new IllegalStateException("Real bed sleep did not complete");return;}
                if(++sleeps<2){command(c,"bedtime");phase=20;changed=System.nanoTime();return;}
                if(!c.field_1724.method_31548().method_7379(new net.minecraft.class_1799(Journey.ECHO)))throw new IllegalStateException("Two real sleeps did not deliver guide");
                var dream=new JsonObject();dream.addProperty("actual_bed_sleeps",sleeps);dream.addProperty("guide_received",true);write("dreams.json",dream);
                for(int i=0;i<9;i++)if(c.field_1724.method_31548().method_5438(i).method_31574(Journey.ECHO))c.field_1724.method_31548().field_7545=i;
                c.field_1761.method_2919(c.field_1724,class_1268.field_5808);command(c,"view approach");phase=17;changed=System.nanoTime();return;
            }
            if(phase==17){if(!surfaceWalk(c,true))return;c.field_1724.method_36456(180);c.field_1724.method_36457(8);phase=1;changed=System.nanoTime();return;}
            if(phase==18){if(!surfaceWalk(c,false))return;capture(c,"surface-walk-exit.png");phase=19;changed=System.nanoTime();return;}
            if(phase==19){if(!surfaceWalk(c,true))return;bell(c,true);phase=7;changed=System.nanoTime();return;}
            if(phase==1){if(seconds()<18||!queues(c))return;capture(c,"surface-station.png");bell(c,true);next();return;}
            if(phase==2){if(!c.field_1724.method_5765()){if(seconds()>12)throw new IllegalStateException("Upper bell did not board");return;}next();return;}
            if(phase==3){
                if(!midShot&&c.field_1724.method_23318()<JourneyClient.entryY-10){capture(c,"cabin-descent.png");midShot=true;}
                if(!lowShot&&c.field_1724.method_23318()<72){c.field_1724.method_36456(-140);c.field_1724.method_36457(8);capture(c,"cabin-cavern-arrival.png");lowShot=true;}
                if(!exteriorShot&&photoCamera==null&&c.field_1724.method_5765()&&c.field_1724.method_23318()<66){
                    // Detached photography camera only; the real passenger remains seated and the server car keeps moving.
                    photoCamera=new net.minecraft.class_1531(c.field_1687,0,0,0);
                    photoCamera.method_5808(JourneyClient.x-9.5,c.field_1724.method_23318()+2,JourneyClient.z+60.5,-45,18);
                    photoCamera.field_5982=photoCamera.method_36454();photoCamera.field_6004=photoCamera.method_36455();photoCamera.field_6241=photoCamera.field_6259=-45;photoCamera.field_6283=photoCamera.field_6220=-45;
                    c.method_1504(photoCamera);exteriorAt=System.nanoTime();
                }
                if(photoCamera!=null&&System.nanoTime()-exteriorAt>1_000_000_000L){capture(c,"phantom-car-exterior.png");exteriorShot=true;c.method_1504(c.field_1724);photoCamera=null;}
                if(c.field_1724.method_5765()){if(seconds()>150)throw new IllegalStateException("Descent did not finish");return;}
                checkLanding(c,false);phase=16;changed=System.nanoTime();return;
            }
            if(phase==16){if(seconds()<2)return;capture(c,"lower-arrival.png");leg=0;startX=c.field_1724.method_23317();startZ=c.field_1724.method_23321();phase=4;changed=System.nanoTime();return;}
            if(phase==4){
                if(leg>=WALK.length){c.field_1690.field_1894.method_23481(false);bell(c,false);next();return;}
                double tx=JourneyClient.x+WALK[leg][0],tz=JourneyClient.z+WALK[leg][1],dx=tx-c.field_1724.method_23317(),dz=tz-c.field_1724.method_23321();
                c.field_1724.method_36456((float)Math.toDegrees(Math.atan2(-dx,dz)));c.field_1724.method_36457(0);c.field_1690.field_1894.method_23481(true);
                if(Math.hypot(dx,dz)>.38&&seconds()<35)return;
                c.field_1690.field_1894.method_23481(false);boolean pass=Math.hypot(dx,dz)<=.5&&Math.abs(c.field_1724.method_23318()-45)<.15&&!c.field_1724.method_31549().field_7479;
                var r=new JsonObject();r.addProperty("leg",leg);r.addProperty("start_x",startX);r.addProperty("start_z",startZ);r.addProperty("end_x",c.field_1724.method_23317());r.addProperty("end_z",c.field_1724.method_23321());r.addProperty("end_y",c.field_1724.method_23318());r.addProperty("forward_seconds",seconds());r.addProperty("pass",pass);walks.add(r);write("walk.json",walks);
                if(!pass)throw new IllegalStateException("Walking blocked: "+r);
                if(leg==7)capture(c,"walk-bridge.png");if(NATURAL&&leg==8)capture(c,"walk-library.png");if(leg==(NATURAL?13:11))capture(c,"walk-town.png");
                leg++;startX=c.field_1724.method_23317();startZ=c.field_1724.method_23321();changed=System.nanoTime();return;
            }
            if(phase==5){if(!c.field_1724.method_5765()){if(seconds()>12)throw new IllegalStateException("Lower bell did not board");return;}next();return;}
            if(phase==6){if(c.field_1724.method_5765()){if(seconds()>150)throw new IllegalStateException("Return did not finish");return;}checkLanding(c,true);capture(c,"surface-return.png");phase=18;changed=System.nanoTime();return;}
            if(phase==7){if(seconds()<8)return;if(!c.field_1724.method_5765())throw new IllegalStateException("Emergency test failed to board");c.field_1690.field_1832.method_23481(true);next();return;}
            if(phase==8){if(seconds()<3)return;c.field_1690.field_1832.method_23481(false);if(c.field_1724.method_5765())throw new IllegalStateException("Emergency dismount still riding");checkLanding(c,true);capture(c,"emergency-safe-return.png");command(c,"view street");next();return;}
            if(phase>=9&&phase<=12){
                if(seconds()<18||!queues(c))return;
                String[] names={"town-street.png","naturalized-cliff.png","overworld-town-overview.png","surface-entrance-overview.png"};capture(c,names[phase-9]);
                if(phase==9)command(c,"view cliff");if(phase==10)command(c,"view overview");if(phase==11)command(c,"view surface");
                if(phase==12&&NATURAL){command(c,"view bridge-destination");phase=30;changed=System.nanoTime();return;}next();return;
            }
            if(phase>=30&&phase<=35){
                if(seconds()<18||!queues(c))return;
                String[] names={"bridge-destination.png","library-interior.png","residence-bedroom.png","contained-water.png","side-cave.png","natural-floor.png"};
                String[] next={"library","bedroom","water","west-cave","floor"};capture(c,names[phase-30]);
                if(phase<35){command(c,"view "+next[phase-30]);phase++;}else phase=13;
                changed=System.nanoTime();return;
            }
            if(phase==13){
                if(NATURAL){command(c,"debugcheck");write("cabin-motion.json",motion);}
                command(c,"audit client");command(c,"intrusion");write("rides.json",rides);
                var r=new JsonObject();r.addProperty("pass",true);r.addProperty("real_bell_interactions",4);r.addProperty("real_walking_legs",walks.size());r.addProperty("real_surface_access_walks",accesses.size());r.addProperty("native_dimension","minecraft:overworld");r.addProperty("method","Bell right clicks, server-authoritative cabin rides, actual forward-key walking; Operator placement at the native-ground approach endpoint and photographic positions after round trip; actual stair walking enters and leaves the station; detached client camera for one exterior frame does not move the seated passenger.");write("journey.json",r);
                command(c,"view entrance");next();return;
            }
            if(phase==14){if(seconds()<12)return;bell(c,true);next();return;}
            if(phase==15){
                if(seconds()<10)return;if(!c.field_1724.method_5765())throw new IllegalStateException("Restart test did not board");
                if(!restartReady){var restart=new JsonObject();restart.addProperty("riding_before_stop",true);restart.addProperty("y",c.field_1724.method_23318());write("restart-ready.json",restart);restartReady=true;}
                if(seconds()>90)throw new IllegalStateException("Server did not stop for recovery test");
            }
        }catch(Exception e){var failure=new JsonObject();failure.addProperty("phase",phase);failure.addProperty("error",e.toString());if(c.field_1687!=null)failure.addProperty("chunk_debug",c.field_1769.method_3289());write("failure.json",failure);e.printStackTrace();finished=true;c.field_1690.field_1894.method_23481(false);c.field_1690.field_1832.method_23481(false);System.err.println("ABYSS_PHASE7_FAILED");c.method_1592();}
    }
    private boolean surfaceWalk(class_310 c,boolean inward){
        double x=JourneyClient.x+(inward?6.5:9.5+JourneyClient.approachLength),z=JourneyClient.z+70.5;
        double y=inward?JourneyClient.entryY+1:JourneyClient.approachY+1,dx=x-c.field_1724.method_23317(),dz=z-c.field_1724.method_23321();
        c.field_1724.method_36456((float)Math.toDegrees(Math.atan2(-dx,dz)));c.field_1724.method_36457(0);
        boolean reached=Math.hypot(dx,dz)<.4&&Math.abs(c.field_1724.method_23318()-y)<.6;
        c.field_1690.field_1894.method_23481(!reached);
        if(!reached){if(seconds()>60)throw new IllegalStateException("Surface stairs blocked at "+c.field_1724.method_19538()+" target "+x+","+y+","+z);return false;}
        if(c.field_1724.method_6032()!=20||c.field_1724.method_31549().field_7479)throw new IllegalStateException("Surface access was not safe walking");
        var r=new JsonObject();r.addProperty("inward",inward);r.addProperty("seconds",seconds());r.addProperty("x",c.field_1724.method_23317());r.addProperty("y",c.field_1724.method_23318());r.addProperty("z",c.field_1724.method_23321());r.addProperty("health",c.field_1724.method_6032());r.addProperty("pass",true);accesses.add(r);write("surface-access.json",accesses);return true;
    }
    private void checkLanding(class_310 c,boolean upper){
        boolean pass=Math.abs(c.field_1724.method_23317()-(JourneyClient.x+6.5))<.2&&Math.abs(c.field_1724.method_23321()-(JourneyClient.z+70.5))<.2&&Math.abs(c.field_1724.method_23318()-(upper?JourneyClient.entryY+1:45))<.3&&c.field_1724.method_6032()>0&&!c.field_1724.method_5765();
        var r=new JsonObject();r.addProperty("upper",upper);r.addProperty("x",c.field_1724.method_23317());r.addProperty("y",c.field_1724.method_23318());r.addProperty("z",c.field_1724.method_23321());r.addProperty("health",c.field_1724.method_6032());r.addProperty("pass",pass);rides.add(r);if(!pass)throw new IllegalStateException("Unsafe landing "+r);
    }
    private boolean queues(class_310 c){
        boolean idle=c.field_1769.method_3289().matches(".*pC: 0+, pU: 0+(?:,|\\s|$).*");
        if(!idle&&seconds()>150)throw new IllegalStateException("Chunk queues did not drain: "+c.field_1769.method_3289());
        return idle;
    }
    private void capture(class_310 c,String file)throws Exception{
        Files.createDirectories(OUT);try(var frame=class_318.method_1663(c.method_1522())){frame.method_4314(OUT.resolve(file));}
        var r=new JsonObject();r.addProperty("file",file);r.addProperty("x",c.field_1724.method_23317());r.addProperty("y",c.field_1724.method_23318());r.addProperty("z",c.field_1724.method_23321());r.addProperty("yaw",c.field_1724.method_36454());r.addProperty("pitch",c.field_1724.method_36455());r.addProperty("riding",c.field_1724.method_5765());r.addProperty("health",c.field_1724.method_6032());r.addProperty("dimension",c.field_1687.method_27983().method_29177().toString());r.addProperty("chunk_debug",c.field_1769.method_3289());r.addProperty("detached_photo_camera",c.method_1560()!=c.field_1724);r.addProperty("camera_position",c.field_1773.method_19418().method_19326().toString());r.addProperty("camera_yaw",c.field_1773.method_19418().method_19330());r.addProperty("camera_pitch",c.field_1773.method_19418().method_19329());r.addProperty("gl_error",GL11.glGetError());r.addProperty("renderer",GL11.glGetString(GL11.GL_RENDERER));r.add("environment",EnvironmentClient.measurements());frames.add(r);write("captures.json",frames);
    }
    private void write(String name,Object value){try{Files.createDirectories(OUT);Files.writeString(OUT.resolve(name),new GsonBuilder().setPrettyPrinting().create().toJson(value));}catch(Exception e){throw new IllegalStateException(e);}}
}
