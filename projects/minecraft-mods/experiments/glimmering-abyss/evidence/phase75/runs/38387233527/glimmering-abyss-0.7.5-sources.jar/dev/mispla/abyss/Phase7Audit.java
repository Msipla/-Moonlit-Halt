package dev.mispla.abyss;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1311;
import net.minecraft.class_1642;
import net.minecraft.class_1928;
import net.minecraft.class_1934;
import net.minecraft.class_1944;
import net.minecraft.class_2168;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.List;
import static net.minecraft.class_2170.method_9247;
import static net.minecraft.class_2170.method_9244;

/** Explicit, isolated-runtime diagnostics; none of these commands is a survival travel mechanism. */
public final class Phase7Audit {
    private static class_1308 entering;
    private static long enteredAt;
    private Phase7Audit(){}
    public static void initialize(){
        CommandRegistrationCallback.EVENT.register((d,a,e)->d.register(method_9247("abyss").then(method_9247("phase7")
            .requires(s->s.method_9259(2)&&Boolean.getBoolean("abyss.testServer"))
            .then(method_9247("status").executes(c->status(c.getSource())))
            .then(method_9247("audit").then(method_9244("label",StringArgumentType.word()).executes(c->audit(c.getSource(),StringArgumentType.getString(c,"label")))))
            .then(method_9247("view").then(method_9244("name",StringArgumentType.word()).executes(c->view(c.getSource(),StringArgumentType.getString(c,"name")))))
            .then(method_9247("intrusion").executes(c->intrusion(c.getSource())))
            .then(method_9247("natural").executes(c->natural(c.getSource())))
            .then(method_9247("bedtime").executes(c->bedtime(c.getSource())))
            .then(method_9247("debugcheck").executes(c->debugcheck(c.getSource())))
            .then(method_9247("dream").executes(c->{Journey.dream(c.getSource().method_9207());return 1;}))
        )));
        ServerTickEvents.END_SERVER_TICK.register(server->{
            if(entering!=null&&server.method_30002().method_8510()>enteredAt+5){
                var r=new JsonObject();r.addProperty("removed_after_crossing",entering.method_31481());r.addProperty("ticks",server.method_30002().method_8510()-enteredAt);
                write("intrusion",r);if(!entering.method_31481())entering.method_31472();entering=null;
            }
        });
    }
    private static int debugcheck(class_2168 source)throws com.mojang.brigadier.exceptions.CommandSyntaxException{
        var p=source.method_9207();var old=p.field_13974.method_14257();boolean flying=p.method_31549().field_7479;
        boolean denied=false,allowed=false;var dispatcher=source.method_9211().method_3734().method_9235();
        try{
            p.method_7336(class_1934.field_9215);
            try{dispatcher.execute("abyss debug status",p.method_5671());}catch(com.mojang.brigadier.exceptions.CommandSyntaxException ex){denied=true;}
            p.method_7336(class_1934.field_9220);allowed=dispatcher.execute("abyss debug status",p.method_5671())==1;
        }finally{p.method_7336(old);p.method_31549().field_7479=flying;p.method_7355();}
        var r=new JsonObject();r.addProperty("survival_player_denied",denied);r.addProperty("creative_player_allowed",allowed);r.addProperty("pass",denied&&allowed);write("debug-permissions",r);return denied&&allowed?1:0;
    }
    static void write(String name,JsonObject r){try{Files.createDirectories(Path.of("abyss-results"));Files.writeString(Path.of("abyss-results/phase7-"+name+".json"),new GsonBuilder().setPrettyPrinting().create().toJson(r));}catch(Exception e){throw new IllegalStateException(e);}}
    private static JsonObject state(class_3218 w){var s=OverworldSite.get(w);var r=new JsonObject();r.addProperty("layout",s.layout);r.addProperty("seed",w.method_8412());r.addProperty("stage",s.stage);r.addProperty("x",s.x);r.addProperty("z",s.z);r.addProperty("entry_y",s.entryY);r.addProperty("approach_length",s.approachLength);r.addProperty("approach_y",s.approachY);r.addProperty("attempt",s.attempt);r.addProperty("cursor",s.cursor);r.addProperty("reason",s.reason);r.addProperty("unfinished_rides",s.journeys.size());return r;}
    private static int status(class_2168 source){var r=state(source.method_9211().method_30002());write("status",r);source.method_9226(()->class_2561.method_43470(r.toString()),false);return 1;}
    private static int view(class_2168 source,String name)throws com.mojang.brigadier.exceptions.CommandSyntaxException{
        var w=source.method_9211().method_30002();var s=OverworldSite.get(w);if(!s.ready())return 0;
        var p=source.method_9207();p.method_7336(class_1934.field_9215);p.method_31549().field_7479=false;p.method_7355();
        double x=6.5,y=s.entryY+1,z=70.5;float yaw=180,pitch=8;
        switch(name){
            case "library" -> {x=-47.5;y=45;z=38.5;yaw=120;pitch=8;}
            case "bridge-destination" -> {x=-29.5;y=45;z=35.5;yaw=90;pitch=-5;}
            case "bedroom" -> {x=38.5;y=51;z=-10.5;yaw=180;pitch=10;}
            case "water" -> {x=76.5;y=46;z=-27.5;yaw=180;pitch=30;}
            case "west-cave" -> {x=-83.5;y=36;z=-52.5;yaw=-35;pitch=8;p.method_7336(class_1934.field_9220);p.method_31549().field_7479=true;p.method_7355();}
            case "floor" -> {x=-4.5;y=0;z=42.5;yaw=180;pitch=45;p.method_7336(class_1934.field_9220);p.method_31549().field_7479=true;p.method_7355();}
            case "approach" -> {x=9.5+s.approachLength;y=s.approachY+1;z=70.5;yaw=90;pitch=0;}
            case "lower" -> y=45;
            case "street" -> {x=47.5;y=45;z=4.5;yaw=180;pitch=-9;}
            case "cliff" -> {x=-47.5;y=28;z=17.5;yaw=-90;pitch=8;p.method_7336(class_1934.field_9220);p.method_31549().field_7479=true;p.method_7355();}
            case "overview" -> {x=-31.5;y=66;z=60.5;yaw=-135;pitch=18;p.method_7336(class_1934.field_9220);p.method_31549().field_7479=true;p.method_7355();}
            case "surface" -> {x=17;y=s.entryY+7;z=85;yaw=140;pitch=20;p.method_7336(class_1934.field_9220);p.method_31549().field_7479=true;p.method_7355();}
            case "outside" -> {x=400.5;z=70.5;y=OverworldLandscape.surface(w,class_2902.class_2903.field_13203,s.x+400,s.z+70)+1;w.method_29199(18000);p.method_7336(class_1934.field_9220);}
            case "entrance" -> {}
            default -> {return 0;}
        }
        p.method_14251(w,s.x+x,y,s.z+z,yaw,pitch);p.method_6033(20);p.method_7344().method_7580(20);return 1;
    }
    private static int bedtime(class_2168 source)throws com.mojang.brigadier.exceptions.CommandSyntaxException{
        var w=source.method_9211().method_30002();var s=OverworldSite.get(w);int x=s.x+400,z=s.z+70;
        int y=OverworldLandscape.surface(w,class_2902.class_2903.field_13203,x,z);
        for(int dx=-2;dx<=3;dx++)for(int dz=-2;dz<=3;dz++){
            w.method_8501(new class_2338(x+dx,y-1,z+dz),class_2246.field_10340.method_9564());
            for(int h=0;h<4;h++)w.method_8501(new class_2338(x+dx,y+h,z+dz),class_2246.field_10124.method_9564());
        }
        var bed=class_2246.field_10527.method_9564().method_11657(net.minecraft.class_2244.field_11177,net.minecraft.class_2350.field_11035);
        w.method_8501(new class_2338(x,y,z),bed.method_11657(net.minecraft.class_2244.field_9967,net.minecraft.class_2742.field_12557));
        w.method_8501(new class_2338(x,y,z+1),bed.method_11657(net.minecraft.class_2244.field_9967,net.minecraft.class_2742.field_12560));
        w.method_29199((w.method_8532()/24000+1)*24000+13000);
        var player=source.method_9207();player.method_14251(w,x+1.5,y,z+.5,90,40);return 1;
    }
    private static int intrusion(class_2168 source){
        var w=source.method_9211().method_30002();var s=OverworldSite.get(w);
        entering=class_1299.field_6051.method_5883(w);entering.method_5814(s.x+115,45,s.z+70);w.method_8649(entering);
        entering.method_5814(s.x+6,45,s.z+70);enteredAt=w.method_8510();return 1;
    }
    private static int natural(class_2168 source){
        var w=source.method_9211().method_30002();int outside=0,inside=0;var r=new JsonObject();var a=new JsonArray();
        for(var e:w.method_27909())if(e instanceof class_1308&&e.method_5864().method_5891()==class_1311.field_6302){
            if(SceneSafety.protects(w,e.method_23317(),e.method_23318(),e.method_23321()))inside++;else{outside++;var row=new JsonObject();row.addProperty("type",class_1299.method_5890(e.method_5864()).toString());row.addProperty("x",e.method_23317());row.addProperty("y",e.method_23318());row.addProperty("z",e.method_23321());a.add(row);}
        }
        r.addProperty("outside_loaded_monsters",outside);r.addProperty("inside_loaded_monsters",inside);r.add("outside_entities",a);r.addProperty("doMobSpawning",w.method_8450().method_8355(class_1928.field_19390));r.addProperty("difficulty",w.method_8407().method_5460());write("natural",r);return 1;
    }
    private static int audit(class_2168 source,String label){
        if(!label.matches("[a-zA-Z0-9_-]{1,32}"))return 0;
        try{
            var w=source.method_9211().method_30002();var s=OverworldSite.get(w);var r=state(w);if(!s.ready()){write(label,r);return 0;}
            var n=w.method_14183().method_15094(GlimmeringAbyss.id("town")).orElseThrow().method_15175(new class_2487());
            var pal=n.method_10554("palette",class_2520.field_33260);var blocks=n.method_10554("blocks",class_2520.field_33260);
            int windows=0,lit=0,preserved=0;var digest=MessageDigest.getInstance("SHA-256");
            for(int i=0;i<blocks.size();i++){
                var b=blocks.method_10602(i);var xyz=b.method_10554("pos",class_2520.field_33253);int x=xyz.method_10600(0)-55,y=xyz.method_10600(1)-63,z=xyz.method_10600(2)-106;
                String expected=pal.method_10602(b.method_10550("state")).method_10558("Name");
                if(expected.equals("glimmeringabyss:warm_window")){windows++;var p=s.at(x,y,z);if(w.method_8320(p).method_27852(GlimmeringAbyss.WARM_WINDOW))preserved++;if(w.method_8314(class_1944.field_9282,p)==12)lit++;}
            }
            int capMatches=0;for(int i=0;i<OverworldSite.CHUNKS;i++){String cap=OverworldLandscape.capHash(w,s,s.x/16-7+i%14,s.z/16-11+i/14);if(i<s.caps.size()&&s.caps.get(i).equals(cap))capMatches++;}
            r.addProperty("unchanged_surface_and_bedrock_chunks",capMatches);
            var surface=new JsonArray();
            for(int x=-104;x<112;x+=16)for(int z=-168;z<112;z+=16){
                int y=OverworldLandscape.surface(w,class_2902.class_2903.field_13200,s.x+x,s.z+z);
                var row=new JsonObject();row.addProperty("local_x",x);row.addProperty("local_z",z);row.addProperty("y",y);
                row.addProperty("top",w.method_8320(new class_2338(s.x+x,y-1,s.z+z)).toString());row.addProperty("second",w.method_8320(new class_2338(s.x+x,y-2,s.z+z)).toString());surface.add(row);
            }
            r.add("native_surface_samples",surface);
            int samples=0;for(int x=-108;x<108;x+=9)for(int z=-172;z<108;z+=9)for(int y=-63;y<=105;y+=7){
                if(y>OverworldLandscape.ceiling(s,x,z)-OverworldSite.OFFSET_Y)continue;
                digest.update(w.method_8320(s.at(x,y,z)).toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));samples++;
            }
            for(int step=0;step<=s.approachLength;step++){
                int y=s.entryY+(int)Math.round((s.approachY-s.entryY)*step/(double)s.approachLength);
                int next=step==s.approachLength?y:s.entryY+(int)Math.round((s.approachY-s.entryY)*(step+1)/(double)s.approachLength),base=y+(next>y?1:0);
                for(int z=68;z<=72;z++)for(int h=0;h<=4;h++){
                    digest.update(w.method_8320(new class_2338(s.x+9+step,base+h,s.z+z)).toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));samples++;
                }
            }
            var attempts=new JsonArray();boolean blocked=true;
            for(int[] point:new int[][]{{47,45,4},{-40,26,-60},{4,45,35},{0,-54,-20},{0,85,70},{6,s.entryY+2,70},{9+s.approachLength/2,Math.max(s.entryY,s.approachY)+2,70},{-111,20,-175},{110,20,110}}){
                for(var type:List.of(class_1299.field_6051,class_1299.field_6137,class_1299.field_6046,class_1299.field_6078,class_1299.field_6108,class_1299.field_6085)){
                    var mob=type.method_5883(w);mob.method_5814(s.x+point[0]+.5,point[1],s.z+point[2]+.5);boolean accepted=w.method_8649(mob);blocked&=!accepted;
                    var row=new JsonObject();row.addProperty("type",class_1299.method_5890(type).toString());row.addProperty("local_x",point[0]);row.addProperty("y",point[1]);row.addProperty("local_z",point[2]);row.addProperty("accepted",accepted);attempts.add(row);if(accepted)mob.method_31472();
                }
            }
            boolean outside=true;for(int[] q:new int[][]{{-114,20,-50},{114,20,-50},{0,20,-179},{0,20,114},{40,130,0},{0,-60,0}}){
                var mob=class_1299.field_6051.method_5883(w);mob.method_5814(s.x+q[0],q[1],s.z+q[2]);outside&=w.method_8649(mob)&&!mob.method_31481();mob.method_31472();
            }
            int sceneMobs=0;for(var e:w.method_27909())if(e instanceof class_1308&&SceneSafety.protects(w,e.method_23317(),e.method_23318(),e.method_23321()))sceneMobs++;
            boolean bedrock=true;for(int x=-112;x<112;x+=16)for(int z=-176;z<112;z+=16)bedrock&=w.method_8320(new class_2338(s.x+x,-64,s.z+z)).method_27852(class_2246.field_9987);
            boolean shaft=true;for(int y=45;y<=s.entryY+3;y++)for(int x=-1;x<=1;x++)for(int z=69;z<=71;z++)shaft&=w.method_8320(new class_2338(s.x+x,y,s.z+z)).method_26220(w,new class_2338(s.x+x,y,s.z+z)).method_1110();
            r.addProperty("warm_windows",windows);r.addProperty("warm_windows_preserved",preserved);r.addProperty("warm_windows_native_12",lit);r.addProperty("bedrock_intact",bedrock);r.addProperty("shaft_clear",shaft);
            r.addProperty("geometry_sample_count",samples);r.addProperty("geometry_sha256",HexFormat.of().formatHex(digest.digest()));r.add("scene_spawn_attempts",attempts);r.addProperty("scene_insertions_blocked",blocked);r.addProperty("outside_boundary_insertions_allowed",outside);r.addProperty("loaded_scene_mobs",sceneMobs);
            r.addProperty("doMobSpawning",w.method_8450().method_8355(class_1928.field_19390));r.addProperty("difficulty",w.method_8407().method_5460());r.addProperty("dark_native_light",w.method_8314(class_1944.field_9282,s.at(0,-54,-20)));
            r.addProperty("surface_exact_required",label.equals("first")||label.equals("second"));
            boolean fluids=true;int water=0;
            if(s.layout>=75)for(int x=74;x<=78;x++)for(int z=-35;z<=-31;z++){
                var pos=s.at(x,38,z);if(w.method_8320(pos).method_27852(class_2246.field_10382))water++;
                fluids&=w.method_8320(pos.method_10074()).method_26212(w,pos.method_10074());
                for(var dir:List.of(net.minecraft.class_2350.field_11043,net.minecraft.class_2350.field_11035,net.minecraft.class_2350.field_11034,net.minecraft.class_2350.field_11039)){
                    var q=pos.method_10093(dir);fluids&=w.method_8320(q).method_27852(class_2246.field_10382)||w.method_8320(q).method_26212(w,q);
                }
            }
            r.addProperty("water_source_cells",water);r.addProperty("water_basin_contained",fluids);
            int structures=0,missing=0;
            if(s.layout>=75){
                var tn=w.method_14183().method_15094(GlimmeringAbyss.id("natural_town")).orElseThrow().method_15175(new class_2487());
                var tp=tn.method_10554("palette",class_2520.field_33260);var tb=tn.method_10554("blocks",class_2520.field_33260);
                for(int i=0;i<tb.size();i++){
                    var b=tb.method_10602(i);String id=tp.method_10602(b.method_10550("state")).method_10558("Name");if(id.equals("minecraft:air"))continue;
                    var xyz=b.method_10554("pos",class_2520.field_33253);var pos=s.at(xyz.method_10600(0)-64,xyz.method_10600(1)+34,xyz.method_10600(2)-106);
                    structures++;if(!net.minecraft.class_7923.field_41175.method_10221(w.method_8320(pos).method_26204()).toString().equals(id))missing++;
                }
            }
            r.addProperty("architectural_nonair_blocks",structures);r.addProperty("architectural_missing_or_wrong_blocks",missing);
            r.addProperty("player_witness_gold",w.method_8320(s.at(45,42,8)).method_27852(class_2246.field_10205));
            boolean natural=s.layout<75||water==25&&fluids&&missing==0;
            r.addProperty("pass",natural&&(!(label.equals("first")||label.equals("second"))||capMatches==OverworldSite.CHUNKS)&&windows==128&&preserved==128&&lit==128&&bedrock&&shaft&&blocked&&outside&&sceneMobs==0&&w.method_8450().method_8355(class_1928.field_19390));write(label,r);return r.get("pass").getAsBoolean()?1:0;
        }catch(Exception e){e.printStackTrace();return 0;}
    }
}
