package dev.mispla.abyss;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

/** Two seconds of an actual captured scene. Does not teleport or pause the world. */
public final class DreamScreen extends class_437 {
    public final int step;
    private final long opened=System.nanoTime();
    public DreamScreen(int step){super(class_2561.method_43470("梦中的微光"));this.step=step;}
    @Override public boolean method_25421(){return false;}
    @Override public void method_25393(){if(field_22787.field_1687==null||field_22787.field_1724==null||!field_22787.field_1724.method_5805()||System.nanoTime()-opened>2_000_000_000L)method_25419();}
    @Override public void method_25394(class_332 c,int mouseX,int mouseY,float delta){
        c.method_25294(0,0,field_22789,field_22790,0xff07101a);
        float scale=Math.max(field_22789/1280f,field_22790/720f);
        c.method_51448().method_22903();c.method_51448().method_46416((field_22789-1280*scale)/2,(field_22790-720*scale)/2,0);c.method_51448().method_22905(scale,scale,1);
        c.method_25290(GlimmeringAbyss.id("textures/gui/dream_"+step+".png"),0,0,0,0,1280,720,1280,720);c.method_51448().method_22909();
        c.method_27534(field_22793,class_2561.method_43470(step==1?"巨柱与冷蓝洞穴":"岩台上的暖窗"),field_22789/2,field_22790-22,0xffe4e8ed);
    }
}
