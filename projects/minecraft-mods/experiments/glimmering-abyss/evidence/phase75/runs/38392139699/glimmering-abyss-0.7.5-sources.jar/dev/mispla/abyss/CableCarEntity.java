package dev.mispla.abyss;

import dev.mispla.abyss.CableRoute.Point;
import java.util.List;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2604;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3230;

/** A seated closed cabin on a fixed route. The phantom is a harmless visual rig, not an attacking mob. */
public final class CableCarEntity extends class_1297 {
    public static final int DURATION=900;
    private boolean fromUpper,arriving;
    private int progress,topY,originX,originZ,layout;
    private double lerpX,lerpY,lerpZ;
    private int lerpTicks;
    public CableCarEntity(class_1299<? extends CableCarEntity> type,class_1937 w){super(type,w);method_5875(true);method_5684(true);}
    public void configure(OverworldSite s,boolean upper){originX=s.x;originZ=s.z;topY=s.entryY+1;layout=s.layout;fromUpper=upper;method_5814(s.x+.5,upper?topY:45,s.z+70.5);}
    @Override protected void method_5693(){}
    @Override protected void method_5749(class_2487 n){originX=n.method_10550("x");originZ=n.method_10550("z");topY=n.method_10550("top");layout=n.method_10545("layout")?n.method_10550("layout"):70;fromUpper=n.method_10577("upper");progress=n.method_10550("progress");}
    @Override protected void method_5652(class_2487 n){n.method_10569("layout",layout);n.method_10569("x",originX);n.method_10569("z",originZ);n.method_10569("top",topY);n.method_10556("upper",fromUpper);n.method_10569("progress",progress);}
    @Override public class_2596<class_2602> method_18002(){return new class_2604(this);}
    @Override protected boolean method_5818(class_1297 passenger){return passenger instanceof class_3222&&method_5685().isEmpty();}
    @Override public double method_5621(){return .2;}
    @Override public boolean method_5643(class_1282 source,float amount){return false;}
    @Override public boolean method_30948(){return true;}
    @Override public void method_5759(double x,double y,double z,float yaw,float pitch,int steps,boolean interpolate){
        // Base Entity snaps every network update. A vehicle needs client tick interpolation,
        // followed by the renderer's usual partial-tick interpolation, also for its passenger.
        lerpX=x;lerpY=y;lerpZ=z;lerpTicks=3;
    }
    @Override public void method_5773(){
        super.method_5773();if(method_37908().field_9236){
            if(lerpTicks>0){method_5814(method_23317()+(lerpX-method_23317())/lerpTicks,method_23318()+(lerpY-method_23318())/lerpTicks,method_23321()+(lerpZ-method_23321())/lerpTicks);lerpTicks--;}
            return;
        }
        if(!method_5782()){method_31472();return;}
        var w=(class_3218)method_37908();var s=OverworldSite.get(w);
        if(!s.ready()){abort();return;}
        double t=Math.min(1,++progress/(double)DURATION);
        var point=CableRoute.at(fromUpper?t:1-t,topY,layout);
        double x=originX+point.x(),y=point.y(),z=originZ+point.z();var pos=class_2338.method_49637(x,y,z);
        w.method_14178().method_17297(class_3230.field_19280,new class_1923(pos),3,pos);
        if(!w.method_8587(this,new net.minecraft.class_238(x-1.5,y,z-1.5,x+1.5,y+3.3,z+1.5))){abort();return;}
        method_5814(x,y,z);method_18799(class_243.field_1353);
        for(var e:method_5685())e.field_6017=0;
        if(progress>=DURATION){
            arriving=true;var passengers=java.util.List.copyOf(method_5685());method_5772();
            for(var e:passengers)if(e instanceof class_3222 p)Journey.land(p,s,!fromUpper);
            method_31472();
        }
    }
    private void abort(){var s=OverworldSite.get((class_3218)method_37908());arriving=true;var list=java.util.List.copyOf(method_5685());method_5772();for(var e:list)if(e instanceof class_3222 p)Journey.land(p,s,fromUpper);method_31472();}
    @Override protected void method_5793(class_1297 passenger){
        super.method_5793(passenger);
        if(!arriving&&!method_37908().field_9236&&passenger instanceof class_3222 p){
            Journey.queueLanding(p,fromUpper);method_31472();
        }
    }
}
