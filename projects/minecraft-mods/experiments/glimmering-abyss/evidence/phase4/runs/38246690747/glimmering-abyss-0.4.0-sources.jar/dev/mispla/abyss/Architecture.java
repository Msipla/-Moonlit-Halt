package dev.mispla.abyss;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import dev.mispla.abyss.GlimmeringAbyss.View;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.List;
import net.minecraft.class_1944;
import net.minecraft.class_2168;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3492;
import net.minecraft.class_3499;
import net.minecraft.class_7923;

/** One replaceable original structure in the study only; never modifies the generator. */
public final class Architecture {
    public static final class_2338 ORIGIN = new class_2338(22,-34,15);
    public static final List<GlimmeringAbyss.View> VIEWS = List.of(
        new GlimmeringAbyss.View("facade",42.5,39,57.5,180,-18),
        new GlimmeringAbyss.View("warmth",30.5,39,45.5,-145,-18),
        new GlimmeringAbyss.View("scale",-11.5,57,67.5,-145,5),
        new GlimmeringAbyss.View("bridge",27.5,39,70.5,-90,0),
        new GlimmeringAbyss.View("interior",42.5,39,35.5,180,0));
    private Architecture() {}
    private static class_3218 world(class_2168 s) {
        var w=s.method_9211().method_3847(GlimmeringAbyss.STUDY);
        if(w==null)throw new IllegalStateException("Study dimension missing");return w;
    }
    private static class_3499 template(class_3218 w) {
        return w.method_14183().method_15094(GlimmeringAbyss.id("workshop"))
            .orElseThrow(()->new IllegalStateException("Packaged workshop template missing"));
    }
    public static int place(class_2168 source) {
        try {
            var w=world(source);var t=template(w);
            // Explicit invocation also upgrades an old study save; deterministic replacement, no RNG entities.
            var data=new class_3492().method_15133(true).method_15131(true);
            if(!t.method_15172(w,ORIGIN,ORIGIN,data,w.field_9229,class_2248.field_31028|class_2248.field_31031))throw new IllegalStateException("Template placement failed");
            source.method_9226(()->class_2561.method_43470("[Abyss] Workshop ready. /abyss building view facade | /abyssrender blue"),false);
            return 1;
        } catch(Exception e){e.printStackTrace();source.method_9213(class_2561.method_43470(e.getMessage()));return 0;}
    }
    public static int view(class_2168 s,String name) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        var v=VIEWS.stream().filter(x->x.name().equals(name)).findFirst().orElse(null);
        if(v==null){s.method_9213(class_2561.method_43470("facade | warmth | scale | bridge | interior"));return 0;}
        var p=s.method_9207();if(name.equals("scale")&&!p.method_7337()){s.method_9213(class_2561.method_43470("Scale view requires Creative mode"));return 0;}
        p.method_31549().field_7479=name.equals("scale");p.method_7355();p.method_14251(world(s),v.x(),v.y(),v.z(),v.yaw(),v.pitch());return 1;
    }
    public static int audit(class_2168 s,String label) {
        try {
            if(!label.matches("[a-zA-Z0-9_-]{1,40}"))throw new IllegalArgumentException("Invalid label");
            var w=world(s);var n=template(w).method_15175(new class_2487());var palette=n.method_10554("palette",class_2520.field_33260);var list=n.method_10554("blocks",class_2520.field_33260);
            int mismatch=0,windows=0,lit=0,airMismatch=0;var digest=MessageDigest.getInstance("SHA-256");
            for(int i=0;i<list.size();i++) {
                var entry=list.method_10602(i);var xyz=entry.method_10554("pos",class_2520.field_33253);
                var pos=ORIGIN.method_10069(xyz.method_10600(0),xyz.method_10600(1),xyz.method_10600(2));String expected=palette.method_10602(entry.method_10550("state")).method_10558("Name");
                var actual=w.method_8320(pos);String id=class_7923.field_41175.method_10221(actual.method_26204()).toString();
                if(!expected.equals(id)){mismatch++;if(expected.equals("minecraft:air"))airMismatch++;}
                digest.update((pos.method_23854()+"="+id+"\n").getBytes(java.nio.charset.StandardCharsets.UTF_8));
                if(expected.equals("glimmeringabyss:warm_window")){windows++;if(actual.method_27852(GlimmeringAbyss.WARM_WINDOW)&&w.method_8314(class_1944.field_9282,pos)==12)lit++;}
            }
            boolean route=true;int samples=0;
            for(int x=22;x<=38;x++){var pos=new class_2338(x,39,70);route &= clear(w,pos);samples++;}
            for(int z=70;z>=41;z--){var pos=new class_2338(38,39,z);route &= clear(w,pos);samples++;}
            for(int x=38;x<=42;x++){var pos=new class_2338(x,39,42);route &= clear(w,pos);samples++;}
            for(int z=42;z>=34;z--){var pos=new class_2338(42,39,z);route &= clear(w,pos);samples++;}
            var result=new JsonObject();result.addProperty("label",label);result.addProperty("dimension",w.method_27983().method_29177().toString());
            result.addProperty("template_blocks_checked",list.size());result.addProperty("block_id_mismatches",mismatch);result.addProperty("air_clearance_mismatches",airMismatch);
            result.addProperty("actual_structure_block_id_sha256",HexFormat.of().formatHex(digest.digest()));result.addProperty("warm_window_blocks",windows);result.addProperty("warm_windows_native_light_12",lit);
            result.addProperty("route_samples",samples);result.addProperty("connected_route_floor_clearance_pass",route);result.addProperty("template_entities",n.method_10554("entities",class_2520.field_33260).size());
            result.addProperty("pass",mismatch==0&&windows>0&&windows==lit&&route);
            Path out=Path.of("abyss-results");Files.createDirectories(out);Files.writeString(out.resolve("architecture-"+label+".json"),new GsonBuilder().setPrettyPrinting().create().toJson(result));
            s.method_9226(()->class_2561.method_43470("[Abyss] Architecture "+label+" / "+result),false);return result.get("pass").getAsBoolean()?1:0;
        }catch(Exception e){e.printStackTrace();s.method_9213(class_2561.method_43470(e.getMessage()));return 0;}
    }
    private static boolean clear(class_3218 w,class_2338 pos){return w.method_8320(pos.method_10074()).method_26212(w,pos.method_10074())&&w.method_8320(pos).method_26215()&&w.method_8320(pos.method_10084()).method_26215();}
}
