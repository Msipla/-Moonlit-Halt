package dev.mispla.abyss;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2168;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public final class GlimmeringAbyss implements ModInitializer {
    public static final class_5321<class_1937> STUDY = class_5321.method_29179(class_7924.field_41223, id("study"));
    public static final class_2248 DARK = new class_2248(class_4970.class_2251.method_9630(class_2246.field_28888).method_9631(s -> 0));
    public static final class_2248 GLIMMER = new class_2248(class_4970.class_2251.method_9630(class_2246.field_28888).method_9631(s -> 5));
    public static final class_2248 REFERENCE = new class_2248(class_4970.class_2251.method_9630(class_2246.field_28888).method_9631(s -> 15));
    public static final class_2248 WARM_WINDOW = new class_2248(class_4970.class_2251.method_9630(class_2246.field_28888).method_9631(state -> 12));
    private static String mode = "glimmer";
    private static final java.util.Map<class_2338,class_2680> lampBackup=new java.util.HashMap<>();
    private static long ticks, tickStart;
    private static double tickSum, tickMax;
    private static int tickSamples;
    private static final List<Terrain.Fixture> FIXTURES = Terrain.fixtures(Terrain.SEED);

    public record View(String name, double x, double y, double z, float yaw, float pitch) {}
    public static final List<View> VIEWS = List.of(
            new View("tunnel", 0.5, 39, 90.5, 180, 0),
            new View("platform", 0.5, 39, 73.5, 180, 12),
            new View("edge", 20.5, 39, 66.5, 165, 15));
    public static final View OVERLOOK = new View("overlook",0.5,55,60.5,180,28);

    public static class_2960 id(String path) { return new class_2960("glimmeringabyss", path); }

    @Override public void onInitialize() {
        class_2378.method_10230(class_7923.field_41175, id("warm_window"), WARM_WINDOW);
        class_2378.method_10230(class_7923.field_41175, id("dark_marker"), DARK);
        class_2378.method_10230(class_7923.field_41175, id("glimmerstone"), GLIMMER);
        class_2378.method_10230(class_7923.field_41175, id("reference_marker"), REFERENCE);
        class_2378.method_10230(class_7923.field_41157, id("cavern"), AbyssChunkGenerator.field_24746);

        CommandRegistrationCallback.EVENT.register((dispatcher, access, environment) -> dispatcher.register(
                method_9247("abyss")
                .executes(c -> message(c.getSource(), "enter | view tunnel/platform/edge/overlook | light baseline/glimmer/reference | audit | return"))
                .then(method_9247("building").requires(s -> s.method_9259(2))
                    .executes(c -> Architecture.place(c.getSource()))
                    .then(method_9247("audit").then(method_9244("label", StringArgumentType.word()).executes(c -> Architecture.audit(c.getSource(), StringArgumentType.getString(c,"label")))))
                    .then(method_9247("view").then(method_9244("name", StringArgumentType.word())
                        .suggests((c,b) -> { Architecture.VIEWS.forEach(v -> b.suggest(v.name()));return b.buildFuture(); })
                        .executes(c -> Architecture.view(c.getSource(),StringArgumentType.getString(c,"name"))))))
                .then(method_9247("enter").executes(c -> teleport(c.getSource(), VIEWS.get(0))))
                .then(method_9247("view").then(method_9244("name", StringArgumentType.word())
                        .suggests((c, b) -> { VIEWS.forEach(v -> b.suggest(v.name)); b.suggest("overlook"); return b.buildFuture(); })
                        .executes(c -> {
                            String name = StringArgumentType.getString(c, "name");
                            View view = name.equals("overlook") ? OVERLOOK : VIEWS.stream().filter(v -> v.name.equals(name)).findFirst().orElse(null);
                            if (view == null) return message(c.getSource(), "Unknown view: " + name);
                            return teleport(c.getSource(), view);
                        })))
                .then(method_9247("light").requires(s -> s.method_9259(2))
                        .then(method_9244("mode", StringArgumentType.word())
                        .suggests((c, b) -> { for (String name : new String[]{"baseline", "glimmer", "reference"}) b.suggest(name); return b.buildFuture(); })
                        .executes(c -> changeLight(c.getSource(), StringArgumentType.getString(c, "mode")))))
                .then(method_9247("lamps").requires(s -> s.method_9259(2)).then(method_9244("state",StringArgumentType.word())
                        .executes(c -> calibrationLamps(c.getSource(),StringArgumentType.getString(c,"state")))))
                .then(method_9247("audit").requires(s -> s.method_9259(2)).executes(c -> audit(c.getSource(),""))
                        .then(method_9244("label",StringArgumentType.word()).executes(c -> audit(c.getSource(),StringArgumentType.getString(c,"label")))))
                .then(method_9247("return").executes(c -> {
                    class_3222 player = c.getSource().method_9207();
                    class_3218 world = c.getSource().method_9211().method_30002();
                    class_2338 pos = world.method_43126();
                    player.method_31549().field_7479 = false;
                    player.method_7355();
                    player.method_14251(world, pos.method_10263() + 0.5, pos.method_10264() + 1, pos.method_10260() + 0.5, 0, 0);
                    return 1;
                }))));

        // Test-only operator access is limited to the isolated localhost test server.
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            if (Boolean.getBoolean("abyss.testServer")) server.method_3760().method_14582(handler.field_14140.method_7334());
        });
        ServerTickEvents.START_SERVER_TICK.register(server -> tickStart = System.nanoTime());
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            double millis = (System.nanoTime() - tickStart) / 1e6;
            tickSum += millis; tickMax = Math.max(tickMax, millis); tickSamples++; ticks++;
            if (Boolean.getBoolean("abyss.testServer") && ticks % 20 == 0) {
                Path request = Path.of("abyss-command.txt");
                if (Files.isRegularFile(request)) try {
                    List<String> commands = Files.readAllLines(request); Files.delete(request);
                    for (String command : commands) {
                        if (command.equals("stop")) server.method_3747(false);
                        else if (command.startsWith("abyss ")) server.method_3734().method_44252(server.method_3739(), command);
                    }
                } catch (Exception error) { error.printStackTrace(); }
            }
        });
    }

    private static class_3218 study(MinecraftServer server) {
        class_3218 world = server.method_3847(STUDY);
        if (world == null) throw new IllegalStateException("Study dimension did not load; use Minecraft 1.20.1 with this mod's data enabled.");
        return world;
    }

    private static int message(class_2168 source, String text) {
        source.method_9226(() -> class_2561.method_43470("[Abyss] " + text), false);
        return 1;
    }

    private static int teleport(class_2168 source, View view) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        class_3222 player = source.method_9207();
        if (view == OVERLOOK && !player.method_7337()) return message(source, "Overlook requires Creative mode.");
        player.method_31549().field_7479 = view == OVERLOOK;
        player.method_7355();
        player.method_14251(study(source.method_9211()), view.x, view.y, view.z, view.yaw, view.pitch);
        return message(source, "View " + view.name + " / study seed " + Terrain.SEED);
    }

    private static int changeLight(class_2168 source, String requested) {
        class_2248 block = switch (requested) {
            case "baseline" -> DARK;
            case "glimmer" -> GLIMMER;
            case "reference" -> REFERENCE;
            default -> null;
        };
        if (block == null) return message(source, "Use baseline, glimmer or reference.");
        class_3218 world = study(source.method_9211());
        if (Boolean.getBoolean("abyss.testServer")) {
            // Without a player, unloaded light data reads as zero. Hold only the
            // sealed calibration lane and its sampled neighbor in this test runtime.
            world.method_17988(-5, 6, true);
            world.method_17988(-4, 6, true);
        }
        for (Terrain.Fixture fixture : FIXTURES) {
            world.method_8652(new class_2338(fixture.x(), fixture.y(), fixture.z()), block.method_9564(), class_2248.field_31036);
        }
        mode = requested;
        tickSum = tickMax = 0; tickSamples = 0;
        return message(source, "Light " + mode + " / " + FIXTURES.size() + " emitters. Wait for lighting/chunks to settle before audit.");
    }

    private static int calibrationLamps(class_2168 source,String state) {
        class_3218 world=study(source.method_9211());
        if(state.equals("on")) {
            for(int x:new int[]{-16,16})for(int z:new int[]{68,78}) {
                class_2338 pos=new class_2338(x,39,z);lampBackup.putIfAbsent(pos,world.method_8320(pos));
                world.method_8652(pos,class_2246.field_16541.method_9564(),class_2248.field_31036);
            }
        } else if(state.equals("off")) {
            lampBackup.forEach((pos,original)->world.method_8652(pos,original,class_2248.field_31036));lampBackup.clear();
        } else return message(source,"lamps on/off: temporary native lantern calibration only");
        return message(source,"Native calibration lanterns "+state);
    }

    private static int audit(class_2168 source,String label) {
        try {
            if(!label.matches("[a-zA-Z0-9_-]{0,40}"))throw new IllegalArgumentException("Invalid audit label");
            class_3218 world = study(source.method_9211());
            JsonObject result = new JsonObject();
            result.addProperty("minecraft", "1.20.1");
            result.addProperty("dimension", STUDY.method_29177().toString());
            result.addProperty("study_seed", Terrain.SEED);
            result.addProperty("world_seed", world.method_8412());
            result.addProperty("light_mode", mode);
            result.addProperty("emitter_count", FIXTURES.size());
            result.addProperty("dimension_has_skylight", world.method_8597().comp_642());
            result.addProperty("ambient_light", world.method_8597().comp_656());
            result.addProperty("calibration_chunks_kept_loaded_for_test_server", Boolean.getBoolean("abyss.testServer"));
            JsonArray profile = new JsonArray();
            int strength = mode.equals("reference") ? 15 : mode.equals("glimmer") ? 5 : 0;
            boolean lightPass = true;
            for (int distance = 0; distance <= 16; distance++) {
                class_2338 pos = new class_2338(-78 + distance, 41, 100);
                int block = world.method_8314(class_1944.field_9282, pos);
                int sky = world.method_8314(class_1944.field_9284, pos);
                JsonObject sample = new JsonObject();
                sample.addProperty("distance", distance); sample.addProperty("block", block); sample.addProperty("sky", sky);
                sample.addProperty("expected_unobstructed_block", Math.max(0, strength - distance));
                profile.add(sample);
                lightPass &= block == Math.max(0, strength - distance) && sky == 0;
            }
            result.add("light_profile", profile);
            result.addProperty("native_light_profile_pass", lightPass);

            JsonArray views = new JsonArray();
            boolean routePass = true;
            for (View view : VIEWS) {
                class_2338 foot = class_2338.method_49637(view.x, view.y, view.z);
                boolean floor = world.method_8320(foot.method_10074()).method_26212(world, foot.method_10074());
                boolean clearance = world.method_8320(foot).method_26215() && world.method_8320(foot.method_10084()).method_26215();
                JsonObject check = new JsonObject();
                check.addProperty("name", view.name); check.addProperty("x", view.x); check.addProperty("y", view.y); check.addProperty("z", view.z);
                check.addProperty("yaw", view.yaw); check.addProperty("pitch", view.pitch);
                check.addProperty("floor_solid", floor); check.addProperty("two_block_clearance", clearance);
                check.addProperty("block_light_at_feet", world.method_8314(class_1944.field_9282, foot));
                check.addProperty("sky_light_at_feet", world.method_8314(class_1944.field_9284, foot));
                routePass &= floor && clearance;
                views.add(check);
            }
            for (int z = 78; z <= 111; z++) {
                routePass &= world.method_8320(new class_2338(0, 38, z)).method_26212(world, new class_2338(0, 38, z));
                routePass &= world.method_8320(new class_2338(0, 39, z)).method_26215();
            }
            for (int x = -22; x <= 22; x++) for (int y = 39; y <= 40; y++) {
                routePass &= world.method_8320(new class_2338(x, y, 62)).method_27852(class_2246.field_10576);
                if (Math.abs(x) > 3) routePass &= world.method_8320(new class_2338(x, y, 77)).method_27852(class_2246.field_10576);
            }
            for (int z = 62; z <= 77; z++) for (int x : new int[]{-22, 22}) for (int y = 39; y <= 40; y++) {
                routePass &= world.method_8320(new class_2338(x, y, z)).method_27852(class_2246.field_10576);
            }
            result.add("views", views); result.addProperty("route_and_rail_pass", routePass);

            // Read generated world data, not the pure terrain function. Normalize lamp luminance only.
            Set<Long> lamps = FIXTURES.stream().map(f -> class_2338.method_10064(f.x(), f.y(), f.z())).collect(Collectors.toSet());
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            int samples = 0;
            for (int x = -104; x <= 104; x += 4) for (int z = -164; z <= 112; z += 4)
                for (int y = -64; y <= 124; y += 4) {
                    class_2338 pos = new class_2338(x, y, z);
                    String state = lamps.contains(pos.method_10063()) ? "fixture" : world.method_8320(pos).toString();
                    digest.update(state.getBytes(StandardCharsets.UTF_8)); digest.update((byte) 0); samples++;
                }
            result.addProperty("generated_world_sample_count", samples);
            result.addProperty("generated_terrain_sha256", HexFormat.of().formatHex(digest.digest()));
            result.addProperty("server_tick_samples_since_mode_change", tickSamples);
            result.addProperty("server_tick_mean_ms", tickSamples == 0 ? 0 : tickSum / tickSamples);
            result.addProperty("server_tick_max_ms", tickMax);
            result.addProperty("server_total_ticks", ticks);
            result.addProperty("lighting_pending_at_audit_end", world.method_14178().method_17293().method_15518());
            Path directory = Path.of("abyss-results"); Files.createDirectories(directory);
            Path path = directory.resolve("audit-" + mode + (label.isEmpty()?"":"-"+label) + ".json");
            Files.writeString(path, new GsonBuilder().setPrettyPrinting().create().toJson(result));
            message(source, "Audit " + path + " / light=" + lightPass + " route=" + routePass);
            return lightPass && routePass ? 1 : 0;
        } catch (Exception error) {
            error.printStackTrace();
            source.method_9213(class_2561.method_43470("[Abyss] Audit failed: " + error.getMessage()));
            return 0;
        }
    }
}
