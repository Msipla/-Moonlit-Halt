package dev.mispla.abyss;

import dev.mispla.abyss.Terrain.Fixture;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_765;
import net.minecraft.client.render.*;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/** Small depth-tested surface accents on existing sources, not additional illumination. */
final class GlowMarkers {
    private static final java.util.List<Terrain.Fixture> FIXTURES=Terrain.fixtures(Terrain.SEED);
    private static final class_1921 LAYER=class_1921.method_23026(new class_2960("minecraft","textures/block/white_concrete.png"));
    private static final class_4597.class_4598 BUFFER=class_4597.method_22991(new class_287(4096));
    static int facesDrawn;
    static void render(WorldRenderContext context) {
        facesDrawn=0;if(!EnvironmentClient.customActive()||EnvironmentClient.profile().glow()<=0)return;
        var matrices=context.matrixStack();var camera=context.camera().method_19326();matrices.method_22903();matrices.method_22904(-camera.field_1352,-camera.field_1351,-camera.field_1350);
        var matrix=matrices.method_23760().method_23761();var normal=matrices.method_23760().method_23762();var vertices=BUFFER.getBuffer(LAYER);float glow=EnvironmentClient.profile().glow();
        for(var f:FIXTURES) {
            var pos=new class_2338(f.x(),f.y(),f.z());if(!context.world().method_8320(pos).method_27852(GlimmeringAbyss.GLIMMER))continue;
            for(var direction:class_2350.values()) {
                if(!context.world().method_8320(pos.method_10093(direction)).method_26215())continue;facesDrawn++;
                float nx=direction.method_10148(),ny=direction.method_10164(),nz=direction.method_10165();
                float ux,uz,vy,vz;if(ny!=0){ux=1;uz=0;vy=0;vz=-ny;}else{ux=nz;uz=-nx;vy=1;vz=0;}
                float cx=f.x()+.5f+nx*.502f,cy=f.y()+.5f+ny*.502f,cz=f.z()+.5f+nz*.502f;
                for(int i=0;i<4;i++) {
                    float a=i==0||i==3?-.14f:.14f,b=i<2?-.14f:.14f;
                    vertices.method_22918(matrix,cx+ux*a,cy+vy*b,cz+uz*a+vz*b).method_22915(.18f*glow,.72f*glow,.76f*glow,1)
                            .method_22913(i==0||i==3?0:1,i<2?0:1).method_22922(class_4608.field_21444).method_22916(class_765.field_32767).method_23763(normal,nx,ny,nz).method_1344();
                }
            }
        }
        BUFFER.method_22994(LAYER);matrices.method_22909();EnvironmentClient.applyDistance();
    }
}
