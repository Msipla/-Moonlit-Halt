package dev.mispla.abyss.mixin;
import dev.mispla.abyss.EnvironmentClient;
import net.minecraft.class_4184;
import net.minecraft.class_5636;
import net.minecraft.class_758;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(class_758.class)
public abstract class DistanceMixin {
    @Inject(method="applyFog",at=@At("TAIL"))
    private static void abyss$distance(class_4184 camera,class_758.class_4596 type,float distance,boolean thick,float delta,CallbackInfo ci){
        if(EnvironmentClient.customActive()&&type==class_758.class_4596.field_20946&&camera.method_19334()==class_5636.field_27888)EnvironmentClient.applyDistance();
        if(type==class_758.class_4596.field_20946)EnvironmentClient.recordTerrainDistance();
    }
}
