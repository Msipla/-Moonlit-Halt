package dev.mispla.abyss;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import dev.mispla.abyss.GlimmeringAbyss.View;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1011;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_318;
import net.minecraft.class_412;
import net.minecraft.class_442;
import net.minecraft.class_5365;
import net.minecraft.class_639;
import net.minecraft.class_642;
import org.lwjgl.opengl.GL11;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Opt-in same-session real Minecraft framebuffer capture and movement checks. */
public final class Phase3CaptureClient implements ClientModInitializer {
    private record Case(String file,String profile,GlimmeringAbyss.View view,String light,String kind) {}
    private static final List<Case> CASES=cases();
    private static final Path OUT=Path.of("abyss-phase3-captures");
    private final JsonArray captures=new JsonArray();
    private final List<Double> frames=new ArrayList<>();
    private final JsonObject intervals=new JsonObject();
    private boolean connected,entered,finished,saved,walking,prepared;
    private int phase=-1,stability;
    private long started,phaseStarted,lastFrame,walkStarted;
    private double walkStartZ;
    private static List<Case> cases() {
        var result=new ArrayList<Case>();var views=new ArrayList<>(GlimmeringAbyss.VIEWS);views.add(GlimmeringAbyss.OVERLOOK);
        for(String p:new String[]{"blue","copper"})for(var v:views)result.add(new Case(p+"-"+v.name()+".png",p,v,"glimmer","comparison"));
        for(String p:new String[]{"blue","copper"})result.add(new Case(p+"-no-sources.png",p,GlimmeringAbyss.VIEWS.get(1),"baseline","natural_without_sources"));
        for(String p:new String[]{"blue-clear","blue-no-field"})result.add(new Case(p+"-platform.png",p,GlimmeringAbyss.VIEWS.get(1),"glimmer","ablation"));
        result.add(new Case("blue-reference.png","blue",GlimmeringAbyss.VIEWS.get(1),"reference","strong_native_light"));
        result.add(new Case("a-reference.png","a",GlimmeringAbyss.VIEWS.get(1),"reference","strong_native_light"));
        result.add(new Case("blue-lanterns.png","blue",GlimmeringAbyss.VIEWS.get(1),"glimmer","native_lanterns"));
        result.add(new Case("a-platform.png","a",GlimmeringAbyss.VIEWS.get(1),"glimmer","baseline"));
        result.add(new Case("a-tunnel.png","a",GlimmeringAbyss.VIEWS.get(0),"glimmer","baseline_queue_control"));
        result.add(new Case("overworld-blue.png","blue",null,"glimmer","dimension_scope"));
        result.add(new Case("overworld-a.png","a",null,"glimmer","dimension_scope"));return List.copyOf(result);
    }
    @Override public void onInitializeClient() {
        if(!Boolean.getBoolean("abyss.capture.phase3"))return;started=System.nanoTime();
        WorldRenderEvents.END.register(c->{long now=System.nanoTime();if(phase>=0&&phase<CASES.size()&&!saved&&now-phaseStarted>8_000_000_000L&&lastFrame!=0)frames.add((now-lastFrame)/1e6);lastFrame=now;});
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }
    private void tick(class_310 client) {
        if(finished)return;
        if(System.nanoTime()-started>1000_000_000_000L){fail(client,new IllegalStateException("Capture timeout"));return;}
        if(!connected&&client.field_1755!=null&&client.field_1755.getClass().getSimpleName().equals("AccessibilityOnboardingScreen"))client.method_1507(new class_442());
        if(!connected&&client.field_1755 instanceof class_442&&client.method_18506()==null) {
            connected=true;client.field_1690.method_42503().method_41748(16);client.field_1690.method_42510().method_41748(6);
            client.field_1690.method_41808().method_41748(75);client.field_1690.method_42473().method_41748(.5);client.field_1690.method_42524().method_41748(60);
            client.field_1690.method_42433().method_41748(false);client.field_1690.method_42534().method_41748(class_5365.field_25428);client.field_1690.method_41792().method_41748(true);
            client.field_1690.field_1837=false;client.field_1690.field_1842=true;client.field_1690.method_1640();
            String address="127.0.0.1:"+Integer.getInteger("abyss.port",25585);
            class_412.method_36877(new class_442(),client,class_639.method_2950(address),new class_642("Abyss phase 3 local test",address,false),false);return;
        }
        if(client.field_1724==null||client.field_1687==null||client.method_1562()==null)return;
        if(!entered){entered=true;command(client,"abyss enter");return;}
        if(phase==-1){if(EnvironmentClient.studyActive()&&ClientCommandManager.getActiveDispatcher()!=null)next(client);return;}
        if(phase>=CASES.size()){walk(client);return;}
        long elapsed=System.nanoTime()-phaseStarted;if(elapsed<13_000_000_000L)return;Case test=CASES.get(phase);
        if(!cQueuesReady(client)){if(elapsed<75_000_000_000L)return;fail(client,new IllegalStateException("Chunk queues did not drain: "+client.field_1769.method_3289()));return;}
        try {
            if(!saved) {
                screenshot(client,test.file);var times=new JsonArray();for(double value:frames)times.add(value);intervals.add(test.file,times);write("frame-intervals.json",intervals);captures.add(metadata(client,test));saved=true;write("captures.json",captures);
                if(test.kind.equals("comparison")&&test.view.name().equals("overlook"))command(client,"abyss audit "+test.profile);
                if(test.kind.equals("natural_without_sources"))command(client,"abyss audit no-sources-"+test.profile);
                if(test.file.equals("blue-platform.png"))stability=1;
            }
            if(stability>0&&test.file.equals("blue-platform.png")) {
                if(elapsed<13_000_000_000L+stability*600_000_000L)return;
                screenshot(client,"blue-platform-stability-"+stability+".png");if(stability++<2)return;
            }
            next(client);
        }catch(Exception e){fail(client,e);}
    }
    private JsonObject metadata(class_310 c,Case test) {
        var r=new JsonObject();r.addProperty("file",test.file);r.addProperty("kind",test.kind);r.addProperty("render_profile",test.profile);r.addProperty("light_mode",test.light);r.addProperty("view",test.view==null?"overworld":test.view.name());
        r.addProperty("x",c.field_1724.method_23317());r.addProperty("y",c.field_1724.method_23318());r.addProperty("z",c.field_1724.method_23321());r.addProperty("yaw",c.field_1724.method_36454());r.addProperty("pitch",c.field_1724.method_36455());
        r.addProperty("framebuffer_width",c.method_1522().field_1482);r.addProperty("framebuffer_height",c.method_1522().field_1481);
        r.addProperty("fov",c.field_1690.method_41808().method_41753());r.addProperty("brightness_gamma",c.field_1690.method_42473().method_41753());r.addProperty("view_distance_chunks",c.field_1690.method_42503().method_41753());r.addProperty("simulation_distance_chunks",c.field_1690.method_42510().method_41753());
        r.addProperty("graphics",c.field_1690.method_42534().method_41753().toString());r.addProperty("ambient_occlusion",c.field_1690.method_41792().method_41753());r.addProperty("dimension_ambient_light",c.field_1687.method_8597().comp_656());r.addProperty("dimension_fixed_time",c.field_1687.method_8597().comp_641().orElse(-1));
        r.addProperty("gl_renderer",GL11.glGetString(GL11.GL_RENDERER));r.addProperty("gl_vendor",GL11.glGetString(GL11.GL_VENDOR));r.addProperty("gl_version",GL11.glGetString(GL11.GL_VERSION));r.addProperty("gl_error_at_capture",GL11.glGetError());r.addProperty("chunk_debug",c.field_1769.method_3289());
        var foot=class_2338.method_49638(c.field_1724.method_19538());r.addProperty("block_light_at_feet",c.field_1687.method_8314(class_1944.field_9282,foot));r.addProperty("sky_light_at_feet",c.field_1687.method_8314(class_1944.field_9284,foot));r.add("environment",EnvironmentClient.measurements());r.add("space_lighting",SpaceLighting.measurements());
        if(SpaceLighting.active()&&SpaceLighting.measurements().get("terrain_shader_selections").getAsLong()==0)throw new IllegalStateException("New terrain shader never selected");
        r.addProperty("sample_frames",frames.size());r.addProperty("settle_seconds",8);r.addProperty("sample_seconds",5);
        if(!frames.isEmpty()) {
            double sum=frames.stream().mapToDouble(Double::doubleValue).sum();Collections.sort(frames);
            r.addProperty("sample_fps",frames.size()*1000/sum);r.addProperty("median_frame_ms",frames.get(frames.size()/2));r.addProperty("p95_frame_ms",frames.get((int)Math.floor((frames.size()-1)*.95)));r.addProperty("max_frame_ms",frames.get(frames.size()-1));r.addProperty("frames_over_100ms",frames.stream().filter(v->v>100).count());
        }return r;
    }
    private void next(class_310 client) {
        phase++;saved=false;stability=0;frames.clear();lastFrame=0;phaseStarted=System.nanoTime();if(phase>=CASES.size())return;
        var test=CASES.get(phase);selectWithCommand(client,test.profile);command(client,"abyss lamps "+(test.kind.equals("native_lanterns")?"on":"off"));command(client,"abyss light "+test.light);command(client,test.view==null?"abyss return":"abyss view "+test.view.name());
    }
    private boolean cQueuesReady(class_310 c) {
        return c.field_1769.method_3289().matches(".*pC: 0+, pU: 0+.*");
    }
    private void screenshot(class_310 client,String name)throws Exception {
        Files.createDirectories(OUT);try(var image=class_318.method_1663(client.method_1522())){image.method_4314(OUT.resolve(name));}System.out.println("ABYSS_PHASE3_CAPTURE_SAVED "+name);
    }
    private void write(String name,com.google.gson.JsonElement value)throws Exception {Files.writeString(OUT.resolve(name),new GsonBuilder().setPrettyPrinting().create().toJson(value));}
    private void walk(class_310 c) {
        if(!prepared){prepared=true;selectWithCommand(c,"blue");command(c,"abyss light glimmer");command(c,"abyss view tunnel");walkStarted=System.nanoTime();return;}
        long elapsed=System.nanoTime()-walkStarted;if(!walking&&elapsed>2_000_000_000L){walking=true;walkStartZ=c.field_1724.method_23321();c.field_1690.field_1894.method_23481(true);}if(elapsed<10_000_000_000L)return;
        c.field_1690.field_1894.method_23481(false);double z=c.field_1724.method_23321(),y=c.field_1724.method_23318();boolean pass=walkStartZ-z>20&&z>62.7&&z<64&&Math.abs(y-39)<.01;
        var r=new JsonObject();r.addProperty("method","Actual forward-key movement for 8 seconds under profile blue; stopped by existing iron rail.");r.addProperty("start_z",walkStartZ);r.addProperty("end_z",z);r.addProperty("end_y",y);r.addProperty("walk_and_collision_pass",pass);
        try{write("walk-collision.json",r);}catch(Exception e){fail(c,e);return;}finished=true;System.out.println("ABYSS_PHASE3_COMPLETE "+captures.size()+" walk_collision="+pass);c.method_1592();
    }
    private void selectWithCommand(class_310 c,String profile) {
        try {int result=ClientCommandManager.getActiveDispatcher().execute("abyssrender "+profile,(FabricClientCommandSource)c.method_1562().method_2875());if(result!=1||!EnvironmentClient.selectedName().equals(profile))throw new IllegalStateException("Bad command result");System.out.println("ABYSS_RENDER_COMMAND_DISPATCH "+profile+" result="+result);}catch(Exception e){throw new IllegalStateException(e);}
    }
    private void command(class_310 c,String text){c.method_1562().method_45730(text);}
    private void fail(class_310 c,Exception e){e.printStackTrace();finished=true;System.err.println("ABYSS_PHASE3_FAILED");c.method_1592();}
}
