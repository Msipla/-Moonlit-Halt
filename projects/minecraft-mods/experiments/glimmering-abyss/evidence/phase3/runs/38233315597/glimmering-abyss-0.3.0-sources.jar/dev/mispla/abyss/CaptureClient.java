package dev.mispla.abyss;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1011;
import net.minecraft.class_310;
import net.minecraft.class_318;
import net.minecraft.class_412;
import net.minecraft.class_442;
import net.minecraft.class_639;
import net.minecraft.class_642;
import org.lwjgl.opengl.GL11;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Opt-in dev capture harness; inactive in normal play. Reads the real game framebuffer. */
public final class CaptureClient implements ClientModInitializer {
    private static final String[] MODES = {"baseline", "glimmer", "reference"};
    private boolean connected, entered, finished;
    private int phase = -1;
    private long started, phaseStarted, lastFrame;
    private long walkStarted;
    private double walkStartZ;
    private boolean walking;
    private final List<Double> frameMillis = new ArrayList<>();
    private final JsonArray captures = new JsonArray();

    @Override public void onInitializeClient() {
        if (!Boolean.getBoolean("abyss.capture")) return;
        started = System.nanoTime();
        WorldRenderEvents.END.register(context -> {
            long now = System.nanoTime();
            if (phase >= 0 && now - phaseStarted > 8_000_000_000L && lastFrame != 0) {
                frameMillis.add((now - lastFrame) / 1e6);
            }
            lastFrame = now;
        });
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }

    private void tick(class_310 client) {
        if (finished) return;
        if (!connected && client.field_1755 != null
                && client.field_1755.getClass().getSimpleName().equals("AccessibilityOnboardingScreen")) {
            client.method_1507(new class_442());
        }
        if (System.nanoTime() - started > 600_000_000_000L) {
            finished = true;
            System.err.println("ABYSS_CAPTURE_FAILED timeout");
            client.method_1592();
            return;
        }
        if (!connected && client.field_1755 instanceof class_442 && client.method_18506() == null) {
            connected = true;
            client.field_1690.method_42503().method_41748(12);
            client.field_1690.method_42510().method_41748(6);
            client.field_1690.method_41808().method_41748(75);
            client.field_1690.method_42473().method_41748(0.5);
            client.field_1690.method_42524().method_41748(60);
            client.field_1690.method_42433().method_41748(false);
            client.field_1690.field_1837 = false;
            client.field_1690.field_1842 = true;
            client.field_1690.method_1640();
            String address = "127.0.0.1:" + Integer.getInteger("abyss.port", 25585);
            class_412.method_36877(new class_442(), client, class_639.method_2950(address),
                    new class_642("Abyss local test", address, false), false);
            return;
        }
        if (client.field_1724 == null || client.field_1687 == null || client.method_1562() == null) return;
        if (!entered) {
            entered = true;
            client.method_1562().method_45730("abyss enter");
            return;
        }
        if (!client.field_1687.method_27983().equals(GlimmeringAbyss.STUDY)) return;
        if (phase >= 9) { walkTest(client); return; }
        if (phase == -1) { next(client); return; }
        if (System.nanoTime() - phaseStarted < 13_000_000_000L) return;

        String mode = MODES[phase / 3];
        GlimmeringAbyss.View view = GlimmeringAbyss.VIEWS.get(phase % 3);
        try {
            Path out = Path.of("abyss-captures"); Files.createDirectories(out);
            String filename = mode + "-" + view.name() + ".png";
            try (class_1011 image = class_318.method_1663(client.method_1522())) {
                image.method_4314(out.resolve(filename));
            }
            JsonObject capture = new JsonObject();
            capture.addProperty("file", filename); capture.addProperty("light_mode", mode);
            capture.addProperty("view", view.name());
            capture.addProperty("x", client.field_1724.method_23317()); capture.addProperty("y", client.field_1724.method_23318()); capture.addProperty("z", client.field_1724.method_23321());
            capture.addProperty("yaw", client.field_1724.method_36454()); capture.addProperty("pitch", client.field_1724.method_36455());
            capture.addProperty("framebuffer_width", client.method_1522().field_1482);
            capture.addProperty("framebuffer_height", client.method_1522().field_1481);
            capture.addProperty("fov", client.field_1690.method_41808().method_41753());
            capture.addProperty("brightness_gamma", client.field_1690.method_42473().method_41753());
            capture.addProperty("view_distance_chunks", client.field_1690.method_42503().method_41753());
            capture.addProperty("simulation_distance_chunks", client.field_1690.method_42510().method_41753());
            capture.addProperty("graphics", client.field_1690.method_42534().method_41753().toString());
            capture.addProperty("ambient_occlusion", client.field_1690.method_41792().method_41753().toString());
            capture.addProperty("gl_renderer", GL11.glGetString(GL11.GL_RENDERER));
            capture.addProperty("gl_vendor", GL11.glGetString(GL11.GL_VENDOR));
            capture.addProperty("gl_version", GL11.glGetString(GL11.GL_VERSION));
            capture.addProperty("chunk_debug", client.field_1769.method_3289());
            capture.addProperty("sample_frames", frameMillis.size());
            capture.addProperty("measurement", "Real world-render frame intervals in a 5-second window after 8 seconds of settling; software GPU, not user hardware.");
            if (!frameMillis.isEmpty()) {
                double sum = frameMillis.stream().mapToDouble(Double::doubleValue).sum();
                Collections.sort(frameMillis);
                capture.addProperty("sample_fps", frameMillis.size() * 1000.0 / sum);
                capture.addProperty("median_frame_ms", frameMillis.get(frameMillis.size() / 2));
                capture.addProperty("p95_frame_ms", frameMillis.get((int) Math.floor((frameMillis.size() - 1) * 0.95)));
                capture.addProperty("max_frame_ms", frameMillis.get(frameMillis.size() - 1));
            }
            captures.add(capture);
            Files.writeString(out.resolve("captures.json"), new GsonBuilder().setPrettyPrinting().create().toJson(captures));
            System.out.println("ABYSS_CAPTURE_SAVED " + filename);
            if (phase % 3 == 2) client.method_1562().method_45730("abyss audit");
            next(client);
        } catch (Exception error) {
            error.printStackTrace(); finished = true; client.method_1592();
        }
    }

    private void next(class_310 client) {
        phase++;
        if (phase >= MODES.length * GlimmeringAbyss.VIEWS.size()) {
            client.method_1562().method_45730("abyss view tunnel");
            walkStarted = System.nanoTime();
            return;
        }
        client.method_1562().method_45730("abyss light " + MODES[phase / 3]);
        client.method_1562().method_45730("abyss view " + GlimmeringAbyss.VIEWS.get(phase % 3).name());
        phaseStarted = System.nanoTime(); lastFrame = 0; frameMillis.clear();
    }

    private void walkTest(class_310 client) {
        long elapsed = System.nanoTime() - walkStarted;
        if (!walking && elapsed > 2_000_000_000L) {
            walking = true; walkStartZ = client.field_1724.method_23321();
            client.field_1690.field_1894.method_23481(true);
        }
        if (elapsed < 10_000_000_000L) return;
        client.field_1690.field_1894.method_23481(false);
        double z = client.field_1724.method_23321(), y = client.field_1724.method_23318();
        boolean passed = walkStartZ - z > 20 && z > 62.7 && z < 64 && Math.abs(y - 39) < 0.01;
        JsonObject result = new JsonObject();
        result.addProperty("method", "Actual Minecraft player input: hold forward for 8 seconds from tunnel; stop at generated two-block iron railing.");
        result.addProperty("start_z", walkStartZ); result.addProperty("end_z", z); result.addProperty("end_y", y);
        result.addProperty("walk_and_collision_pass", passed);
        try {
            Files.writeString(Path.of("abyss-captures/walk-collision.json"), new GsonBuilder().setPrettyPrinting().create().toJson(result));
        } catch (Exception error) { error.printStackTrace(); }
        finished = true;
        System.out.println("ABYSS_CAPTURE_COMPLETE " + captures.size() + " walk_collision=" + passed);
        client.method_1592();
    }
}
