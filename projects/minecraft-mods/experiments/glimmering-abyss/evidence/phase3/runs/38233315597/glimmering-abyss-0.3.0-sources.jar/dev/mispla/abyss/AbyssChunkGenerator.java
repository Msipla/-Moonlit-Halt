package dev.mispla.abyss;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.class_1966;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2791;
import net.minecraft.class_2794;
import net.minecraft.class_2893;
import net.minecraft.class_2902;
import net.minecraft.class_3233;
import net.minecraft.class_4543;
import net.minecraft.class_4966;
import net.minecraft.class_5138;
import net.minecraft.class_5281;
import net.minecraft.class_5539;
import net.minecraft.class_6748;
import net.minecraft.class_7138;

/** Registered world generator: the study is generated as real Minecraft chunks. */
public final class AbyssChunkGenerator extends class_2794 {
    public static final Codec<AbyssChunkGenerator> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            class_1966.field_24713.fieldOf("biome_source").forGetter(AbyssChunkGenerator::method_12098),
            Codec.LONG.fieldOf("study_seed").forGetter(g -> g.seed)
    ).apply(instance, AbyssChunkGenerator::new));

    private final long seed;
    private final Map<Long, class_2680> fixtures;
    private static final class_2680 NS_RAIL = class_2246.field_10576.method_9564()
            .method_11657(class_2741.field_12489, true).method_11657(class_2741.field_12540, true);
    private static final class_2680 EW_RAIL = class_2246.field_10576.method_9564()
            .method_11657(class_2741.field_12487, true).method_11657(class_2741.field_12527, true);

    public AbyssChunkGenerator(class_1966 biomes, long seed) {
        super(biomes);
        this.seed = seed;
        Map<Long, class_2680> lamps = new HashMap<>();
        for (Terrain.Fixture f : Terrain.fixtures(seed)) {
            lamps.put(class_2338.method_10064(f.x(), f.y(), f.z()), GlimmeringAbyss.GLIMMER.method_9564());
        }
        this.fixtures = Map.copyOf(lamps);
    }

    public long studySeed() { return seed; }
    @Override protected Codec<? extends class_2794> method_28506() { return field_24746; }
    @Override public int method_33730() { return Terrain.MIN_Y; }
    @Override public int method_12104() { return Terrain.HEIGHT; }
    @Override public int method_16398() { return Terrain.MIN_Y; }

    public class_2680 stateAt(Terrain.Column column, int y) {
        class_2680 fixture = fixtures.get(class_2338.method_10064(column.x(), y, column.z()));
        if (fixture != null) return fixture;
        return switch (column.materialAt(y)) {
            case Terrain.AIR -> class_2246.field_10124.method_9564();
            case Terrain.BEDROCK -> class_2246.field_9987.method_9564();
            case Terrain.FLOOR -> class_2246.field_28892.method_9564();
            case Terrain.RAIL_NS -> column.z() == 62 || column.z() == 77
                    ? NS_RAIL.method_11657(class_2741.field_12487, column.x() < 0).method_11657(class_2741.field_12527, column.x() > 0)
                    : NS_RAIL;
            case Terrain.RAIL_EW -> EW_RAIL;
            default -> class_2246.field_28888.method_9564();
        };
    }

    @Override public CompletableFuture<class_2791> method_12088(Executor executor, class_6748 blender,
            class_7138 noise, class_5138 structures, class_2791 chunk) {
        return CompletableFuture.supplyAsync(() -> {
            class_2338.class_2339 pos = new class_2338.class_2339();
            class_2902 ocean = chunk.method_12032(class_2902.class_2903.field_13195);
            class_2902 surface = chunk.method_12032(class_2902.class_2903.field_13194);
            int startX = chunk.method_12004().method_8326(), startZ = chunk.method_12004().method_8328();
            for (int dx = 0; dx < 16; dx++) for (int dz = 0; dz < 16; dz++) {
                Terrain.Column column = Terrain.column(startX + dx, startZ + dz, seed);
                for (int y = Terrain.MIN_Y; y < Terrain.MIN_Y + Terrain.HEIGHT; y++) {
                    class_2680 state = stateAt(column, y);
                    if (!state.method_26215()) {
                        chunk.method_12010(pos.method_10103(column.x(), y, column.z()), state, false);
                        ocean.method_12597(dx, y, dz, state);
                        surface.method_12597(dx, y, dz, state);
                    }
                }
            }
            return chunk;
        }, executor);
    }

    @Override public int method_16397(int x, int z, class_2902.class_2903 type, class_5539 world, class_7138 noise) {
        return Terrain.MIN_Y + Terrain.HEIGHT;
    }

    @Override public class_4966 method_26261(int x, int z, class_5539 world, class_7138 noise) {
        class_2680[] states = new class_2680[Terrain.HEIGHT];
        Terrain.Column column = Terrain.column(x, z, seed);
        for (int i = 0; i < states.length; i++) states[i] = stateAt(column, Terrain.MIN_Y + i);
        return new class_4966(Terrain.MIN_Y, states);
    }

    @Override public void method_12108(class_3233 r, long s, class_7138 n, class_4543 b,
            class_5138 a, class_2791 c, class_2893.class_2894 step) {}
    @Override public void method_12110(class_3233 r, class_5138 a, class_7138 n, class_2791 c) {}
    @Override public void method_12107(class_3233 region) {}
    @Override public void method_12102(class_5281 world, class_2791 chunk, class_5138 structures) {}
    @Override public void method_40450(List<String> text, class_7138 noise, class_2338 pos) {
        text.add("Glimmering Abyss study seed: " + seed);
    }
}
