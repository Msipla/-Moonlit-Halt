package dev.mispla.abyss;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import dev.mispla.abyss.GlimmeringAbyss.View;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1011;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_318;
import net.minecraft.class_412;
import net.minecraft.class_442;
import net.minecraft.class_5365;
import net.minecraft.class_639;
import net.minecraft.class_642;
import org.lwjgl.opengl.GL11;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Opt-in same-session real Minecraft framebuffer capture and movement checks. */
public final class Phase5CaptureClient implements ClientModInitializer {
    private record Case(String file,String profile,GlimmeringAbyss.View view,String light,String kind) {}
    private static final List<Case> CASES=cases();
    private static final Path OUT=Path.of("abyss-phase5-captures");
    private final JsonArray captures=new JsonArray();
    private final List<Double> frames=new ArrayList<>();
    private final JsonObject intervals=new JsonObject();
    private boolean connected,entered,finished,saved,walking,prepared;
    private int phase=-1,stability;
    private long started,phaseStarted,lastFrame,walkStarted,walkPressed;
    private double walkStartZ;
    private int leg;
    private final JsonArray legs=new JsonArray();
    private long legStarted;
    private double legStartX,legStartZ;
    private boolean wallTest,railTest;
    private static final double[][] WAYPOINTS={{42.5,43.5},{30.5,43.5},{30.5,35.5},{-29.5,35.5},{-29.5,30.5},{-29.5,35.5},{30.5,35.5},{30.5,43.5},{42.5,43.5},{42.5,35.5}};
    private static List<Case> cases() {
        var r=new ArrayList<Case>();
        r.add(new Case("before-platform.png","blue",GlimmeringAbyss.VIEWS.get(1),"glimmer","before_building"));
        r.add(new Case("before-facade.png","blue",Architecture.VIEWS.get(0),"glimmer","phase4_control"));
        for(var v:Exploration.VIEWS)r.add(new Case("blue-"+v.name()+".png","blue",v,"glimmer","exploration"));
        r.add(new Case("blue-platform.png","blue",GlimmeringAbyss.VIEWS.get(1),"glimmer","legacy_view"));
        r.add(new Case("a-core.png","a",Exploration.VIEWS.get(1),"glimmer","native_control"));
        r.add(new Case("copper-core.png","copper",Exploration.VIEWS.get(1),"glimmer","palette_control"));
        r.add(new Case("overworld-blue.png","blue",null,"glimmer","dimension_scope"));return List.copyOf(r);
    }
    @Override public void onInitializeClient() {
        if(!Boolean.getBoolean("abyss.capture.phase5"))return;started=System.nanoTime();System.out.println("ABYSS_PHASE5_RELEASE_HARNESS_ENABLED");
        WorldRenderEvents.END.register(c->{long now=System.nanoTime();if(phase>=0&&phase<CASES.size()&&!saved&&now-phaseStarted>8_000_000_000L&&lastFrame!=0)frames.add((now-lastFrame)/1e6);lastFrame=now;});
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }
    private void tick(class_310 client) {
        if(finished)return;
        if(System.nanoTime()-started>1000_000_000_000L){fail(client,new IllegalStateException("Capture timeout"));return;}
        // Release Minecraft uses intermediary class names; never identify screens with a name string.
        if(!connected&&client.field_1755!=null&&client.method_18506()==null&&!(client.field_1755 instanceof class_442))client.method_1507(new class_442());
        if(!connected&&System.nanoTime()-started>180_000_000_000L){fail(client,new IllegalStateException("Release title-screen connection timeout"));return;}
        if(!connected&&client.field_1755 instanceof class_442&&client.method_18506()==null) {
            connected=true;client.field_1690.method_42503().method_41748(16);client.field_1690.method_42510().method_41748(6);
            client.field_1690.method_41808().method_41748(75);client.field_1690.method_42473().method_41748(.5);client.field_1690.method_42524().method_41748(60);
            client.field_1690.method_42433().method_41748(false);client.field_1690.method_42534().method_41748(class_5365.field_25428);client.field_1690.method_41792().method_41748(true);
            client.field_1690.field_1837=false;client.field_1690.field_1842=true;client.field_1690.method_1640();
            String address="127.0.0.1:"+Integer.getInteger("abyss.port",25585);
            class_412.method_36877(new class_442(),client,class_639.method_2950(address),new class_642("Abyss phase 5 release test",address,false),false);return;
        }
        if(client.field_1724==null||client.field_1687==null||client.method_1562()==null)return;
        if(!entered){entered=true;command(client,"abyss enter");return;}
        if(phase==-1){if(EnvironmentClient.studyActive()&&ClientCommandManager.getActiveDispatcher()!=null)next(client);return;}
        if(phase>=CASES.size()){walk(client);return;}
        long elapsed=System.nanoTime()-phaseStarted;if(elapsed<13_000_000_000L)return;Case test=CASES.get(phase);
        if(!cQueuesReady(client)){if(elapsed<75_000_000_000L)return;fail(client,new IllegalStateException("Chunk queues did not drain: "+client.field_1769.method_3289()));return;}
        try {
            if(!saved) {
                screenshot(client,test.file);var times=new JsonArray();for(double value:frames)times.add(value);intervals.add(test.file,times);write("frame-intervals.json",intervals);captures.add(metadata(client,test));saved=true;write("captures.json",captures);
                if(test.kind.equals("before_building"))command(client,"abyss audit before-building");
                if(test.file.equals("before-facade.png"))command(client,"abyss building audit phase4-regression");
                if(test.file.equals("blue-core.png"))command(client,"abyss route audit first");
                if(test.file.equals("blue-platform.png")){command(client,"abyss route");command(client,"abyss route audit repeat");}
                
            }
            next(client);
        }catch(Exception e){fail(client,e);}
    }
    private JsonObject metadata(class_310 c,Case test) {
        var r=new JsonObject();r.addProperty("file",test.file);r.addProperty("kind",test.kind);r.addProperty("render_profile",test.profile);r.addProperty("light_mode",test.light);r.addProperty("view",test.view==null?"overworld":test.view.name());
        r.addProperty("x",c.field_1724.method_23317());r.addProperty("y",c.field_1724.method_23318());r.addProperty("z",c.field_1724.method_23321());r.addProperty("yaw",c.field_1724.method_36454());r.addProperty("pitch",c.field_1724.method_36455());
        r.addProperty("framebuffer_width",c.method_1522().field_1482);r.addProperty("framebuffer_height",c.method_1522().field_1481);
        r.addProperty("fov",c.field_1690.method_41808().method_41753());r.addProperty("brightness_gamma",c.field_1690.method_42473().method_41753());r.addProperty("view_distance_chunks",c.field_1690.method_42503().method_41753());r.addProperty("simulation_distance_chunks",c.field_1690.method_42510().method_41753());
        r.addProperty("graphics",c.field_1690.method_42534().method_41753().toString());r.addProperty("ambient_occlusion",c.field_1690.method_41792().method_41753());r.addProperty("dimension_ambient_light",c.field_1687.method_8597().comp_656());r.addProperty("dimension_fixed_time",c.field_1687.method_8597().comp_641().orElse(-1));
        r.addProperty("gl_renderer",GL11.glGetString(GL11.GL_RENDERER));r.addProperty("gl_vendor",GL11.glGetString(GL11.GL_VENDOR));r.addProperty("gl_version",GL11.glGetString(GL11.GL_VERSION));r.addProperty("gl_error_at_capture",GL11.glGetError());r.addProperty("chunk_debug",c.field_1769.method_3289());
        var foot=class_2338.method_49638(c.field_1724.method_19538());r.addProperty("block_light_at_feet",c.field_1687.method_8314(class_1944.field_9282,foot));r.addProperty("sky_light_at_feet",c.field_1687.method_8314(class_1944.field_9284,foot));r.add("environment",EnvironmentClient.measurements());r.add("space_lighting",SpaceLighting.measurements());
        if(SpaceLighting.active()&&SpaceLighting.measurements().get("terrain_shader_selections").getAsLong()==0)throw new IllegalStateException("New terrain shader never selected");
        r.addProperty("sample_frames",frames.size());r.addProperty("settle_seconds",8);r.addProperty("sample_seconds",frames.stream().mapToDouble(Double::doubleValue).sum()/1000);
        if(!frames.isEmpty()) {
            double sum=frames.stream().mapToDouble(Double::doubleValue).sum();Collections.sort(frames);
            r.addProperty("sample_fps",frames.size()*1000/sum);r.addProperty("median_frame_ms",frames.get(frames.size()/2));r.addProperty("p95_frame_ms",frames.get((int)Math.floor((frames.size()-1)*.95)));r.addProperty("max_frame_ms",frames.get(frames.size()-1));r.addProperty("frames_over_100ms",frames.stream().filter(v->v>100).count());
        }return r;
    }
    private void next(class_310 client) {
        phase++;saved=false;stability=0;frames.clear();lastFrame=0;phaseStarted=System.nanoTime();if(phase>=CASES.size())return;
        var test=CASES.get(phase);if(phase==1)command(client,"abyss building");if(phase==2)command(client,"abyss route");selectWithCommand(client,test.profile);command(client,"abyss lamps "+(test.kind.equals("native_lanterns")?"on":"off"));command(client,"abyss light "+test.light);command(client,test.view==null?"abyss return":test.kind.equals("phase4_control")?"abyss building view facade":Exploration.VIEWS.contains(test.view)?"abyss route view "+test.view.name():"abyss view "+test.view.name());
    }
    private boolean cQueuesReady(class_310 c) {
        return c.field_1769.method_3289().matches(".*pC: 0+, pU: 0+.*");
    }
    private void screenshot(class_310 client,String name)throws Exception {
        Files.createDirectories(OUT);try(var image=class_318.method_1663(client.method_1522())){image.method_4314(OUT.resolve(name));}System.out.println("ABYSS_PHASE5_CAPTURE_SAVED "+name);
    }
    private void write(String name,com.google.gson.JsonElement value)throws Exception {Files.writeString(OUT.resolve(name),new GsonBuilder().setPrettyPrinting().create().toJson(value));}
    private void walk(class_310 c) {
        if(!prepared){prepared=true;selectWithCommand(c,"blue");command(c,"abyss route view interior");walkStarted=System.nanoTime();return;}
        if(System.nanoTime()-walkStarted<2_000_000_000L)return;
        if(leg<WAYPOINTS.length) {
            double tx=WAYPOINTS[leg][0],tz=WAYPOINTS[leg][1];
            if(!walking){walking=true;legStarted=System.nanoTime();legStartX=c.field_1724.method_23317();legStartZ=c.field_1724.method_23321();
                double dx=tx-legStartX,dz=tz-legStartZ;c.field_1724.method_36456((float)Math.toDegrees(Math.atan2(-dx,dz)));c.field_1724.method_36457(0);}
            c.field_1690.field_1894.method_23481(true);
            double distance=Math.hypot(tx-c.field_1724.method_23317(),tz-c.field_1724.method_23321());
            if(distance>.26&&System.nanoTime()-legStarted<25_000_000_000L)return;
            c.field_1690.field_1894.method_23481(false);
            boolean pass=distance<.4&&Math.abs(c.field_1724.method_23318()-39)<.01;
            var r=new JsonObject();r.addProperty("leg",leg);r.addProperty("start_x",legStartX);r.addProperty("start_z",legStartZ);r.addProperty("target_x",tx);r.addProperty("target_z",tz);r.addProperty("end_x",c.field_1724.method_23317());r.addProperty("end_z",c.field_1724.method_23321());r.addProperty("end_y",c.field_1724.method_23318());r.addProperty("held_forward_seconds",(System.nanoTime()-legStarted)/1e9);r.addProperty("pass",pass);legs.add(r);
            try{write("walk-legs.json",legs);if(leg==4)screenshot(c,"blue-walk-arrival.png");}catch(Exception e){fail(c,e);return;}
            if(!pass){fail(c,new IllegalStateException("Actual walking leg blocked: "+r));return;}
            leg++;walking=false;return;
        }
        if(!wallTest) {
            if(!walking){walking=true;legStarted=System.nanoTime();c.field_1724.method_36456(180);c.field_1724.method_36457(0);walkStartZ=c.field_1724.method_23321();}
            c.field_1690.field_1894.method_23481(true);
            if(System.nanoTime()-legStarted<5_000_000_000L)return;
            c.field_1690.field_1894.method_23481(false);double z=c.field_1724.method_23321();
            boolean pass=walkStartZ-z>14&&z<20.32&&z>=20.28&&Math.abs(c.field_1724.method_23318()-39)<.01;
            var r=new JsonObject();r.addProperty("method","Actual forward-key movement through the full route, return to workshop, then collide with back wall.");r.addProperty("end_x",c.field_1724.method_23317());r.addProperty("end_z",z);r.addProperty("end_y",c.field_1724.method_23318());r.addProperty("walk_and_collision_pass",pass);r.add("walking_legs",legs);
            try{write("walk-collision.json",r);screenshot(c,"blue-walk-interior.png");}catch(Exception e){fail(c,e);return;}
            if(!pass){fail(c,new IllegalStateException("Workshop wall did not stop player: "+r));return;}
            wallTest=true;walking=false;command(c,"abyss route view down");legStarted=System.nanoTime();return;
        }
        if(!railTest) {
            if(!walking){if(System.nanoTime()-legStarted<2_000_000_000L)return;walking=true;legStarted=System.nanoTime();c.field_1724.method_36456(180);c.field_1724.method_36457(35);}
            c.field_1690.field_1894.method_23481(true);if(System.nanoTime()-legStarted<5_000_000_000L)return;
            c.field_1690.field_1894.method_23481(false);double z=c.field_1724.method_23321();
            boolean pass=z>32.8&&z<33.4&&Math.abs(c.field_1724.method_23318()-39)<.01&&Math.abs(c.field_1724.method_23317()-4.5)<.01;
            var r=new JsonObject();r.addProperty("method","Actual forward key held north into bridge iron rail, flight disabled, five seconds including stationary collision.");r.addProperty("end_x",c.field_1724.method_23317());r.addProperty("end_z",z);r.addProperty("end_y",c.field_1724.method_23318());r.addProperty("rail_collision_pass",pass);
            try{write("rail-collision.json",r);screenshot(c,"blue-rail-collision.png");}catch(Exception e){fail(c,e);return;}
            if(!pass){fail(c,new IllegalStateException("Rail did not stop player: "+r));return;}
            railTest=true;
        }
        finished=true;System.out.println("ABYSS_PHASE5_COMPLETE "+captures.size()+" walk_collision=true rail_collision=true");c.method_1592();
    }
    private void selectWithCommand(class_310 c,String profile) {
        try {int result=ClientCommandManager.getActiveDispatcher().execute("abyssrender "+profile,(FabricClientCommandSource)c.method_1562().method_2875());if(result!=1||!EnvironmentClient.selectedName().equals(profile))throw new IllegalStateException("Bad command result");System.out.println("ABYSS_RENDER_COMMAND_DISPATCH "+profile+" result="+result);}catch(Exception e){throw new IllegalStateException(e);}
    }
    private void command(class_310 c,String text){c.method_1562().method_45730(text);}
    private void fail(class_310 c,Exception e){e.printStackTrace();finished=true;System.err.println("ABYSS_PHASE5_FAILED");c.method_1592();}
}
