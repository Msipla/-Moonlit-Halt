package dev.mispla.abyss;

import net.minecraft.class_1299;
import net.minecraft.class_1593;
import net.minecraft.class_1921;
import net.minecraft.class_2246;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_588;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_897;

/** Vanilla materials and phantom model. No textures copied, no actual phantom mob or attack AI. */
public final class CableCarRenderer extends class_897<CableCarEntity> {
    private static final class_2960 PHANTOM=new class_2960("textures/entity/phantom.png");
    private final class_588<class_1593> phantom;
    private class_1593 pose;
    public CableCarRenderer(class_5617.class_5618 context){super(context);phantom=new class_588<>(context.method_32167(class_5602.field_27620));field_4673=1.4f;}
    @Override public class_2960 getTexture(CableCarEntity entity){return PHANTOM;}
    private void box(class_4587 m,class_4597 v,int light,class_2680 state,float x,float y,float z,float sx,float sy,float sz){
        m.method_22903();m.method_46416(x,y,z);m.method_22905(sx,sy,sz);class_310.method_1551().method_1541().method_3353(state,m,v,light,class_4608.field_21444);m.method_22909();
    }
    @Override public void render(CableCarEntity car,float yaw,float delta,class_4587 m,class_4597 v,int worldLight){
        int light=class_765.method_23687(12,0);
        var floor=class_2246.field_10075.method_9564();var frame=class_2246.field_28892.method_9564();var glass=class_2246.field_10033.method_9564();
        box(m,v,light,floor,-1.5f,0,-1.5f,3,.2f,3);
        box(m,v,light,frame,-1.6f,3.1f,-1.6f,3.2f,.25f,3.2f);
        for(float x:new float[]{-1.5f,1.35f})for(float z:new float[]{-1.5f,1.35f})box(m,v,light,frame,x,.2f,z,.15f,2.9f,.15f);
        for(float x:new float[]{-1.5f,1.42f})box(m,v,light,glass,x,.2f,-1.4f,.08f,2.9f,2.8f);
        for(float z:new float[]{-1.5f,1.42f})box(m,v,light,glass,-1.4f,.2f,z,2.8f,2.9f,.08f);
        for(float x:new float[]{-.8f,.8f})box(m,v,light,class_2246.field_23985.method_9564(),x,3.35f,-.8f,.18f,1.8f,.18f);
        // A fixed neutral scenic rig pulling the car: it cannot acquire targets, attack, burn or spawn separately.
        if(pose==null||pose.method_37908()!=car.method_37908())pose=new class_1593(class_1299.field_6078,car.method_37908());
        pose.field_6012=car.field_6012;phantom.method_33686(pose,0,0,car.field_6012+delta,0,0);
        m.method_22903();m.method_22904(0,5.1,-1.8);m.method_22907(class_7833.field_40714.rotationDegrees(180));m.method_22905(1.8f,1.8f,1.8f);
        phantom.method_2828(m,v.getBuffer(class_1921.method_23578(PHANTOM)),light,class_4608.field_21444,.65f,.88f,1,1);m.method_22909();
        super.method_3936(car,yaw,delta,m,v,worldLight);
    }
}
