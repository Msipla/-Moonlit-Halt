package dev.mispla.abyss;

import net.fabricmc.fabric.api.entity.event.v1.EntitySleepEvents;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import net.minecraft.class_4048;
import net.minecraft.class_4970;
import net.minecraft.class_7923;
import net.minecraft.server.MinecraftServer;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Two quiet dreams, a reusable direction shard and two station bells. */
public final class Journey {
    public static final class_2960 SITE_PACKET=GlimmeringAbyss.id("site");
    public static final class_1299<CableCarEntity> CAR=class_2378.method_10230(class_7923.field_41177,GlimmeringAbyss.id("cable_car"),
        FabricEntityTypeBuilder.<CableCarEntity>create(class_1311.field_17715,CableCarEntity::new).dimensions(class_4048.method_18385(3,3.3f)).trackRangeBlocks(160).trackedUpdateRate(1).build());
    public static final class_2248 BELL=new class_2248(class_4970.class_2251.method_9630(class_2246.field_23261).method_9629(-1,3600000)){
        @Override public class_1269 method_9534(class_2680 state,class_1937 w,class_2338 pos,class_1657 p,class_1268 hand,class_3965 hit){
            if(w.field_9236)return class_1269.field_5812;
            var s=OverworldSite.get(((class_3218)w).method_8503().method_30002());
            if(!w.method_27983().equals(class_1937.field_25179)||!s.ready()||pos.method_10263()!=s.x+6||pos.method_10260()!=s.z+68)return class_1269.field_5811;
            board((class_3222)p,s,pos.method_10264()==s.entryY+1);return class_1269.field_21466;
        }
    };
    public static final class_1792 ECHO=new class_1792(new class_1792.class_1793().method_7889(1)){
        @Override public class_1271<class_1799> method_7836(class_1937 world,class_1657 p,class_1268 hand){
            if(!world.field_9236)guide((class_3222)p);
            return class_1271.method_29237(p.method_5998(hand),world.field_9236);
        }
    };
    private static final Map<UUID,Long> sleepStarts=new HashMap<>();
    private Journey(){}
    public static void initialize(){
        class_2378.method_10230(class_7923.field_41175,GlimmeringAbyss.id("station_bell"),BELL);
        class_2378.method_10230(class_7923.field_41178,GlimmeringAbyss.id("echo_shard"),ECHO);
        EntitySleepEvents.START_SLEEPING.register((e,p)->{if(e instanceof class_3222 sp)sleepStarts.put(sp.method_5667(),sp.method_37908().method_8510());});
        EntitySleepEvents.STOP_SLEEPING.register((e,p)->{
            if(e instanceof class_3222 sp){
                Long start=sleepStarts.remove(sp.method_5667());
                if(start!=null&&sp.method_37908().method_8510()-start>=95&&sp.method_37908().method_8532()%24000<1000)dream(sp);
            }
        });
        ServerPlayConnectionEvents.JOIN.register((h,sender,server)->server.execute(()->{
            sync(h.field_14140);var s=OverworldSite.get(server.method_30002());
            if(s.journeys.containsKey(h.field_14140.method_5667()))recover(h.field_14140,s,"旅途中断后，你已回到安全站台。");
        }));
        ServerPlayConnectionEvents.DISCONNECT.register((h,server)->{
            var s=OverworldSite.get(server.method_30002());
            if(s.journeys.containsKey(h.field_14140.method_5667()))recover(h.field_14140,s,"缆车已靠站。");
            sleepStarts.remove(h.field_14140.method_5667());
        });
    }
    public static void syncAll(MinecraftServer server){for(var p:server.method_3760().method_14571())sync(p);}
    public static void sync(class_3222 p){
        var s=OverworldSite.get(p.method_5682().method_30002());var b=PacketByteBufs.create();
        b.writeBoolean(s.ready());b.writeInt(s.x);b.writeInt(s.z);b.writeInt(s.entryY);ServerPlayNetworking.send(p,SITE_PACKET,b);
    }
    public static void dream(class_3222 p){
        var s=OverworldSite.get(p.method_5682().method_30002());long day=p.method_37908().method_8532()/24000;
        if(!s.ready()||s.dreamDays.getOrDefault(p.method_5667(),-1L)==day)return;
        int n=Math.min(2,s.dreams.getOrDefault(p.method_5667(),0)+1);s.dreams.put(p.method_5667(),n);s.dreamDays.put(p.method_5667(),day);s.method_80();
        p.method_7353(class_2561.method_43470(n==1?"梦中，蓝色巨柱间亮着几扇暖窗。山间传来一声悠远的铃响……":"梦中的幻翼停在玻璃车厢上。掌心的微光，正指向那处山间站台。"),false);
        if(n>=2&&!p.method_31548().method_7379(new class_1799(ECHO)))p.method_31548().method_7398(new class_1799(ECHO));
    }
    public static void guide(class_3222 p){
        var s=OverworldSite.get(p.method_5682().method_30002());
        if(!s.ready()){p.method_7353(class_2561.method_43470("微光尚未回应。先在这片世界歇息片刻。"),true);return;}
        if(!p.method_37908().method_27983().equals(class_1937.field_25179)){p.method_7353(class_2561.method_43470("回响来自主世界的群山。"),true);return;}
        class_243 target=class_243.method_24953(s.landing(true));class_243 delta=target.method_1020(p.method_19538());
        var dir=new class_243(delta.field_1352,0,delta.field_1350).method_1029();
        for(int i=1;i<=20;i++)p.method_51469().method_14166(p,class_2398.field_11207,true,p.method_23317()+dir.field_1352*i*.5,p.method_23320(),p.method_23321()+dir.field_1350*i*.5,1,.02,.03,.02,0);
        String ns=delta.field_1350<0?"北":"南",ew=delta.field_1352<0?"西":"东";
        String direction=Math.abs(delta.field_1352)>Math.abs(delta.field_1350)*2?ew:Math.abs(delta.field_1350)>Math.abs(delta.field_1352)*2?ns:ew+ns;
        p.method_7353(class_2561.method_43470("微光指向"+direction+"，约 "+(int)Math.hypot(delta.field_1352,delta.field_1350)+" 格。"+(delta.method_37267()<32?"循灯走向站台，触碰回响铃登车。":"")),true);
        p.method_7357().method_7906(ECHO,30);
    }
    public static void board(class_3222 p,OverworldSite s,boolean upper){
        if(!s.ready()||p.method_5765())return;
        var w=p.method_51469();var car=CAR.method_5883(w);car.configure(s,upper);
        if(!w.method_8649(car)){p.method_7353(class_2561.method_43470("缆车暂未就绪，请稍后再试。"),true);return;}
        s.journeys.put(p.method_5667(),upper);s.method_80();w.method_17983().method_125();
        p.method_14251(w,s.x+.5,upper?s.entryY+1:45,s.z+70.5,180,8);
        p.method_5873(car,true);p.method_7353(class_2561.method_43470("玻璃车门已关闭。请欣赏沿途风景；潜行可提前返回安全站台。"),true);
    }
    public static void recover(class_3222 p,OverworldSite s,String message){
        boolean upper=s.journeys.getOrDefault(p.method_5667(),true);p.method_5848();
        land(p,s,upper);p.method_7353(class_2561.method_43470(message),true);
    }
    public static void land(class_3222 p,OverworldSite s,boolean upper){
        var pos=s.landing(upper);var w=p.method_5682().method_30002();w.method_22350(pos);
        // Re-establish only the tiny emergency landing pad if a player removed its footing.
        for(int dx=-1;dx<=1;dx++)for(int dz=-1;dz<=1;dz++){
            var q=pos.method_10069(dx,0,dz);w.method_8652(q.method_10074(),class_2246.field_28892.method_9564(),class_2248.field_31036);
            w.method_8652(q,class_2246.field_10124.method_9564(),class_2248.field_31036);w.method_8652(q.method_10084(),class_2246.field_10124.method_9564(),class_2248.field_31036);
        }
        p.field_6017=0;p.method_18799(class_243.field_1353);p.method_14251(w,pos.method_10263()+.5,pos.method_10264(),pos.method_10260()+.5,upper?90:180,0);
        s.journeys.remove(p.method_5667());s.method_80();
    }
}
