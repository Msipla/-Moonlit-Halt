package dev.mispla.abyss;

import java.util.List;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2604;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3230;

/** A seated closed cabin on a fixed route. The phantom is a harmless visual rig, not an attacking mob. */
public final class CableCarEntity extends class_1297 {
    public static final int DURATION=900;
    private boolean fromUpper,arriving;
    private int progress,topY,originX,originZ;
    public CableCarEntity(class_1299<? extends CableCarEntity> type,class_1937 w){super(type,w);method_5875(true);method_5684(true);}
    public void configure(OverworldSite s,boolean upper){originX=s.x;originZ=s.z;topY=s.entryY+1;fromUpper=upper;method_5814(s.x+.5,upper?topY:45,s.z+70.5);}
    @Override protected void method_5693(){}
    @Override protected void method_5749(class_2487 n){originX=n.method_10550("x");originZ=n.method_10550("z");topY=n.method_10550("top");fromUpper=n.method_10577("upper");progress=n.method_10550("progress");}
    @Override protected void method_5652(class_2487 n){n.method_10569("x",originX);n.method_10569("z",originZ);n.method_10569("top",topY);n.method_10556("upper",fromUpper);n.method_10569("progress",progress);}
    @Override public class_2596<class_2602> method_18002(){return new class_2604(this);}
    @Override protected boolean method_5818(class_1297 passenger){return passenger instanceof class_3222&&method_5685().isEmpty();}
    @Override public double method_5621(){return .2;}
    @Override public boolean method_5643(class_1282 source,float amount){return false;}
    @Override public boolean method_30948(){return true;}
    @Override public void method_5773(){
        super.method_5773();if(method_37908().field_9236)return;
        if(!method_5782()){method_31472();return;}
        var w=(class_3218)method_37908();var s=OverworldSite.get(w);
        if(!s.ready()){abort();return;}
        double t=Math.min(1,++progress/(double)DURATION),ease=t*t*(3-2*t);
        double y=fromUpper?topY+(45-topY)*ease:45+(topY-45)*ease;
        var pos=class_2338.method_49637(originX+.5,y,originZ+70.5);
        w.method_14178().method_17297(class_3230.field_19280,new class_1923(pos),3,pos);
        if(!w.method_8587(this,new net.minecraft.class_238(originX-1, y,originZ+69,originX+2,y+3.2,originZ+72))){abort();return;}
        method_5814(originX+.5,y,originZ+70.5);method_18799(class_243.field_1353);
        for(var e:method_5685())e.field_6017=0;
        if(progress>=DURATION){
            arriving=true;var passengers=java.util.List.copyOf(method_5685());method_5772();
            for(var e:passengers)if(e instanceof class_3222 p)Journey.land(p,s,!fromUpper);
            method_31472();
        }
    }
    private void abort(){var s=OverworldSite.get((class_3218)method_37908());arriving=true;var list=java.util.List.copyOf(method_5685());method_5772();for(var e:list)if(e instanceof class_3222 p)Journey.land(p,s,fromUpper);method_31472();}
    @Override protected void method_5793(class_1297 passenger){
        super.method_5793(passenger);
        if(!arriving&&!method_37908().field_9236&&passenger instanceof class_3222 p){
            Journey.land(p,OverworldSite.get((class_3218)method_37908()),fromUpper);method_31472();
        }
    }
}
