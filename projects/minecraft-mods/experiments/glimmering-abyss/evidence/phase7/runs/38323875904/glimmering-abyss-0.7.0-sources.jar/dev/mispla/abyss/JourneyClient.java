package dev.mispla.abyss;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_310;

public final class JourneyClient implements ClientModInitializer {
    private static boolean ready;
    public static int x,z,entryY;
    @Override public void onInitializeClient(){
        EntityRendererRegistry.register(Journey.CAR,CableCarRenderer::new);
        ClientPlayNetworking.registerGlobalReceiver(Journey.SITE_PACKET,(client,handler,b,response)->{
            boolean ok=b.readBoolean();int nx=b.readInt(),nz=b.readInt(),ny=b.readInt();
            client.execute(()->{ready=ok;x=nx;z=nz;entryY=ny;});
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler,client)->ready=false);
    }
    public static boolean ready(){return ready;}
    public static class_2338 origin(){
        var c=class_310.method_1551();if(!ready||c.field_1687==null||!c.field_1687.method_27983().equals(class_1937.field_25179))return null;
        var p=c.field_1773.method_19418().method_19326();
        if(p.field_1352<x-120||p.field_1352>x+120||p.field_1350<z-184||p.field_1350>z+120||p.field_1351< -60||p.field_1351>116)return null;
        return new class_2338(x,OverworldSite.OFFSET_Y,z);
    }
}
