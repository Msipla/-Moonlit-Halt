package dev.mispla.abyss;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1011;
import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_318;
import net.minecraft.class_3965;
import net.minecraft.class_412;
import net.minecraft.class_442;
import net.minecraft.class_5365;
import net.minecraft.class_639;
import net.minecraft.class_642;
import org.lwjgl.opengl.GL11;
import java.nio.file.Files;
import java.nio.file.Path;

/** Opt-in official-client harness: actual bell interactions, two rides and walking keys. */
public final class Phase7CaptureClient implements ClientModInitializer {
    private static final boolean RECONNECT=Boolean.getBoolean("abyss.capture.phase7.reconnect");
    private static final Path OUT=Path.of(RECONNECT?"abyss-phase7-reconnect":"abyss-phase7-captures");
    private final JsonArray frames=new JsonArray(),walks=new JsonArray(),rides=new JsonArray();
    private boolean connected,finished,midShot,lowShot;
    private long started,changed;
    private int phase=-1,leg,sleeps;
    private boolean observedSleep,restartReady;
    private double startX,startZ;
    private static final double[][] WALK={{20.5,70.5},{38.5,70.5},{38.5,43.5},{30.5,43.5},{30.5,35.5},{-29.5,35.5},{30.5,35.5},{30.5,5.5},{47.5,5.5},{47.5,-22.5},{47.5,5.5},{30.5,5.5},{30.5,43.5},{38.5,43.5},{38.5,70.5},{20.5,70.5},{6.5,70.5}};
    @Override public void onInitializeClient(){if(!Boolean.getBoolean("abyss.capture.phase7"))return;started=System.nanoTime();ClientTickEvents.END_CLIENT_TICK.register(this::tick);}
    private double seconds(){return (System.nanoTime()-changed)/1e9;}
    private void next(){phase++;changed=System.nanoTime();}
    private void command(class_310 c,String command){c.method_1562().method_45730("abyss phase7 "+command);}
    private void bell(class_310 c,boolean upper){
        var p=new class_2338(JourneyClient.x+6,upper?JourneyClient.entryY+1:45,JourneyClient.z+68);
        c.field_1761.method_2896(c.field_1724,class_1268.field_5808,new class_3965(class_243.method_24953(p),class_2350.field_11035,p,false));
    }
    private void tick(class_310 c){
        if(finished)return;
        try{
            if(System.nanoTime()-started>1500_000_000_000L)throw new IllegalStateException("Capture deadline");
            if(!connected&&c.field_1755!=null&&c.method_18506()==null&&!(c.field_1755 instanceof class_442))c.method_1507(new class_442());
            if(!connected&&c.field_1755 instanceof class_442&&c.method_18506()==null){
                connected=true;c.field_1690.method_42503().method_41748(16);c.field_1690.method_42510().method_41748(6);c.field_1690.method_41808().method_41748(75);c.field_1690.method_42473().method_41748(.5);c.field_1690.method_42524().method_41748(45);c.field_1690.method_42433().method_41748(false);c.field_1690.method_42534().method_41748(class_5365.field_25428);c.field_1690.method_41792().method_41748(true);c.field_1690.field_1837=false;c.field_1690.field_1842=true;
                String address="127.0.0.1:"+Integer.getInteger("abyss.port",25585);class_412.method_36877(new class_442(),c,class_639.method_2950(address),new class_642("Phase 7 release test",address,false),false);return;
            }
            if(restartReady&&c.field_1687==null){finished=true;c.method_1592();return;}
            if(c.field_1724==null||c.field_1687==null||!JourneyClient.ready())return;
            if(RECONNECT){
                if(phase==-1){next();return;}if(seconds()<12)return;checkLanding(c,true);capture(c,"reconnected-safe-station.png");
                var recovery=new JsonObject();recovery.addProperty("pass",true);recovery.addProperty("same_offline_identity",true);write("recovery.json",recovery);finished=true;c.method_1592();return;
            }
            if(phase==-1){command(c,"view outside");next();return;}
            if(phase==0){if(seconds()<65)return;command(c,"natural");capture(c,"outside-normal-overworld.png");command(c,"bedtime");phase=20;changed=System.nanoTime();return;}
            if(phase==20){
                if(seconds()<3)return;var bed=new class_2338(JourneyClient.x+400,c.field_1724.method_31478(),JourneyClient.z+70);
                c.field_1761.method_2896(c.field_1724,class_1268.field_5808,new class_3965(class_243.method_24953(bed),class_2350.field_11036,bed,false));observedSleep=false;phase=21;changed=System.nanoTime();return;
            }
            if(phase==21){
                observedSleep|=c.field_1724.method_6113();if(c.field_1724.method_6113()||!observedSleep){if(seconds()>30)throw new IllegalStateException("Real bed sleep did not complete");return;}
                if(++sleeps<2){command(c,"bedtime");phase=20;changed=System.nanoTime();return;}
                if(!c.field_1724.method_31548().method_7379(new net.minecraft.class_1799(Journey.ECHO)))throw new IllegalStateException("Two real sleeps did not deliver guide");
                var dream=new JsonObject();dream.addProperty("actual_bed_sleeps",sleeps);dream.addProperty("guide_received",true);write("dreams.json",dream);
                for(int i=0;i<9;i++)if(c.field_1724.method_31548().method_5438(i).method_31574(Journey.ECHO))c.field_1724.method_31548().field_7545=i;
                c.field_1761.method_2919(c.field_1724,class_1268.field_5808);command(c,"view entrance");phase=1;changed=System.nanoTime();return;
            }
            if(phase==1){if(seconds()<18||!queues(c))return;capture(c,"surface-station.png");bell(c,true);next();return;}
            if(phase==2){if(!c.field_1724.method_5765()){if(seconds()>12)throw new IllegalStateException("Upper bell did not board");return;}next();return;}
            if(phase==3){
                if(!midShot&&c.field_1724.method_23318()<JourneyClient.entryY-10){capture(c,"cabin-descent.png");midShot=true;}
                if(!lowShot&&c.field_1724.method_23318()<72){c.field_1724.method_36456(-140);c.field_1724.method_36457(8);capture(c,"cabin-cavern-arrival.png");lowShot=true;}
                if(c.field_1724.method_5765()){if(seconds()>150)throw new IllegalStateException("Descent did not finish");return;}
                checkLanding(c,false);capture(c,"lower-arrival.png");leg=0;startX=c.field_1724.method_23317();startZ=c.field_1724.method_23321();next();return;
            }
            if(phase==4){
                if(leg>=WALK.length){c.field_1690.field_1894.method_23481(false);bell(c,false);next();return;}
                double tx=JourneyClient.x+WALK[leg][0],tz=JourneyClient.z+WALK[leg][1],dx=tx-c.field_1724.method_23317(),dz=tz-c.field_1724.method_23321();
                c.field_1724.method_36456((float)Math.toDegrees(Math.atan2(-dx,dz)));c.field_1724.method_36457(0);c.field_1690.field_1894.method_23481(true);
                if(Math.hypot(dx,dz)>.38&&seconds()<35)return;
                c.field_1690.field_1894.method_23481(false);boolean pass=Math.hypot(dx,dz)<=.5&&Math.abs(c.field_1724.method_23318()-45)<.15&&!c.field_1724.method_31549().field_7479;
                var r=new JsonObject();r.addProperty("leg",leg);r.addProperty("start_x",startX);r.addProperty("start_z",startZ);r.addProperty("end_x",c.field_1724.method_23317());r.addProperty("end_z",c.field_1724.method_23321());r.addProperty("end_y",c.field_1724.method_23318());r.addProperty("forward_seconds",seconds());r.addProperty("pass",pass);walks.add(r);write("walk.json",walks);
                if(!pass)throw new IllegalStateException("Walking blocked: "+r);
                if(leg==5)capture(c,"walk-bridge.png");if(leg==9)capture(c,"walk-town.png");
                leg++;startX=c.field_1724.method_23317();startZ=c.field_1724.method_23321();changed=System.nanoTime();return;
            }
            if(phase==5){if(!c.field_1724.method_5765()){if(seconds()>12)throw new IllegalStateException("Lower bell did not board");return;}next();return;}
            if(phase==6){if(c.field_1724.method_5765()){if(seconds()>150)throw new IllegalStateException("Return did not finish");return;}checkLanding(c,true);capture(c,"surface-return.png");bell(c,true);next();return;}
            if(phase==7){if(seconds()<8)return;if(!c.field_1724.method_5765())throw new IllegalStateException("Emergency test failed to board");c.field_1690.field_1832.method_23481(true);next();return;}
            if(phase==8){if(seconds()<3)return;c.field_1690.field_1832.method_23481(false);if(c.field_1724.method_5765())throw new IllegalStateException("Emergency dismount still riding");checkLanding(c,true);capture(c,"emergency-safe-return.png");command(c,"view street");next();return;}
            if(phase>=9&&phase<=12){
                if(seconds()<18||!queues(c))return;
                String[] names={"town-street.png","naturalized-cliff.png","overworld-town-overview.png","surface-entrance-overview.png"};capture(c,names[phase-9]);
                if(phase==9)command(c,"view cliff");if(phase==10)command(c,"view overview");if(phase==11)command(c,"view surface");next();return;
            }
            if(phase==13){
                command(c,"audit client");command(c,"intrusion");write("rides.json",rides);
                var r=new JsonObject();r.addProperty("pass",true);r.addProperty("real_bell_interactions",4);r.addProperty("real_walking_legs",walks.size());r.addProperty("native_dimension","minecraft:overworld");r.addProperty("method","Bell right clicks, server-authoritative cabin rides, actual forward-key walking; operator camera placement used only before journey and after round trip.");write("journey.json",r);
                command(c,"view entrance");next();return;
            }
            if(phase==14){if(seconds()<12)return;bell(c,true);next();return;}
            if(phase==15){
                if(seconds()<10)return;if(!c.field_1724.method_5765())throw new IllegalStateException("Restart test did not board");
                if(!restartReady){var restart=new JsonObject();restart.addProperty("riding_before_stop",true);restart.addProperty("y",c.field_1724.method_23318());write("restart-ready.json",restart);restartReady=true;}
                if(seconds()>90)throw new IllegalStateException("Server did not stop for recovery test");
            }
        }catch(Exception e){e.printStackTrace();finished=true;c.field_1690.field_1894.method_23481(false);c.field_1690.field_1832.method_23481(false);System.err.println("ABYSS_PHASE7_FAILED");c.method_1592();}
    }
    private void checkLanding(class_310 c,boolean upper){
        boolean pass=Math.abs(c.field_1724.method_23317()-(JourneyClient.x+6.5))<.2&&Math.abs(c.field_1724.method_23321()-(JourneyClient.z+70.5))<.2&&Math.abs(c.field_1724.method_23318()-(upper?JourneyClient.entryY+1:45))<.3&&c.field_1724.method_6032()>0&&!c.field_1724.method_5765();
        var r=new JsonObject();r.addProperty("upper",upper);r.addProperty("x",c.field_1724.method_23317());r.addProperty("y",c.field_1724.method_23318());r.addProperty("z",c.field_1724.method_23321());r.addProperty("health",c.field_1724.method_6032());r.addProperty("pass",pass);rides.add(r);if(!pass)throw new IllegalStateException("Unsafe landing "+r);
    }
    private boolean queues(class_310 c){return c.field_1769.method_3289().matches(".*pC: 0(?:[, ].*)?")&&c.field_1769.method_3289().matches(".*pU: 0(?:[, ].*)?");}
    private void capture(class_310 c,String file)throws Exception{
        Files.createDirectories(OUT);try(var frame=class_318.method_1663(c.method_1522())){frame.method_4314(OUT.resolve(file));}
        var r=new JsonObject();r.addProperty("file",file);r.addProperty("x",c.field_1724.method_23317());r.addProperty("y",c.field_1724.method_23318());r.addProperty("z",c.field_1724.method_23321());r.addProperty("yaw",c.field_1724.method_36454());r.addProperty("pitch",c.field_1724.method_36455());r.addProperty("riding",c.field_1724.method_5765());r.addProperty("health",c.field_1724.method_6032());r.addProperty("dimension",c.field_1687.method_27983().method_29177().toString());r.addProperty("chunk_debug",c.field_1769.method_3289());r.addProperty("gl_error",GL11.glGetError());r.addProperty("renderer",GL11.glGetString(GL11.GL_RENDERER));r.add("environment",EnvironmentClient.measurements());frames.add(r);write("captures.json",frames);
    }
    private void write(String name,Object value){try{Files.createDirectories(OUT);Files.writeString(OUT.resolve(name),new GsonBuilder().setPrettyPrinting().create().toJson(value));}catch(Exception e){throw new IllegalStateException(e);}}
}
