package dev.mispla.abyss;

import com.google.gson.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1011;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_318;
import net.minecraft.class_3965;
import net.minecraft.class_412;
import net.minecraft.class_442;
import net.minecraft.class_639;
import net.minecraft.class_642;
import net.minecraft.client.gui.screen.*;
import net.minecraft.client.network.*;
import net.minecraft.util.math.*;
import org.lwjgl.opengl.GL11;
import java.nio.file.*;

/** Opt-in release-client spatial review. Actual sleep, bell journeys and forward-key loop. */
public final class V1CaptureClient implements ClientModInitializer {
    private static final boolean MECHANICS=Boolean.getBoolean("abyss.capture.v1.mechanics");
    private static final boolean TRANSPORT=Boolean.getBoolean("abyss.capture.v1.transport");
    private static final boolean RECONNECT=Boolean.getBoolean("abyss.capture.v1.reconnect");
    private static final Path OUT=Path.of(MECHANICS?"abyss-v1-mechanics":RECONNECT?"abyss-v1-reconnect":TRANSPORT?"abyss-v1-transport":"abyss-v1-captures");
    private static final double[][] ROUTE={{47.5,-57.5},{47.5,-83.5},{22.5,-83.5},{22.5,-99.5},{-27.5,-99.5},{-27.5,-123.5},{-77.5,-123.5},{-77.5,-147.5},{-125.5,-147.5},{-125.5,-183.5},{-150.5,-183.5},{-150.5,-213.5},{-89.5,-213.5},{-89.5,-175.5},{-65.5,-175.5},{-65.5,-123.5},{-77.5,-123.5},{-27.5,-123.5},{-27.5,-99.5},{22.5,-99.5},{22.5,-83.5},{47.5,-83.5},{47.5,-57.5}};
    private final JsonArray frames=new JsonArray(),motion=new JsonArray(),walks=new JsonArray();
    private int state=-1,leg,night;private boolean connected,done,slept,restartReady;private int dreamCaptured;
    private long started,changed;private double walkX,walkZ;
    @Override public void onInitializeClient(){if(Boolean.getBoolean("abyss.capture.v1")){started=changed=System.nanoTime();ClientTickEvents.END_CLIENT_TICK.register(this::tick);}}
    private double seconds(){return (System.nanoTime()-changed)/1e9;}
    private void next(int n){state=n;changed=System.nanoTime();System.out.println("ABYSS_V1_STAGE "+n);}
    private void cmd(class_310 c,String v){c.method_1562().method_45730("abyss phase7 "+v);}
    private void bell(class_310 c,boolean upper){
        var p=new class_2338(JourneyClient.x+6+(upper?0:24),upper?JourneyClient.entryY+1:45,JourneyClient.z+(upper?68:56));
        c.field_1761.method_2896(c.field_1724,class_1268.field_5808,new class_3965(class_243.method_24953(p),class_2350.field_11035,p,false));
    }
    private void tick(class_310 c){
        if(done)return;
        try{
            if(System.nanoTime()-started>1400_000_000_000L)throw new IllegalStateException("Preview deadline");
            if(!connected&&c.field_1755!=null&&c.method_18506()==null&&!(c.field_1755 instanceof class_442))c.method_1507(new class_442());
            if(!connected&&c.field_1755 instanceof class_442&&c.method_18506()==null){
                connected=true;c.field_1690.method_42503().method_41748(16);c.field_1690.method_42510().method_41748(6);c.field_1690.method_41808().method_41748(75);c.field_1690.method_42473().method_41748(.5);c.field_1690.method_42524().method_41748(45);c.field_1690.method_42433().method_41748(false);c.field_1690.field_1837=false;c.field_1690.field_1842=false;c.field_1690.field_1875=net.minecraft.class_1157.field_5653;
                String address="127.0.0.1:25585";class_412.method_36877(new class_442(),c,class_639.method_2950(address),new class_642("V1 release preview",address,false),false);return;
            }
            if(restartReady&&c.field_1687==null){done=true;c.method_1592();return;}
            if(c.field_1724==null||c.field_1687==null||!JourneyClient.ready())return;
            if(RECONNECT){
                if(state==-1){next(100);return;}if(seconds()<12)return;
                checkLanding(c,true);capture(c,"reconnected-safe-station.png");
                var r=new JsonObject();r.addProperty("pass",true);r.addProperty("same_offline_identity",true);r.addProperty("health",c.field_1724.method_6032());write("recovery.json",r);finish(c);return;
            }
            if(TRANSPORT||MECHANICS&&state>=100){transport(c);return;}
            if(!c.field_1724.method_5805())throw new IllegalStateException("Player died");
            if(DreamScreen.step>dreamCaptured&&DreamScreen.alpha()>.98f&&DreamScreen.renderedFrames>=3){
                capture(c,"sleep-dream-"+DreamScreen.step+".png");var r=new JsonObject();r.addProperty("step",DreamScreen.step);r.addProperty("sleeping_at_capture",c.field_1724.method_6113());write("dream-"+DreamScreen.step+".json",r);dreamCaptured=DreamScreen.step;
            }
            if(c.field_1724.method_5765()){
                var p=c.field_1724.method_5854();var r=new JsonObject();r.addProperty("state",state);r.addProperty("x",p.method_23317());r.addProperty("y",p.method_23318());r.addProperty("z",p.method_23321());r.addProperty("passenger_dx",c.field_1724.method_23317()-p.method_23317());r.addProperty("passenger_dz",c.field_1724.method_23321()-p.method_23321());motion.add(r);
            }
            if(Boolean.getBoolean("abyss.capture.v1.second")){
                if(state==-1){if(!c.field_1724.method_5687(2))return;cmd(c,"view overview");next(90);return;}
                if(readyFrame(c)){capture(c,"second-seed-overview.png");finish(c);}return;
            }
            if(state==-1){next(-2);return;}
            if(state==-2){if(seconds()<5||!c.field_1724.method_5687(2))return;cmd(c,"view outside");next(-3);return;}
            if(state==-3){if(seconds()<5)return;cmd(c,"sleepstate before-1");cmd(c,"bedtime");next(0);return;}
            if(state==0){
                if(seconds()<3)return;var p=new class_2338(JourneyClient.x+400,c.field_1724.method_31478(),JourneyClient.z+70);
                if(Math.abs(c.field_1724.method_23317()-(JourneyClient.x+401.5))>2||!c.field_1687.method_8320(p).method_27852(net.minecraft.class_2246.field_10527)){
                    if(seconds()>25)throw new IllegalStateException("Sleep fixture did not arrive at "+c.field_1724.method_19538()+" bed="+c.field_1687.method_8320(p));return;
                }
                c.field_1761.method_2896(c.field_1724,class_1268.field_5808,new class_3965(class_243.method_24953(p),class_2350.field_11036,p,false));slept=false;next(1);return;
            }
            if(state==1){
                slept|=c.field_1724.method_6113();if(!slept||c.field_1724.method_6113()||DreamScreen.step!=0){if(seconds()>40)throw new IllegalStateException("Sleep/wake flow did not finish; observed="+slept+" sleeping="+c.field_1724.method_6113()+" dream="+DreamScreen.step+" at="+c.field_1724.method_19538());return;}
                cmd(c,"sleepstate after-"+(night+1));
                if(++night<2){cmd(c,"sleepstate before-2");cmd(c,"bedtime");next(0);return;}
                if(dreamCaptured!=2||!c.field_1724.method_31548().method_7379(new net.minecraft.class_1799(Journey.ECHO)))throw new IllegalStateException("Sleep dreams or guide absent");
                c.field_1690.field_1842=true;cmd(c,"view entrance");next(MECHANICS?100:2);return;
            }
            if(state==2){if(!readyFrame(c))return;capture(c,"upper-station.png");bell(c,true);next(3);return;}
            if(state==3){if(!c.field_1724.method_5765()){if(seconds()>10)throw new IllegalStateException("Boarding failed");return;}next(4);return;}
            if(state==4){if(c.field_1724.method_5765()){if(seconds()>100)throw new IllegalStateException("Ride deadline");return;}checkLanding(c,false);cmd(c,"view overview");next(5);return;}
            if(state==91){if(!readyFrame(c))return;capture(c,"town-culling-disabled.png");c.field_1730=true;cmd(c,"view rift");next(6);return;}
            if(state>=5&&state<=9){
                if(!readyFrame(c))return;String[] names={"town-in-abyss.png","main-rift.png","folded-gallery.png","warm-return.png","town-street.png"};String[] views={"rift","gallery","homeward","street"};
                capture(c,names[state-5]);if(state==5){c.field_1730=false;next(91);return;}if(state<9){cmd(c,"view "+views[state-5]);next(state+1);}else{cmd(c,"view route-start");next(10);}return;
            }
            if(state==10){if(seconds()<5)return;leg=1;walkX=c.field_1724.method_23317();walkZ=c.field_1724.method_23321();next(11);return;}
            if(state==11){
                if(leg==ROUTE.length){c.field_1690.field_1894.method_23481(false);capture(c,"walk-return-to-town.png");cmd(c,"view lower");next(12);return;}
                double dx=JourneyClient.x+ROUTE[leg][0]-c.field_1724.method_23317(),dz=JourneyClient.z+ROUTE[leg][1]-c.field_1724.method_23321();
                c.field_1724.method_36456((float)Math.toDegrees(Math.atan2(-dx,dz)));c.field_1724.method_36457(0);c.field_1690.field_1894.method_23481(true);
                if(Math.hypot(dx,dz)>.4){if(seconds()>60)throw new IllegalStateException("Loop blocked leg "+leg+" at "+c.field_1724.method_19538());return;}
                c.field_1690.field_1894.method_23481(false);var r=new JsonObject();r.addProperty("leg",leg);r.addProperty("start_x",walkX);r.addProperty("start_z",walkZ);r.addProperty("end_x",c.field_1724.method_23317());r.addProperty("end_y",c.field_1724.method_23318());r.addProperty("end_z",c.field_1724.method_23321());r.addProperty("health",c.field_1724.method_6032());r.addProperty("flying",c.field_1724.method_31549().field_7479);walks.add(r);write("walk.json",walks);
                if(c.field_1724.method_31549().field_7479||c.field_1724.method_6032()<20)throw new IllegalStateException("Unsafe exploration walk");
                if(leg==9||leg==15)capture(c,"walk-gallery-"+leg+".png");leg++;walkX=c.field_1724.method_23317();walkZ=c.field_1724.method_23321();changed=System.nanoTime();return;
            }
            if(state==12){if(seconds()<4)return;bell(c,false);next(13);return;}
            if(state==13){if(!c.field_1724.method_5765()){if(seconds()>10)throw new IllegalStateException("Return boarding failed");return;}next(14);return;}
            if(state==14){if(c.field_1724.method_5765()){if(seconds()>100)throw new IllegalStateException("Return ride deadline");return;}checkLanding(c,true);write("motion.json",motion);cmd(c,"debugcheck");finish(c);}
        }catch(Exception ex){var r=new JsonObject();r.addProperty("state",state);r.addProperty("leg",leg);r.addProperty("error",ex.toString());if(c.field_1724!=null){r.addProperty("position",c.field_1724.method_19538().toString());r.addProperty("permission",c.field_1724.method_5687(2));r.addProperty("sleeping",c.field_1724.method_6113());r.addProperty("dream_step",DreamScreen.step);try{capture(c,"failure-state.png");}catch(Exception ignored){}}write("failure.json",r);ex.printStackTrace();done=true;c.field_1690.field_1894.method_23481(false);c.field_1690.field_1832.method_23481(false);c.method_1592();}
    }
    private void transport(class_310 c)throws Exception{
        if(state==-1){if(!c.field_1724.method_5687(2))return;cmd(c,"view entrance");next(100);return;}
        if(state==100){if(seconds()<8)return;bell(c,true);next(101);return;}
        if(state==101){
            if(seconds()<8)return;if(!c.field_1724.method_5765())throw new IllegalStateException("Early-exit test failed to board");
            c.field_1690.field_1832.method_23481(true);next(102);return;
        }
        if(state==102){
            if(seconds()<3)return;c.field_1690.field_1832.method_23481(false);
            if(c.field_1724.method_5765())throw new IllegalStateException("Early-exit still riding");
            checkLanding(c,true);capture(c,"emergency-safe-return.png");
            var r=new JsonObject();r.addProperty("pass",true);r.addProperty("health",c.field_1724.method_6032());write("emergency.json",r);
            bell(c,true);next(103);return;
        }
        if(state==103){
            if(seconds()<10)return;if(!c.field_1724.method_5765())throw new IllegalStateException("Restart test failed to board");
            if(!restartReady){var r=new JsonObject();r.addProperty("riding_before_stop",true);r.addProperty("y",c.field_1724.method_23318());write("restart-ready.json",r);restartReady=true;}
            if(seconds()>90)throw new IllegalStateException("Server did not stop during journey");
        }
    }
    private boolean readyFrame(class_310 c){
        if(seconds()>160)throw new IllegalStateException("Unsettled chunks "+c.field_1769.method_3289());
        return seconds()>18&&c.field_1769.method_3289().matches(".*pC: 0+, pU: 0+(?:,|\\s|$).*");
    }
    private void checkLanding(class_310 c,boolean upper){
        if(c.field_1724.method_5765()||Math.abs(c.field_1724.method_23317()-(JourneyClient.x+(upper?6.5:30.5)))>.3||Math.abs(c.field_1724.method_23321()-(JourneyClient.z+(upper?70.5:58.5)))>.3||Math.abs(c.field_1724.method_23318()-(upper?JourneyClient.entryY+1:45))>.3||c.field_1724.method_6032()!=20)throw new IllegalStateException("Incorrect safe station");
    }
    private void capture(class_310 c,String name)throws Exception{
        Files.createDirectories(OUT);try(var f=class_318.method_1663(c.method_1522())){f.method_4314(OUT.resolve(name));}
        var r=new JsonObject();r.addProperty("file",name);r.addProperty("position",c.field_1724.method_19538().toString());r.addProperty("yaw",c.field_1724.method_36454());r.addProperty("pitch",c.field_1724.method_36455());r.addProperty("health",c.field_1724.method_6032());r.addProperty("sleeping",c.field_1724.method_6113());r.addProperty("chunk_culling",c.field_1730);r.addProperty("cavern_backdrop_active",JourneyClient.cavernBackdropActive(c.field_1773.method_19418()));r.addProperty("camera_sky_light",c.field_1687.method_8314(net.minecraft.class_1944.field_9284,class_2338.method_49638(c.field_1773.method_19418().method_19326())));r.addProperty("dream_rendered_frames",DreamScreen.renderedFrames);r.addProperty("chunk_debug",c.field_1769.method_3289());r.addProperty("gl_error",GL11.glGetError());r.addProperty("renderer",GL11.glGetString(GL11.GL_RENDERER));r.add("environment",EnvironmentClient.measurements());frames.add(r);write("captures.json",frames);
    }
    private void finish(class_310 c){var r=new JsonObject();r.addProperty("status","SPATIAL_PREVIEW_CAPTURED");r.addProperty("android_tested",false);r.addProperty("aesthetic_accepted",false);write("result.json",r);done=true;c.field_1690.field_1894.method_23481(false);c.field_1690.field_1832.method_23481(false);c.method_1592();}
    private void write(String name,Object value){try{Files.createDirectories(OUT);Files.writeString(OUT.resolve(name),new GsonBuilder().setPrettyPrinting().create().toJson(value));}catch(Exception ex){throw new IllegalStateException(ex);}}
}
