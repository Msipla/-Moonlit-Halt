package dev.mispla.abyss.mixin;

import dev.mispla.abyss.SceneSafety;
import net.minecraft.class_1308;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1308.class)
public abstract class SceneMobTickMixin {
    @Inject(method="tick",at=@At("HEAD"),cancellable=true)
    private void abyss$removeEnteringMob(CallbackInfo ci){
        var mob=(class_1308)(Object)this;
        if(mob.method_37908() instanceof class_3218 w&&SceneSafety.protects(w,mob.method_23317(),mob.method_23318(),mob.method_23321())){mob.method_31472();ci.cancel();}
    }
}
