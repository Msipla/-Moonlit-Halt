package dev.mispla.abyss;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import dev.mispla.abyss.GlimmeringAbyss.View;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.List;
import net.minecraft.class_1944;
import net.minecraft.class_2168;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3492;
import net.minecraft.class_3499;
import net.minecraft.class_7923;

/** Explicit, local Phase 5 research placement. No generator or render changes. */
public final class Exploration {
    public static final class_2338 ORIGIN = new class_2338(-32,-63,-20);
    public static final List<GlimmeringAbyss.View> VIEWS = List.of(
        Architecture.VIEWS.get(0),
        new GlimmeringAbyss.View("core",4.5,39,34.5,-115,12),
        new GlimmeringAbyss.View("down",4.5,39,33.4,180,65),
        new GlimmeringAbyss.View("span",-7.5,57,62.5,180,25),
        new GlimmeringAbyss.View("departure",30.5,39,43.5,98,0),
        new GlimmeringAbyss.View("arrival",-29.5,39,35.5,-90,-8),
        Architecture.VIEWS.get(1), Architecture.VIEWS.get(4));
    private Exploration() {}
    private static class_3218 world(class_2168 s) {
        var w=s.method_9211().method_3847(GlimmeringAbyss.STUDY);
        if(w==null)throw new IllegalStateException("Study dimension missing");return w;
    }
    private static class_3499 template(class_3218 w) {
        return w.method_14183().method_15094(GlimmeringAbyss.id("exploration"))
            .orElseThrow(()->new IllegalStateException("Packaged exploration template missing"));
    }
    public static int place(class_2168 s) {
        try {
            var w=world(s);var t=template(w);
            var data=new class_3492().method_15133(true).method_15131(true);
            if(!t.method_15172(w,ORIGIN,ORIGIN,data,w.field_9229,class_2248.field_31028|class_2248.field_31031))throw new IllegalStateException("Exploration placement failed");
            s.method_9226(()->class_2561.method_43470("[Abyss] Phase 5 route ready. /abyss route view departure | core | arrival; /abyssrender blue"),false);return 1;
        }catch(Exception e){e.printStackTrace();s.method_9213(class_2561.method_43470(e.getMessage()));return 0;}
    }
    public static int view(class_2168 s,String name) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        var v=VIEWS.stream().filter(x->x.name().equals(name)).findFirst().orElse(null);
        if(v==null){s.method_9213(class_2561.method_43470("facade | core | down | span | departure | arrival | warmth | interior"));return 0;}
        var p=s.method_9207();if(name.equals("span")&&!p.method_7337()){s.method_9213(class_2561.method_43470("Span view requires Creative mode"));return 0;}
        p.method_31549().field_7479=name.equals("span");p.method_7355();p.method_14251(world(s),v.x(),v.y(),v.z(),v.yaw(),v.pitch());return 1;
    }
    private static <T extends Comparable<T>> String value(class_2680 s,class_2769<T> p){return p.method_11901(s.method_11654(p));}
    private static boolean clear(class_3218 w,class_2338 p) {
        var floor=w.method_8320(p.method_10074()).method_26220(w,p.method_10074());
        return !floor.method_1110()&&floor.method_1105(class_2350.class_2351.field_11052)==1.0
            &&w.method_8320(p).method_26220(w,p).method_1110()&&w.method_8320(p.method_10084()).method_26220(w,p.method_10084()).method_1110();
    }
    public static int audit(class_2168 s,String label) {
        try {
            if(!label.matches("[a-zA-Z0-9_-]{1,40}"))throw new IllegalArgumentException("Invalid label");
            var w=world(s);var n=template(w).method_15175(new class_2487());var palette=n.method_10554("palette",class_2520.field_33260);var list=n.method_10554("blocks",class_2520.field_33260);
            int mismatch=0,stateMismatch=0,windows=0,lit=0;var digest=MessageDigest.getInstance("SHA-256");
            for(int i=0;i<list.size();i++) {
                var e=list.method_10602(i);var xyz=e.method_10554("pos",class_2520.field_33253);var p=ORIGIN.method_10069(xyz.method_10600(0),xyz.method_10600(1),xyz.method_10600(2));
                var expected=palette.method_10602(e.method_10550("state"));var actual=w.method_8320(p);String id=class_7923.field_41175.method_10221(actual.method_26204()).toString();
                if(!expected.method_10558("Name").equals(id))mismatch++;
                var props=expected.method_10562("Properties");
                for(var prop:actual.method_28501())if(props.method_10545(prop.method_11899())&&!props.method_10558(prop.method_11899()).equals(value(actual,prop)))stateMismatch++;
                digest.update((p.method_23854()+"="+actual+"\n").getBytes(java.nio.charset.StandardCharsets.UTF_8));
                if(expected.method_10558("Name").equals("glimmeringabyss:warm_window")){windows++;if(actual.method_27852(GlimmeringAbyss.WARM_WINDOW)&&w.method_8314(class_1944.field_9282,p)==12)lit++;}
            }
            boolean route=true,rails=true,shaft=true;int samples=0,railChecks=0,voidChecks=0;
            for(int z=35;z<=43;z++){route&=clear(w,new class_2338(42,39,z));samples++;}
            for(int x=30;x<=42;x++){route&=clear(w,new class_2338(x,39,43));samples++;}
            for(int z=35;z<=43;z++){route&=clear(w,new class_2338(30,39,z));samples++;}
            for(int x=-29;x<=30;x++)for(int z=34;z<=36;z++){route&=clear(w,new class_2338(x,39,z));samples++;}
            for(int z=30;z<=35;z++){route&=clear(w,new class_2338(-29,39,z));samples++;}
            for(int x=-24;x<=28;x++)for(int z:new int[]{32,38})for(int y:new int[]{39,40}){
                var p=new class_2338(x,y,z);rails&=w.method_8320(p).method_27852(class_2246.field_10576)&&!w.method_8320(p).method_26220(w,p).method_1110();railChecks++;
            }
            // Check actual unobstructed 100-block drops below the center of span.
            for(int x=-14;x<=20;x+=2)for(int y=-62;y<=37;y++){
                var p=new class_2338(x,y,35);shaft&=w.method_8320(p).method_26215();voidChecks++;
            }
            for(int x=-14;x<=20;x+=2)shaft&=w.method_8320(new class_2338(x,-63,35)).method_27852(class_2246.field_10458);
            var r=new JsonObject();r.addProperty("label",label);r.addProperty("template_blocks_checked",list.size());r.addProperty("block_id_mismatches",mismatch);r.addProperty("explicit_property_mismatches",stateMismatch);
            r.addProperty("actual_structure_state_sha256",HexFormat.of().formatHex(digest.digest()));r.addProperty("warm_window_blocks",windows);r.addProperty("warm_windows_native_light_12",lit);
            r.addProperty("route_samples",samples);r.addProperty("connected_route_collision_clearance_pass",route);r.addProperty("iron_rail_samples",railChecks);r.addProperty("iron_rail_collision_pass",rails);
            r.addProperty("vertical_air_samples",voidChecks);r.addProperty("finite_vertical_shaft_pass",shaft);r.addProperty("shaft_floor_y",-63);r.addProperty("walk_surface_y",39);
            r.addProperty("template_entities",n.method_10554("entities",class_2520.field_33260).size());r.addProperty("pass",mismatch==0&&stateMismatch==0&&windows>0&&windows==lit&&route&&rails&&shaft);
            Path out=Path.of("abyss-results");Files.createDirectories(out);Files.writeString(out.resolve("exploration-"+label+".json"),new GsonBuilder().setPrettyPrinting().create().toJson(r));
            s.method_9226(()->class_2561.method_43470("[Abyss] Exploration "+label+" / "+r),false);return r.get("pass").getAsBoolean()?1:0;
        }catch(Exception e){e.printStackTrace();s.method_9213(class_2561.method_43470(e.getMessage()));return 0;}
    }
}
