package dev.mispla.abyss;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

import static net.minecraft.class_2170.method_9247;

/** No destructive regeneration, no candidate coordinates, no survival bypass. */
public final class CreativeDebug {
    private CreativeDebug(){}
    private static boolean creative(class_2168 s){return s.method_9228() instanceof net.minecraft.class_3222 p&&p.method_7337();}
    public static void initialize(){
        CommandRegistrationCallback.EVENT.register((d,a,e)->d.register(method_9247("abyss").then(method_9247("debug").requires(CreativeDebug::creative)
            .then(method_9247("status").executes(c->{var p=c.getSource().method_9207();var s=OverworldSite.get(p.method_5682().method_30002());p.method_7353(class_2561.method_43470(DiscoveryStatus.describe(s.stage,s.cursor,s.attempt,s.reason,s.dreams.getOrDefault(p.method_5667(),0),s.chunks())+" 布局版本："+s.layout),false);return 1;}))
            .then(method_9247("entrance").executes(c->land(c.getSource(),true)))
            .then(method_9247("town").executes(c->land(c.getSource(),false)))
            .then(method_9247("dream").then(method_9247("1").executes(c->{Journey.previewDream(c.getSource().method_9207(),1);return 1;})).then(method_9247("2").executes(c->{Journey.previewDream(c.getSource().method_9207(),2);return 1;})))
            .then(method_9247("ride").executes(c->{var p=c.getSource().method_9207();var s=OverworldSite.get(p.method_5682().method_30002());if(!s.ready()||!p.method_37908().method_27983().equals(net.minecraft.class_1937.field_25179)||p.method_19538().method_1025(net.minecraft.class_243.method_24953(s.landing(p.method_23318()>100)))>100){p.method_7353(class_2561.method_43470("请先定位到已生成的安全站台，再测试乘车。"),false);return 0;}Journey.board(p,s,p.method_23318()>100);return 1;}))
        )));
    }
    private static int land(class_2168 source,boolean upper)throws com.mojang.brigadier.exceptions.CommandSyntaxException{
        var p=source.method_9207();var s=OverworldSite.get(source.method_9211().method_30002());
        if(!s.ready()){p.method_7353(class_2561.method_43470(DiscoveryStatus.describe(s.stage,s.cursor,s.attempt,s.reason,0,s.chunks())),false);return 0;}
        if(p.method_5765()){p.method_7353(class_2561.method_43470("请先结束乘车。"),false);return 0;}
        // Reuse safe landing only after world generation has completed.
        Journey.land(p,s,upper);p.method_7353(class_2561.method_43470("测试定位：已到达生成完成的安全站台。"),false);return 1;
    }
}
