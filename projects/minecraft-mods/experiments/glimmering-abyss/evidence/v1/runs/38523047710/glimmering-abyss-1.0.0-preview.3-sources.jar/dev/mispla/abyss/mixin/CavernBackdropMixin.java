package dev.mispla.abyss.mixin;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.mispla.abyss.JourneyClient;
import net.minecraft.class_4184;
import net.minecraft.class_638;
import net.minecraft.class_758;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/** Underground layout-100 background matches cavern air, while native fog distances stay intact. */
@Mixin(class_758.class)
public abstract class CavernBackdropMixin {
    @Shadow private static float red;
    @Shadow private static float green;
    @Shadow private static float blue;
    @Inject(method="render",at=@At("TAIL"))
    private static void abyss$backdrop(class_4184 camera,float delta,class_638 world,int distance,float skyDarkness,CallbackInfo ci){
        if(JourneyClient.cavernBackdropActive(camera)){
            red=.012f;green=.033f;blue=.055f;
            RenderSystem.clearColor(red,green,blue,0);
            RenderSystem.setShaderFogColor(red,green,blue);
        }
    }
}
