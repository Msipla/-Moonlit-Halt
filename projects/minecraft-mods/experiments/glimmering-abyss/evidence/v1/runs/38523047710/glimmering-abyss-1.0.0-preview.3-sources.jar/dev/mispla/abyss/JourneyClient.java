package dev.mispla.abyss;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_310;

public final class JourneyClient implements ClientModInitializer {
    private static boolean ready;
    public static int x,z,entryY,approachLength,approachY,layout;
    @Override public void onInitializeClient(){
        EntityRendererRegistry.register(Journey.CAR,CableCarRenderer::new);
        ClientPlayNetworking.registerGlobalReceiver(Journey.SITE_PACKET,(client,handler,b,response)->{
            boolean ok=b.readBoolean();int nx=b.readInt(),nz=b.readInt(),ny=b.readInt(),nl=b.readInt(),na=b.readInt(),version=b.readInt();
            client.execute(()->{ready=ok;x=nx;z=nz;entryY=ny;approachLength=nl;approachY=na;layout=version;});
        });
        ClientPlayNetworking.registerGlobalReceiver(Journey.DREAM_PACKET,(client,handler,b,response)->{
            int step=b.readInt();client.execute(()->{
                if(step>0&&step<=2)DreamScreen.start(step,client.field_1724!=null&&client.field_1724.method_6113());
                else DreamScreen.wake();
            });
        });
        net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback.EVENT.register((context,delta)->{
            if(class_310.method_1551().field_1755==null)DreamScreen.render(context,delta);
        });
        net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AFTER_INIT.register((client,screen,width,height)->
            net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.afterRender(screen).register((s,context,mx,my,delta)->DreamScreen.render(context,delta)));
        ClientPlayConnectionEvents.DISCONNECT.register((handler,client)->{ready=false;DreamScreen.clear();});
    }
    public static boolean cavernBackdropActive(net.minecraft.class_4184 camera){
        var c=class_310.method_1551();
        return layout>=100&&origin()!=null
            &&camera.method_19334()==net.minecraft.class_5636.field_27888
            &&c.field_1687.method_8314(net.minecraft.class_1944.field_9284,class_2338.method_49638(camera.method_19326()))==0;
    }
    public static boolean ready(){return ready;}
    public static class_2338 origin(){
        var c=class_310.method_1551();if(!ready||c.field_1687==null||!c.field_1687.method_27983().equals(class_1937.field_25179))return null;
        var p=c.field_1773.method_19418().method_19326();
        if(p.field_1352<x-(layout>=100?212:120)||p.field_1352>x+(layout>=100?132:120)||p.field_1350<z-(layout>=100?324:184)||p.field_1350>z+(layout>=100?132:120)||p.field_1351< -60||p.field_1351>116)return null;
        return new class_2338(x,OverworldSite.OFFSET_Y,z);
    }
}
