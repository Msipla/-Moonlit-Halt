package dev.mispla.abyss;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_18;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_3218;

/** One seed-selected, versioned landscape per save. No global static world state. */
public final class OverworldSite extends class_18 {
    public static final int MIN_X=-112, MAX_X=111, MIN_Z=-176, MAX_Z=111, OFFSET_Y=6;
    public static final int CHUNKS=14*18;
    public int x,z,entryY,attempt,cursor,approachLength,approachY;
    public int layout=101;
    public int[] columnCaps=new int[0];
    public String stage="search";
    public String reason="";
    public final Map<UUID,Integer> dreams=new HashMap<>();
    public final Map<UUID,Long> dreamDays=new HashMap<>();
    public final Map<UUID,Boolean> journeys=new HashMap<>();
    // Runtime-only recovery: an unfinished placement is replayed idempotently.
    public boolean resumed;
    public final java.util.List<String> caps=new java.util.ArrayList<>();
    public static OverworldSite get(class_3218 w){
        return w.method_17983().method_17924(OverworldSite::read,OverworldSite::new,"glimmeringabyss_site_v1");
    }
    private static OverworldSite read(class_2487 n){
        var s=new OverworldSite();s.x=n.method_10550("x");s.z=n.method_10550("z");s.entryY=n.method_10550("entryY");
        s.layout=n.method_10545("layout")?n.method_10550("layout"):70;s.columnCaps=n.method_10561("columnCaps");
        s.approachLength=n.method_10550("approachLength");s.approachY=n.method_10550("approachY");
        s.attempt=n.method_10550("attempt");s.cursor=n.method_10550("cursor");s.stage=n.method_10558("stage");s.reason=n.method_10558("reason");
        if(s.stage.equals("carve")){s.cursor=0;s.resumed=true;}
        if(s.stage.equals("check"))s.cursor=0;
        var cs=n.method_10554("caps",net.minecraft.class_2520.field_33258);for(int i=0;i<cs.size();i++)s.caps.add(cs.method_10608(i));
        var d=n.method_10562("dreams");for(String k:d.method_10541())s.dreams.put(UUID.fromString(k),d.method_10550(k));
        d=n.method_10562("dreamDays");for(String k:d.method_10541())s.dreamDays.put(UUID.fromString(k),d.method_10537(k));
        d=n.method_10562("journeys");for(String k:d.method_10541())s.journeys.put(UUID.fromString(k),d.method_10577(k));
        return s;
    }
    @Override public class_2487 method_75(class_2487 n){
        n.method_10569("layout",layout);if(columnCaps.length>0)n.method_10539("columnCaps",columnCaps);
        n.method_10569("approachLength",approachLength);n.method_10569("approachY",approachY);n.method_10569("schema",1);n.method_10569("x",x);n.method_10569("z",z);n.method_10569("entryY",entryY);n.method_10569("attempt",attempt);n.method_10569("cursor",cursor);n.method_10582("stage",stage);n.method_10582("reason",reason);
        var cs=new net.minecraft.class_2499();caps.forEach(v->cs.add(net.minecraft.class_2519.method_23256(v)));n.method_10566("caps",cs);
        var d=new class_2487();dreams.forEach((k,v)->d.method_10569(k.toString(),v));n.method_10566("dreams",d);
        var days=new class_2487();dreamDays.forEach((k,v)->days.method_10544(k.toString(),v));n.method_10566("dreamDays",days);
        var rides=new class_2487();journeys.forEach((k,v)->rides.method_10556(k.toString(),v));n.method_10566("journeys",rides);return n;
    }
    public int minX(){return layout>=100?-208:MIN_X;}
    public int maxX(){return layout>=100?127:MAX_X;}
    public int minZ(){return layout>=100?-320:MIN_Z;}
    public int maxZ(){return layout>=100?127:MAX_Z;}
    public int widthChunks(){return (maxX()-minX()+1)/16;}
    public int chunks(){return widthChunks()*(maxZ()-minZ()+1)/16;}
    public int chunkX(int index){return x/16+minX()/16+index%widthChunks();}
    public int chunkZ(int index){return z/16+minZ()/16+index/widthChunks();}
    public int capIndex(int lx,int lz){return (lx-minX())*(maxZ()-minZ()+1)+lz-minZ();}
    public void resetCaps(){columnCaps=new int[(maxX()-minX()+1)*(maxZ()-minZ()+1)];java.util.Arrays.fill(columnCaps,Integer.MIN_VALUE);}
    public int dockX(){return layout>=100?24:0;}
    public int dockZ(){return layout>=100?58:70;}
    public class_2338 at(int lx,int ly,int lz){return new class_2338(x+lx,ly+OFFSET_Y,z+lz);}
    public boolean ready(){return stage.equals("ready");}
    public boolean reserved(){return stage.equals("carve")||ready();}
    public boolean contains(double px,double py,double pz){
        if(!reserved())return false;
        double lx=px-x,lz=pz-z;
        // Whole cavern volume plus its separate surface station and shaft.
        return lx>=minX()&&lx<=maxX()+1&&lz>=minZ()&&lz<=maxZ()+1&&py>=-58&&py<=117
            || lx>=-10&&lx<=13+approachLength&&lz>=60&&lz<=81&&py>=45&&py<=Math.max(entryY,approachY)+9;
    }
    public class_2338 approach(){return new class_2338(x+9+approachLength,approachY+1,z+70);}
    public class_2338 landing(boolean upper){return new class_2338(x+6+(upper?0:dockX()),upper?entryY+1:45,z+(upper?70:dockZ()));}
}
