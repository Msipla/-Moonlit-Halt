package dev.mispla.abyss;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2338.class_2339;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2507;
import net.minecraft.class_2512;
import net.minecraft.class_2520;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2818;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3754;
import net.minecraft.class_7923;
import ;
import dev.mispla.abyss.Terrain.Column;
import dev.mispla.abyss.Terrain.Fixture;
import java.io.InputStream;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Random;

/** Bounded preflight, then one chunk per tick. Never changes the overworld generator. */
public final class OverworldLandscape {
    private static short[] town;
    private static class_2680[] palette;
    private static final int SX=139,SY=143,SZ=180;
    private static short[] naturalTown;
    private static class_2680[] naturalPalette;
    private static Blueprint abyssTown,settlementTown;
    private record Blueprint(int sx,int sy,int sz,short[] blocks,class_2680[] palette){
        class_2680 at(int x,int y,int z){
            int dx=x+180,dy=y+8,dz=z+290;
            if(dx<0||dx>=sx||dy<0||dy>=sy||dz<0||dz>=sz)return null;
            int i=blocks[(dx*sz+dz)*sy+dy];return i<0?null:palette[i];
        }
    }
    private static final int FLAGS=class_2248.field_31028|class_2248.field_31031;
    private OverworldLandscape(){}
    public static void initialize(){ServerTickEvents.END_SERVER_TICK.register(server->{
        if(!Boolean.parseBoolean(System.getProperty("abyss.worldgen.enabled","true")))return;
        var w=server.method_30002();if(w.method_8510()%2==0)tick(w);
    });}
    private static int height(class_3218 w,int x,int z){return w.method_14178().method_12129().method_16397(x,z,class_2902.class_2903.field_13195,w,w.method_14178().method_41248());}
    /** World.getTopY returns bottom Y for an unloaded remote chunk. Load explicitly. */
    public static int surface(class_3218 w,class_2902.class_2903 type,int x,int z){
        return w.method_8497(x>>4,z>>4).method_12005(type,x&15,z&15)+1;
    }
    private static int ground(class_3218 w,int x,int z){
        var p=new class_2338.class_2339(x,surface(w,class_2902.class_2903.field_13203,x,z)-1,z);
        while(p.method_10264()>w.method_31607()){
            var b=w.method_8320(p);
            if(b.method_26212(w,p)&&!b.method_26164(net.minecraft.class_3481.field_15475)&&!b.method_26164(net.minecraft.class_3481.field_15503))return p.method_10264();
            p.method_10098(net.minecraft.class_2350.field_11033);
        }
        return w.method_31607();
    }
    private static boolean planApproach(class_3218 w,OverworldSite s){
        s.entryY=ground(w,s.x,s.z+70)+1;
        if(s.entryY<100||s.entryY>240)return false;
        for(int length=8;length<=32;length+=4){
            int y=ground(w,s.x+9+length,s.z+70);
            if(Math.abs(y-s.entryY)<length){s.approachLength=length;s.approachY=y;return true;}
        }
        return false;
    }
    public static int ceiling(int x,int z){
        return CavernShape.ceiling(x,z)+OverworldSite.OFFSET_Y;
    }
    public static int ceiling(OverworldSite s,int x,int z){
        if(s.layout>=100)return AbyssShape.ceiling(x,z)+OverworldSite.OFFSET_Y;
        if(s.layout>=75)return ceiling(x,z);
        var c=Terrain.column(x,z,Terrain.SEED);
        int top=(int)Math.ceil(c.roof())+4;
        if(x>=-55&&x<=83&&z>=-106&&z<=73)top=Math.max(top,82);
        return Math.min(111,Math.max(48,top))+OverworldSite.OFFSET_Y;
    }
    private static boolean remote(int x,int z){return x<-112||x>111||z<-176||z>111;}
    private static int ceiling(class_3218 w,OverworldSite s,int x,int z){
        int cap=ceiling(s,x,z);
        if(s.layout>=100&&s.columnCaps.length>0){
            int saved=s.columnCaps[s.capIndex(x,z)];
            if(saved!=Integer.MIN_VALUE)return saved;
        }
        // Compatibility for an interrupted, unshipped first sample without persisted caps.
        if(s.layout>=100&&remote(x,z))cap=Math.min(cap,height(w,s.x+x,s.z+z)-16);
        return cap;
    }
    private static int routeCap(int layout,int x,int z){
        // A sparse blueprint has no claim on the rest of the terrain column.
        var blueprint=layout>=101?settlementTown:abyssTown;
        if(blueprint==null)return -58;
        for(int y=blueprint.sy-1-8;y>=-8;y--)if(blueprint.at(x,y,z)!=null)return y+4+OverworldSite.OFFSET_Y;
        return -58;
    }
    private static void tick(class_3218 w){
        var s=OverworldSite.get(w);
        if(s.ready()||s.stage.equals("unavailable"))return;
        try{
            if(!(w.method_14178().method_12129() instanceof class_3754)||w.method_31607()>-64){
                s.stage="unavailable";s.reason="Requires a normal height overworld with noise terrain";s.method_80();return;
            }
            if(s.layout>=100)loadAbyssTown(s.layout);
            if(s.stage.equals("search")){
                if(s.attempt>=4096){s.stage="unavailable";s.reason="No covered, uninhabited candidate in bounded search";s.method_80();return;}
                var rng=new Random(w.method_8412()^0x41B155L^(s.attempt*0x9E3779B97F4A7C15L));s.attempt++;
                int x=(rng.nextInt(1024)-512)*16,z=(rng.nextInt(1024)-512)*16;
                if(Math.abs(x)<768&&Math.abs(z)<768)return;
                if(height(w,x,z)<130)return;
                for(int lx=-112;lx<=111;lx+=32)for(int lz=-176;lz<=111;lz+=32)
                    if(!(s.layout>=100&&remote(lx,lz))&&height(w,x+lx,z+lz)<ceiling(s,lx,lz)+12)return;
                s.x=x;s.z=z;if(!planApproach(w,s))return;s.cursor=0;s.caps.clear();if(s.layout>=100)s.resetCaps();s.stage="check";s.method_80();
                System.out.println("ABYSS_SITE_CANDIDATE "+x+","+z+" attempt="+s.attempt);return;
            }
            int cx=s.chunkX(s.cursor),cz=s.chunkZ(s.cursor);
            var chunk=w.method_8497(cx,cz);
            if(s.stage.equals("check")){
                boolean valid=chunk.method_12033()==0;
                if(s.layout>=100&&s.columnCaps.length==0)s.resetCaps();
                for(int dx=0;dx<16&&valid;dx++)for(int dz=0;dz<16&&valid;dz++){
                    int wx=cx*16+dx,wz=cz*16+dz,top=ceiling(s,wx-s.x,wz-s.z);
                    // Exact full-footprint check after vanilla carving/surface/features, not only sampled noise heights.
                    int h=ground(w,wx,wz)+1; // Bare ground, never count a tree canopy as mountain cover.
                    if(s.layout>=100&&remote(wx-s.x,wz-s.z))top=Math.min(top,h-16);
                    if(s.layout>=100)s.columnCaps[s.capIndex(wx-s.x,wz-s.z)]=top;
                    if(h<top+10||s.layout>=100&&remote(wx-s.x,wz-s.z)&&top<routeCap(s.layout,wx-s.x,wz-s.z))valid=false;
                    // The painter retains a four-block solid local roof below this cap.
                    // Existing natural caves above it are permitted; requiring every native
                    // voxel to be solid would reject otherwise well-covered mountain sites.
                }
                if(!valid){s.stage="search";s.cursor=0;s.reason="Candidate rejected before edits: coverage or existing habitation";s.method_80();return;}
                if(s.caps.size()>s.cursor)s.caps.set(s.cursor,capHash(w,s,cx,cz));else s.caps.add(capHash(w,s,cx,cz));
                if(++s.cursor==s.chunks()){
                    // Dry, reachable station; the exact shaft is the sole intended surface opening.
                    if(s.entryY>240||s.entryY<100){s.stage="search";s.cursor=0;s.method_80();return;}
                    s.stage="carve";s.cursor=0;s.reason="";s.method_80();w.method_17983().method_125();
                    System.out.println("ABYSS_SITE_PREFLIGHT_PASS "+s.x+","+s.z+" entry="+s.entryY);
                }
                s.method_80();return;
            }
            if(s.stage.equals("carve")){
                loadTown();if(s.layout>=75)loadNaturalTown();if(s.layout>=100)loadAbyssTown(s.layout);paint(w,s,cx,cz);
                if(++s.cursor==s.chunks()){
                    stations(w,s);s.stage="ready";s.method_80();w.method_8503().method_3723(false,true,true);
                    Journey.syncAll(w.method_8503());System.out.println("ABYSS_SITE_READY "+s.x+","+s.z+" entry="+s.entryY);
                }
                s.method_80();
            }
        }catch(Exception e){s.reason=e.toString();s.method_80();System.err.println("ABYSS_SITE_ERROR "+s.stage+" "+s.cursor);e.printStackTrace();s.stage="unavailable";}
    }
    public static String capHash(class_3218 w,OverworldSite s,int cx,int cz){
        try{
            var hash=java.security.MessageDigest.getInstance("SHA-256");
            var chunk=w.method_8497(cx,cz);
            for(int dx=0;dx<16;dx++)for(int dz=0;dz<16;dz++){
                int x=cx*16+dx,z=cz*16+dz,lx=x-s.x,lz=z-s.z;
                if(lx>=-6&&lx<=9&&lz>=64&&lz<=77 || lx>=10&&lx<=10+s.approachLength&&lz>=67&&lz<=73)continue;
                int h=ground(w,x,z)+1;
                hash.update((h+":"+w.method_8320(new class_2338(x,h-1,z))+":"+w.method_8320(new class_2338(x,h-2,z))).getBytes(java.nio.charset.StandardCharsets.UTF_8));
                for(int y=-64;y<=-59;y++)hash.update(w.method_8320(new class_2338(x,y,z)).toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));
            }
            return java.util.HexFormat.of().formatHex(hash.digest());
        }catch(Exception e){throw new IllegalStateException(e);}
    }
    private static void loadTown()throws Exception{
        if(town!=null)return;
        try(var in=OverworldLandscape.class.getResourceAsStream("/data/glimmeringabyss/structures/town.nbt")){
            var n=class_2507.method_10629(in);var p=n.method_10554("palette",class_2520.field_33260);
            palette=new class_2680[p.size()];for(int i=0;i<p.size();i++)palette[i]=class_2512.method_10681(class_7923.field_41175.method_46771(),p.method_10602(i));
            town=new short[SX*SY*SZ];Arrays.fill(town,(short)-1);var b=n.method_10554("blocks",class_2520.field_33260);
            for(int i=0;i<b.size();i++){var row=b.method_10602(i);var a=row.method_10554("pos",class_2520.field_33253);town[(a.method_10600(0)*SZ+a.method_10600(2))*SY+a.method_10600(1)]=(short)row.method_10550("state");}
        }
    }
    static class_2680 townAt(int x,int y,int z){
        int dx=x+55,dy=y+63,dz=z+106;if(dx<0||dx>=SX||dy<0||dy>=SY||dz<0||dz>=SZ)return null;
        int i=town[(dx*SZ+dz)*SY+dy];return i<0?null:palette[i];
    }
    private static void loadNaturalTown()throws Exception{
        if(naturalTown!=null)return;
        try(var in=OverworldLandscape.class.getResourceAsStream("/data/glimmeringabyss/structures/natural_town.nbt")){
            var n=class_2507.method_10629(in);var p=n.method_10554("palette",class_2520.field_33260);
            naturalPalette=new class_2680[p.size()];for(int i=0;i<p.size();i++)naturalPalette[i]=class_2512.method_10681(class_7923.field_41175.method_46771(),p.method_10602(i));
            naturalTown=new short[148*46*180];Arrays.fill(naturalTown,(short)-1);var blocks=n.method_10554("blocks",class_2520.field_33260);
            for(int i=0;i<blocks.size();i++){var row=blocks.method_10602(i);var a=row.method_10554("pos",class_2520.field_33253);naturalTown[(a.method_10600(0)*180+a.method_10600(2))*46+a.method_10600(1)]=(short)row.method_10550("state");}
        }
    }
    private static class_2680 naturalAt(int x,int y,int z){
        int dx=x+64,dy=y-34,dz=z+106;if(dx<0||dx>=148||dy<0||dy>=46||dz<0||dz>=180)return null;
        int i=naturalTown[(dx*180+dz)*46+dy];return i<0?null:naturalPalette[i];
    }
    private static void loadAbyssTown(int layout)throws Exception{
        if((layout>=101?settlementTown:abyssTown)!=null)return;
        String name=layout>=101?"settlement_town":"abyss_town";
        try(var in=OverworldLandscape.class.getResourceAsStream("/data/glimmeringabyss/structures/"+name+".nbt")){
            var n=class_2507.method_10629(in);var p=n.method_10554("palette",class_2520.field_33260);var size=n.method_10554("size",class_2520.field_33253);
            int sx=size.method_10600(0),sy=size.method_10600(1),sz=size.method_10600(2);var palette=new class_2680[p.size()];
            for(int i=0;i<p.size();i++)palette[i]=class_2512.method_10681(class_7923.field_41175.method_46771(),p.method_10602(i));
            var blocks=new short[sx*sy*sz];Arrays.fill(blocks,(short)-1);var rows=n.method_10554("blocks",class_2520.field_33260);
            for(int i=0;i<rows.size();i++){var row=rows.method_10602(i);var a=row.method_10554("pos",class_2520.field_33253);blocks[(a.method_10600(0)*sz+a.method_10600(2))*sy+a.method_10600(1)]=(short)row.method_10550("state");}
            var blueprint=new Blueprint(sx,sy,sz,blocks,palette);if(layout>=101)settlementTown=blueprint;else abyssTown=blueprint;
        }
    }
    private static class_2680 abyssExpected(AbyssShape.Column c,int y){
        var t=(c.layout()>=101?settlementTown:abyssTown).at(c.x(),y,c.z());if(t!=null)return t;
        if(!c.rock(y))return class_2246.field_10124.method_9564();
        double stratum=y+.16*c.x()+4*Math.sin(c.z()*.021);
        if(c.layout()>=101&&c.x()>75){
            stratum+=.25*c.z()+5*Math.sin(c.x()*.044+c.z()*.036);
            if(Math.floorMod((int)Math.floor(stratum),29)<3)return class_2246.field_27165.method_9564();
            var axis=Math.sin(c.z()*.033+y*.021)>.35?net.minecraft.class_2350.class_2351.field_11048:net.minecraft.class_2350.class_2351.field_11052;
            return class_2246.field_28888.method_9564().method_11657(class_2741.field_12496,axis);
        }
        return (Math.floorMod((int)Math.floor(stratum),29)<2?class_2246.field_27165:class_2246.field_28888).method_9564();
    }
    private static class_2680 naturalExpected(CavernShape.Column c,int y){
        var t=naturalAt(c.x(),y,c.z());if(t!=null)return t;
        // Retain the proven entry balcony/walkway geometry, away from the geological shelf.
        if(Math.abs(c.x())<=22&&c.z()>=62&&c.z()<=77&&y>=38&&y<=46){
            int m=Terrain.materialAt(c.x(),y,c.z(),Terrain.SEED);
            if(m==Terrain.FLOOR)return class_2246.field_28892.method_9564();
            if(m==Terrain.AIR)return class_2246.field_10124.method_9564();
            if(m==Terrain.RAIL_NS)return class_2246.field_10576.method_9564().method_11657(class_2741.field_12489,true).method_11657(class_2741.field_12540,true);
            if(m==Terrain.RAIL_EW)return class_2246.field_10576.method_9564().method_11657(class_2741.field_12487,true).method_11657(class_2741.field_12527,true);
        }
        if(!c.rock(y))return class_2246.field_10124.method_9564();
        // Strata follow the rock, not an ornamental covering on the old box.
        double stratum=y+3*Math.sin(c.x()*.043)+2*Math.sin(c.z()*.057);
        return (Math.floorMod((int)Math.floor(stratum),23)<2?class_2246.field_27165:class_2246.field_28888).method_9564();
    }
    static class_2680 expected(Terrain.Column c,int y){
        int x=c.x(),z=c.z();var t=townAt(x,y,z);
        class_2680 state=t;
        if(state==null)state=switch(c.materialAt(y)){
            case Terrain.AIR -> class_2246.field_10124.method_9564();
            case Terrain.FLOOR -> class_2246.field_28892.method_9564();
            case Terrain.RAIL_NS -> class_2246.field_10576.method_9564().method_11657(class_2741.field_12489,true).method_11657(class_2741.field_12540,true);
            case Terrain.RAIL_EW -> class_2246.field_10576.method_9564().method_11657(class_2741.field_12487,true).method_11657(class_2741.field_12527,true);
            default -> class_2246.field_28888.method_9564();
        };
        // Add only low, irregular buttresses to the accepted shelf; walking floor/buildings/rails stay exact.
        if(y<35&&y>-62&&z>=-69&&z<=50&&x>=0&&x<=89&&c.pillarRatio()>1.4){
            double edge=22+(int)(2*Math.sin(z/13.0)+1.5*Math.sin(z/5.0));
            double foot=Math.min(14,(36-y)*.16),ripple=2*Math.sin(z*.19+y*.17)+Math.sin(y*.43+z*.11);
            if(x>=edge-foot+ripple&&x<=83+foot*.35&&z>=-65-foot*.25&&z<=46+foot*.25
                && (state.method_26215()||state.method_27852(class_2246.field_28888)||state.method_27852(class_2246.field_29031)))
                state=(Math.floorMod(y+z/7,17)<3?class_2246.field_29031:class_2246.field_28888).method_9564();
        }
        return state;
    }
    private static void paint(class_3218 w,OverworldSite s,int cx,int cz){
        var pos=new class_2338.class_2339();
        for(int dx=0;dx<16;dx++)for(int dz=0;dz<16;dz++){
            int x=cx*16+dx-s.x,z=cz*16+dz-s.z;var c=Terrain.column(x,z,Terrain.SEED);var natural=CavernShape.column(x,z);
            int top=ceiling(w,s,x,z)-OverworldSite.OFFSET_Y;var abyss=AbyssShape.column(x,z,top,s.layout);
            for(int y=-63;y<=top;y++){
                var state=s.layout>=100?abyssExpected(abyss,y):s.layout>=75?naturalExpected(natural,y):expected(c,y);pos.method_10103(s.x+x,y+OverworldSite.OFFSET_Y,s.z+z);
                if(!w.method_8320(pos).method_27852(class_2246.field_9987))w.method_8652(pos,state,FLAGS);
            }
        }
        for(var f:Terrain.fixtures(Terrain.SEED))if((s.x+f.x())>>4==cx&&(s.z+f.z())>>4==cz)
            w.method_8652(s.at(f.x(),f.y(),f.z()),GlimmeringAbyss.GLIMMER.method_9564(),FLAGS);
    }
    private static void set(class_3218 w,OverworldSite s,int x,int y,int z,class_2248 b){w.method_8652(new class_2338(s.x+x,y,s.z+z),b.method_9564(),class_2248.field_31036);}
    private static void stations(class_3218 w,OverworldSite s){
        // A sealed, nine-wide shaft, opened into the existing observation balcony.
        for(int x=-4;x<=4;x++)for(int z=66;z<=74;z++)for(int y=45;y<=s.entryY+5;y++){
            if(Math.abs(x)==4||z==66||z==74){
                if(y>(s.layout>=75?89:80))set(w,s,x,y,z,class_2246.field_28900);
            }else set(w,s,x,y,z,class_2246.field_10124);
        }
        for(int y:new int[]{44,s.entryY}){
            int ox=y==44?s.dockX():0,oz=y==44?s.dockZ()-70:0;
            for(int x=-6;x<=9;x++)for(int z=64;z<=77;z++){
                if(y==s.entryY&&x>=-3&&x<=3&&z>=67&&z<=73)continue;
                set(w,s,x+ox,y,z+oz,class_2246.field_28892);
                if(y==44&&s.layout>=100)for(int h=1;h<=8;h++)set(w,s,x+ox,y+h,z+oz,class_2246.field_10124);
                if(y==s.entryY){
                    for(int h=1;h<=4;h++)set(w,s,x,y+h,z,class_2246.field_10124);
                    if(x==-6||x==9||z==64||z==77)set(w,s,x,y+1,z,class_2246.field_28891);
                }
            }
            // Guard the upper shaft. Bell remotely boards the passenger into a closed cabin.
            if(y==s.entryY)for(int x=-4;x<=4;x++)for(int z=66;z<=74;z++)
                if(Math.abs(x)==4||z==66||z==74)set(w,s,x,y+1,z,class_2246.field_28891);
            set(w,s,6+ox,y+1,68+oz,Journey.BELL);set(w,s,7+ox,y+1,68+oz,class_2246.field_16541);
        }
        // A short guarded staircase meets actual native ground, with a three-wide opening in the outer rail.
        for(int step=0;step<=s.approachLength;step++){
            int x=9+step,y=s.entryY+(int)Math.round((s.approachY-s.entryY)*step/(double)s.approachLength);
            int next=step==s.approachLength?y:s.entryY+(int)Math.round((s.approachY-s.entryY)*(step+1)/(double)s.approachLength);
            int base=y+(next>y?1:0);
            for(int z=68;z<=72;z++){
                for(int h=1;h<=4;h++)set(w,s,x,base+h,z,class_2246.field_10124);
                for(int h=base-1;h>=base-16;h--){var p=new class_2338(s.x+x,h,s.z+z);if(w.method_8320(p).method_26212(w,p))break;set(w,s,x,h,z,class_2246.field_28900);}
                if(z==68||z==72){set(w,s,x,base,z,class_2246.field_28892);set(w,s,x,base+1,z,class_2246.field_28891);}
                else{
                    var floor=next==y?class_2246.field_28892.method_9564():class_2246.field_28893.method_9564().method_11657(class_2741.field_12481,next>y?net.minecraft.class_2350.field_11034:net.minecraft.class_2350.field_11039);
                    w.method_8652(new class_2338(s.x+x,base,s.z+z),floor,class_2248.field_31036);
                }
            }
        }
        // Footing under the surface platform: no floating station on a sloping mountain.
        for(int x=-6;x<=9;x++)for(int z=64;z<=77;z++)for(int y=s.entryY-1;y>=s.entryY-16;y--){
            if(x>=-3&&x<=3&&z>=67&&z<=73)continue;
            var p=new class_2338(s.x+x,y,s.z+z);if(w.method_8320(p).method_26212(w,p))break;
            set(w,s,x,y,z,class_2246.field_28900);
        }
    }
}
