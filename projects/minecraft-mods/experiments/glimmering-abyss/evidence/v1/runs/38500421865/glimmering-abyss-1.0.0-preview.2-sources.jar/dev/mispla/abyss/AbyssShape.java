package dev.mispla.abyss;

import ;

/** Layout 100: a branching fault valley, sheltered settlement and folded west gallery.
 * The plan follows connected fractures; rock shoulders interrupt long sightlines.
 * Historical layout 70/75 geometry is deliberately kept in its own recipes. */
public final class AbyssShape {
    private AbyssShape(){}
    private static double sq(double v){return v*v;}
    private static double smooth(double v){double t=Math.max(0,Math.min(1,v));return t*t*(3-2*t);}
    // x,z,radius,roof,floor. Narrow necks separate the distant vaults.
    private static final double[][] SPINE={{0,64,36,90,-35},{-25,3,72,103,-54},
        {-42,-77,65,96,-55},{-79,-147,39,81,-47},{-78,-222,59,77,-52},{-122,-268,33,58,-39}};
    private static final double[][] WEST={{-56,-102,32,76,-40},{-126,-143,36,68,-35},
        {-167,-187,39,73,-45},{-153,-252,31,57,-32}};
    private static final double[][] LEDGES={{47,40,-60},{47,40,-84},{22,37,-84},{22,37,-100},{-28,31,-100},{-28,31,-124},{-78,27,-124},{-78,25,-148},{-126,24,-148},{-126,20,-184},{-151,20,-184},{-151,16,-214},{-90,16,-214},{-90,22,-176},{-66,22,-176},{-66,27,-124},{-78,27,-124}};
    public record Column(int x,int z,double floor,double roof,double q,double rough,double ledgeDistance,double ledgeTop,int layout,double wallWeight){
        public boolean rock(int y){
            if(y<=floor)return true;
            double localRoof=roof,boundary=q;
            // Only the east wall changes. Cache the column weight and keep the
            // historical recipe's hot path free of new geological calculations.
            if(wallWeight>0){
                localRoof-=wallWeight*(4+3*Math.sin(z*.055+x*.028)+4*Math.exp(-sq((z+28)/28.0)));
                double bedding=y+.27*z+.14*x;
                double recess=13*Math.exp(-sq((bedding-54)/12.0))+9*Math.exp(-sq((bedding-17)/8.0));
                double shoulder=10*Math.exp(-sq((z-22)/22.0))*Math.exp(-sq((y-58)/20.0));
                double sway=5*Math.sin(z*.044+y*.017)+3*Math.sin(y*.07-z*.035);
                boundary-=wallWeight*(recess-shoulder+sway)/43;
                // Recesses end in solid rock before the unchanged footprint edge.
                boundary+=wallWeight*.60*smooth((x-109)/17.0);
                double side=smooth((x-50)/28.0)*(1-smooth((Math.abs(z-66)-44)/32.0));
                localRoof-=side*(5*Math.exp(-sq((z-65)/18.0))+3*Math.sin(x*.079-z*.047));
                boundary+=side*(11*Math.exp(-sq((z-66)/20.0))*Math.exp(-sq((y-63)/24.0))
                    -8*Math.exp(-sq((z-38)/16.0))*Math.exp(-sq((y-49)/13.0)))/43;
            }
            if(y>=localRoof)return true;
            double mid=(localRoof+floor)*.5,half=(localRoof-floor)*.5;
            if(boundary+.12*Math.pow((y-mid)/half,4)>1+rough)return true;
            // Occupied shelves widen into talus and merge with the native floor below.
            if(y<=ledgeTop&&ledgeDistance<7+(ledgeTop-y)*.55)return true;
            // Large attached rock shoulders, not a repeated forest of cylinders.
            double fault=x+23+.25*(z+75)+7*Math.sin(z*.024+y*.031)+4*Math.sin(y*.068);
            double width=(17+4*Math.sin(y*.055+z*.027)+Math.max(0,y-50)*.15)*Math.max(0,Math.sin(Math.PI*(z+143)/87));
            if(z<-56&&z>-143&&fault>0&&fault<width&&y>18+10*Math.sin(z*.032))return true;
            double fold=x+111-.38*(z+178)+6*Math.sin(z*.043+y*.04)+3*Math.sin(y*.08);
            if(z<-158&&z>-254&&fold>0&&fold<15+3*Math.sin(y*.047)&&y>-13)return true;
            // Quiet inhabited terrace narrows at the lip, broadens at its foot.
            int top=38+(z<=-26?1:0)+(z<=-43?1:0);
            double depth=Math.max(0,top-y);
            if(y<=top&&sq((x-62-4*Math.sin(z*.035))/(59+depth*.27))
                +sq((z+11+5*Math.sin(x*.03))/(90+depth*.19))<1)return true;
            return y<=38&&sq((x+49)/(25+depth*.17))+sq((z-35)/(22+depth*.13))<1;
        }
    }
    public static Column column(int x,int z){return column(x,z,ceiling(x,z));}
    public static Column column(int x,int z,int cap){return column(x,z,cap,100);}
    public static Column column(int x,int z,int cap,int layout){
        double n=Math.sin(x*.034+Math.sin(z*.019))*Math.cos(z*.039)+.25*Math.sin(x*.103-z*.071);
        double[] v={9,-57,45};
        corridor(v,x+4*n,z+3*n,SPINE);corridor(v,x+3*n,z-4*n,WEST);
        // The town sits in a broad side recess, out of the central fracture.
        double q=sq((x-47)/79.0)+sq((z+15)/104.0);
        if(q<v[0]){v[0]=q;v[1]=-46+12*q+3*n;v[2]=103-20*q+4*n;}
        double distance=1e9,ledgeTop=0;
        double wx=x+2*Math.sin(z*.06),wz=z+2*Math.sin(x*.05);
        for(int i=1;i<LEDGES.length;i++){
            var a=LEDGES[i-1];var b=LEDGES[i];double dx=b[0]-a[0],dz=b[2]-a[2];
            double t=Math.max(0,Math.min(1,((wx-a[0])*dx+(wz-a[2])*dz)/(dx*dx+dz*dz)));
            double d=Math.hypot(wx-a[0]-dx*t,wz-a[2]-dz*t);
            if(d<distance){distance=d;ledgeTop=a[1]+(b[1]-a[1])*t-2+Math.sin(x*.06+z*.07);}
        }
        double weight=layout>=101?Math.max(smooth((x-72)/40.0)*(1-smooth((Math.abs(z+10)-106)/34.0)),smooth((x-50)/28.0)*(1-smooth((Math.abs(z-66)-44)/32.0))):0;
        double geologicalCap=cap;
        if(weight>0&&x>111){
            int innerCap=CavernShape.ceiling(111,z);
            geologicalCap=Math.min(cap,innerCap+(cap-innerCap)*smooth((x-111)/16.0));
        }
        return new Column(x,z,Math.max(-57,v[1]+3*n),Math.min(geologicalCap-4,v[2]+3*n),v[0],.05*n,distance,ledgeTop,layout,weight);
    }
    private static void corridor(double[] best,double x,double z,double[][] points){
        for(int i=1;i<points.length;i++){
            var a=points[i-1];var b=points[i];double dx=b[0]-a[0],dz=b[1]-a[1];
            double t=Math.max(0,Math.min(1,((x-a[0])*dx+(z-a[1])*dz)/(dx*dx+dz*dz)));
            double r=a[2]+(b[2]-a[2])*t,q=(sq(x-a[0]-dx*t)+sq(z-a[1]-dz*t))/(r*r);
            if(q<best[0]){best[0]=q;best[1]=a[4]+(b[4]-a[4])*t+12*q;best[2]=a[3]+(b[3]-a[3])*t-22*q;}
        }
    }
    public static int ceiling(int x,int z){
        if(x>=-112&&x<=111&&z>=-176&&z<=111)return CavernShape.ceiling(x,z);
        // Low remote vaults fit beneath ordinary hill terrain; never remove the native cap.
        double[] v={9,-57,45};corridor(v,x,z,SPINE);corridor(v,x,z,WEST);
        return Math.max(48,Math.min(88,(int)Math.ceil(v[2]+8)));
    }
}
